/*---------------------------------------------------------------------
 * record.c - Routines to record data and use it to read it again to 
 * generate revised reports using different "histogram" parameters.
 *
 *-------------------------------------------------------------------------
 * Copyright 2006, Dave Wagoner
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *-------------------------------------------------------------------------
 *
 *---------------------------------------------------------------------*/

/*-------------------------------------------------------------------- 
 * fetch header files and macro definitions
 *-------------------------------------------------------------------*/
#include "./bertha.h"

/***************************************************************************
 * do_record() - store metrics for possible re-reporting later without 
 *               having to rerun the IOPs to obtain data. This allows 
 *               reporting with different bucket sizes, zero suppression
 *               flags, etc.
 ***************************************************************************/
void do_record(
		struct metrics_rec *metrics, 	/* array of raw perf data */
		uint   nprocs, 			/* number of processes */
               	uint   iops,			/* number of iops per process*/
		char  *operation,  		/*{read,write,re-write,replay}*/
                char  *rptdir,                  /* dir to write reports */
                char  *test_timestamp,          /* when test began */
                char  *testname,		/* id str for test results */
                FILE  *logptr,			/* ptr to log file */
                uint   verbose,
		uint   replay_mono_file_flag
               )
{
   char record_fname[MAX_REPORTNAME_SIZE];      /* record data filename */
   char error_msg[MAX_ERROR_MSG_LEN];
   uint m_index;				/* index from 2-D to 1-D */
   uint this_proc, this_iop;			/* loop counters */
   uint max_iop_rows;				
   FILE *outfile;				/* ptr to output (record) file*/
  

   /*--------------------------------------------------------------------
    * Pre-conditions
    *--------------------------------------------------------------------*/
   assert(!errno);
   if (!metrics)  BAD_ARG_PTR(metrics,"metrics","do_report","metrics!=NULL");
   if (!nprocs)   BAD_ARG_UINT(nprocs, "nprocs", "do_report","nprocs > 0");
   if (!iops)     BAD_ARG_UINT(iops,   "iops",   "do_report","iops > 0");
   if (!operation) 
      BAD_ARG_PTR(operation,"operation","do_report","operation!=NULL");
   if (!rptdir)   BAD_ARG_PTR(rptdir,"rptdir","do_report","rptdir!=NULL");
   if (!test_timestamp)   
      BAD_ARG_PTR(test_timestamp,"test_timestamp","do_report",
          "test_timestamp!=NULL");
   if (!testname) BAD_ARG_PTR(testname,"testname","do_report","testname!=NULL");
   if (!logptr) BAD_ARG_PTR(logptr,"logptr","do_report","logptr!=NULL");
   if (replay_mono_file_flag > 1) 
      BAD_ARG_UINT(replay_mono_file_flag, "replay_mono_file_flag",
	  "do_report", "replay_mono_file_flag = {0|1}");
   /*--------------------------------------------------------------------*/

  /*--------------------------------------------------------------------
   * construct filename for raw data 
   *--------------------------------------------------------------------*/
   strncpy(record_fname, rptdir, MAX_REPORT_PREFIX_SIZE );
   strcat (record_fname, "/");
   strncat(record_fname, testname, MAX_TESTNAME_LEN );
   if (strlen(testname)) strcat(record_fname,"_");
   assert(strlen(record_fname) < MAX_REPORT_PREFIX_SIZE );
   strcat(record_fname   , "record_");
   strcat(record_fname   , operation);
   strcat(record_fname   , ".dat" );
   assert(strlen(record_fname)<MAX_REPORTNAME_SIZE);

   if ( !(outfile = fopen(record_fname,"w"))) {
      fprintf(logptr, "Cannot create file: \"%s\"\n", record_fname);
      terminate( EXIT_REPORT_CREATION_ERROR );
   }							/* if !outfile */

  /*-----------------------------------------------------------------
   * record header information - nprocs iops replay_mono_file_flag
   *-----------------------------------------------------------------*/
   fprintf(outfile,"%u %u %u\n", nprocs, iops, replay_mono_file_flag);
   fprintf(outfile,"%s\n", test_timestamp); 
   
  /*-----------------------------------------------------------------
   * record raw data - reuse algorithm from dump_metrics
   *-----------------------------------------------------------------*/
   if (replay_mono_file_flag)
      max_iop_rows = (iops/nprocs) + (iops - nprocs*(iops/nprocs));
   else
      max_iop_rows = iops;

   for ( this_iop=0; this_iop < max_iop_rows; this_iop++ ) {
      for ( this_proc=0; this_proc < nprocs; this_proc++ ) {
         if (replay_mono_file_flag)
            m_index = this_proc*(iops/nprocs) + this_iop;
         else
            m_index = this_iop*nprocs+this_proc;

        /*
         * for concurrent replay mode, the number of IOPs in the
         * transaction file may not be an integral number of nprocs. In
         * this case, the last process executes the remainder of the IOPS.
         */
         if (!(replay_mono_file_flag  && (this_iop >= (iops/nprocs)) &&
                     (this_proc < (nprocs-1)) )) {
            /* write rsp_time as milliseconds to reduce round-off error */
            fprintf(outfile,"%lf %f %lu\n",
                metrics[m_index].tstamp,
                metrics[m_index].rsp_time * 1000,
		metrics[m_index].io_size);
         }                                           /* if replay */
      }                                              /* for this_iop */
   }                                                 /* for this_proc */

   if (fclose( outfile )) {
      (void)snprintf(error_msg, ERROR_MSG_MAX_LEN,
                "fclose() failed on file %s\n", record_fname);
      io_error(error_msg);
   }                                                 /* if fclose() */


}							/* do_record() */

/***************************************************************************
 * do_rereports() - reload data from a previous run of bertha into a 
 *                  shared memory segment and run do_reports() again. This
 *                  allows reporting with different bucket sizes, zero 
 *                  suppression flags, etc. 
 *
 *                  Note that when do_rereports() is run, bertha generates
 *                  no I/O - all that happens is that the reports are
 *                  generated in accordance with the new arguments.
 ***************************************************************************/
void do_rereports(
                char  *operation,               /*{read,write,re-write,replay}*/
                float  hist_args[NUM_CHARTS][NUM_CHART_PARMS],
                char  *rptdir,                 /* dir to write reports */
                char  *testname,                /* id str for test results */
                uint   dump_raw_metrics_flag,   /* 0=don't dump raw, 1=dump*/
                uint   metrics_by_proc_flag,    /* 0=don't dump stats, 1=dump*/
                uint   reports_requested[NUM_REPORT_TYPES],
                FILE  *logptr,
                uint   verbose
               )
{
   struct metrics_rec *metrics;       /* where to write tstamp & rsp times*/

   char record_fname[MAX_REPORTNAME_SIZE];  /* record data filename */
   uint m_index;			    /* index from 2-D to 1-D */
   uint nprocs; 
   uint iops;
   uint this_proc, this_iop;		    /* loop counters */
   uint concurrent_nprocs;
   uint max_iop_rows;				
   FILE *infile;			    /* ptr to input (record) file */
   uint line_num = 2;			    /* line# of rec file being read */
   uint replay_mono_file_flag;
   char test_timestamp[MAX_TSTAMP_STR_SIZE];  /*txt vers of start time of test*/

   int retval;

   /* temp variables to hold timestamp components contained in record file */
   char dayname[4];
   char month[4];
   char day_of_month[3];
   char time_of_day[9];
   char year[5]; 

   /*--------------------------------------------------------------------
    * Pre-conditions
    *--------------------------------------------------------------------*/
   assert(!errno);
   if (!operation) 
      BAD_ARG_PTR(operation,"operation","do_report","operation!=NULL");
   if (!hist_args) 
      BAD_ARG_PTR(hist_args,"hist_args","do_report","hist_args!=NULL");
   if (!rptdir)  BAD_ARG_PTR(rptdir,"rptdir","do_report","rptdir!=NULL");
   if (dump_raw_metrics_flag> 1) 
      BAD_ARG_UINT(dump_raw_metrics_flag, "dump-raw_metrics_flag",
	  "do_report", "dump-raw_metrics_flag= {0 | 1}");
   if (metrics_by_proc_flag > 1) 
      BAD_ARG_UINT(metrics_by_proc_flag, "metrics_by_proc_flag",
	  "do_report", "metrics_by_proc_flag = {0 | 1}");
   if (!reports_requested)   
      BAD_ARG_PTR(reports_requested,"reports_requested",
                  "do_report","reports_requested!=NULL");
   if (!logptr) BAD_ARG_PTR(logptr,"logptr","do_report","logptr!=NULL");
   /*--------------------------------------------------------------------*/

  /*--------------------------------------------------------------------
   * construct filename for raw data 
   *--------------------------------------------------------------------*/
   strncpy(record_fname, rptdir, MAX_REPORT_PREFIX_SIZE );
   strcat (record_fname, "/");
   strncat(record_fname, testname, MAX_TESTNAME_LEN );
   if (strlen(testname)) strcat(record_fname,"_");
   assert(strlen(record_fname) < MAX_REPORT_PREFIX_SIZE );
   strcat(record_fname   , "record_");
   strcat(record_fname   , operation);
   strcat(record_fname   , ".dat" );
   assert(strlen(record_fname)<MAX_REPORTNAME_SIZE);

   if ( !(infile = fopen(record_fname,"r"))) {
      fprintf(logptr, "Could not find: \"%s\"; continuing\n", record_fname);
      if (errno == 2) errno=0; /* reset on file not found */
      return;  /* ok not to find; no data recorded for this test */
   }							/* if !outfile */

   printf("Re-reporting data from %s\n",record_fname);
   fprintf(logptr, "Rereporting data from %s\n", record_fname);

  /*--------------------------------------------------------------------
   * read header information from record file
   *--------------------------------------------------------------------*/
   if (fscanf(infile,"%u %u %u\n",&nprocs,&iops,&replay_mono_file_flag) != 3){
      fprintf(logptr, 
         "Cannot read header (nprocs, iops, replay_mono_file_flag) ");
      fprintf(logptr,"  information from record file \"%s\"\n", record_fname);
      terminate(EXIT_RECORD_FILE_ERROR);
   }

   if (fscanf(infile,"%3s %3s %2s %8s %4s\n",
         dayname, month, day_of_month, time_of_day, year) != 5){
      fprintf(logptr, "Cannot read header information (test timestamp) from ");
      fprintf(logptr, "record file \"%s\"; no data\n", record_fname);
      terminate(EXIT_RECORD_FILE_ERROR);
   }

   (void)snprintf(test_timestamp, MAX_TSTAMP_STR_SIZE, "%s %s %s %s %s",
	dayname, month, day_of_month, time_of_day, year);

   if (strlen(test_timestamp) > MAX_TSTAMP_STR_SIZE) {
      fprintf(logptr, "Cannot read header information (test timestamp) from ");
      fprintf(logptr, "record file \"%s\"; timestamp too long\n", record_fname);
      terminate(EXIT_RECORD_FILE_ERROR);
   }

  /*--------------------------------------------------------------------
   * allocate space for metrics
   *--------------------------------------------------------------------*/
   if ( replay_mono_file_flag ) concurrent_nprocs = 1;
   else                         concurrent_nprocs = nprocs;

  /* 
   * allocate memory to contain metrics if it has not already been done.
   * Since metrics_shmid is declared as global, it is stored in the 
   * initialized data area and is therefore guaranteed to be initialized 
   * to be zero.
   * 
   * Subsequent note: there is no guarantee that the same number of metrics
   * would be stored in all datafiles; could be looking at datafiles from
   * different run. Need to delete and recreate shared memory area if it
   * already exists.
   */
   
   if ( metrics_shmid ) {
      if (verbose) fprintf(logptr,"removing shmid=%d\n",metrics_shmid);
      if (shmctl( metrics_shmid, IPC_RMID, NULL)) 
         terminate (EXIT_SHARED_MEM_ERROR);
      metrics_shmid = 0;
   } 						/* if metrics_shmid */

   if (verbose) {
      fprintf(logptr,"allocating shared memory segment of size: ");
      fprintf(logptr,"concurrent_nprocs=%u * iops=%u *",concurrent_nprocs,iops);
      fprintf(logptr,"sizeof(struct metrics_rec)=%u => %u bytes\n",
         sizeof(struct metrics_rec), 
	 concurrent_nprocs*iops*sizeof(struct metrics_rec));
   }						/* if verbose */

   metrics = allocate_shm( (size_t)(sizeof(struct metrics_rec))
                           * concurrent_nprocs * iops);
   init_metrics(metrics, concurrent_nprocs, iops, logptr);

  /*--------------------------------------------------------------------
   * reload metrics from file - reuse algorithm from dump_metrics() and 
   *                            do_record()
   *--------------------------------------------------------------------*/
   if (replay_mono_file_flag)
      max_iop_rows = (iops/nprocs) + (iops - nprocs*(iops/nprocs));
   else
      max_iop_rows = iops;

   for ( this_iop=0; this_iop < max_iop_rows; this_iop++ ) {
      for ( this_proc=0; this_proc < nprocs; this_proc++ ) {
         if (replay_mono_file_flag)
            m_index = this_proc*(iops/nprocs) + this_iop;          else
            m_index = this_iop*nprocs+this_proc;
        /*
         * for concurrent replay mode, the number of IOPs in the
         * transaction file may not be an integral number of nprocs. In
         * this case, the last process executes the remainder of the IOPS.
         */
         if (replay_mono_file_flag  && (this_iop >= (iops/nprocs)) &&
 	    (this_proc < (nprocs-1)) ) {
            continue;
         } else {
            if ((retval=fscanf(infile,"%lf %f %lu\n",
                &metrics[m_index].tstamp,
                &metrics[m_index].rsp_time, 
                &metrics[m_index].io_size)) != 3) {
               fprintf(logptr, 
                  "Cannot read data line from record file \"%s\"\n",
                  record_fname);
               fprintf(logptr,"Could not read line %u of file\n",line_num);
               terminate(EXIT_RECORD_FILE_ERROR);
            }					     /* if fscanf() */
            /* convert rsp_time back to milliseconds; values were converted
             * to seconds to reduce round-off error */
            metrics[m_index].rsp_time /= 1000;

            line_num++;
         }                                           /* if replay */
      }                                              /* for this_iop */
   }                                                 /* for this_proc */

   (void)fclose(infile);

  /*-----------------------------------------------------------------
   * data reloaded; run reports again
   *-----------------------------------------------------------------*/
   do_reports(metrics, nprocs, iops, operation, test_timestamp,
              hist_args, rptdir, testname, dump_raw_metrics_flag,
              metrics_by_proc_flag, reports_requested, logptr, verbose,
              replay_mono_file_flag);

  /*--------------------------------------------------------------
   * Post-conditions
   *--------------------------------------------------------------*/
   assert(!errno);
}						/* do_rereports() */
