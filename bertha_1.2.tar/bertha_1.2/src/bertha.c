/***************************************************************************
 * bertha.c - contains main() and commonly accessed routines
 *
 *-------------------------------------------------------------------------
 * Copyright 2006, Dave Wagoner
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *-------------------------------------------------------------------------
 *
 ***************************************************************************/

/*-------------------------------------------------------------------- 
 * header files, prototypes, structure defs, etc.
 *-------------------------------------------------------------------*/
#include "./bertha.h"

/*--------------------------------------------------------------------
 * prototypes local to this module
 *-------------------------------------------------------------------*/
static void usage();
static void init_hist_args( float hist_args[NUM_CHARTS][NUM_CHART_PARMS] );
static void init_report_types( uint reports_requested[NUM_REPORT_TYPES] );
static void dump_hist_args( float hist_args[NUM_CHARTS][NUM_CHART_PARMS],
			     FILE *logptr );
static void parse_hist_args( float hist_args[NUM_CHARTS][NUM_CHART_PARMS],
			     char *s, hist_t i, char *hist_name);
static uint contains_digit( char *start, char *end );

/***********************************************************************
 * logptr must be global for signal handlers to access, but must also be 
 * visible only within this module - passed as arg to functions outside 
 * this module
 ***********************************************************************/
static FILE *logptr;              /* pointer to log file */

/***********************************************************************
 * main()
 ***********************************************************************/
main(int argc, char * argv[])
{
   uint i;
   uint do_replay     = 0;  /* default is thruput, not replay */
   uint verbose       = 0;  /* flag for messages, values=(0,1,2) */
   uint record_flag   = 0;  /* flag for recording data values (0=no) */
   uint rereport_flag = 0;  /* flag for rereporting collected data (0=no)*/
   int  nprocs_int;     /* temp var to decipher nprocs cmd arg */
   uint nprocs    = 1;  /* number of procs to do I/O concurrently; default=1 */
   uint num_dirs  = 0;  /* number of dirs across which I/O is spread */
   double fsize	  = 1.0;/* MB size of data files*/
   uint replay_mono_file_flag = 0; /* flag to specify replay mode */
   uint replay_scale_io_size_flag = 0;/* flag to specify io size to be scaled*/
   uint dump_raw_metrics_flag = DEFAULT_DUMP_RAW_METRICS_FLAG;
   uint metrics_by_proc_flag  = DEFAULT_METRICS_BY_PROC_FLAG;

   char   logfile[MAX_LOGNAME_LEN] = "";      /* log activity for debug*/
   char   rptdir[MAX_DIRNAME_LEN] = "";      /* dir to contain rpts */
   char   error_msg[MAX_ERROR_MSG_LEN] = "";  /* mkdir() error msgs */
   char   testname[MAX_TESTNAME_LEN] = "";    /* testname to id results*/
   char   replay_file[MAX_REPLAYNAME_LEN]=""; /* name of file containing 
   					       * transactions to be 
					       * replayed */
   char   dir[MAX_NPROCS][MAX_DIRNAME_LEN];   /* array containing list of 
   					       * dir names to house I/O 
					       * scratch files being used
					       * by concurrent processes
					       */

   long  io_size_long;			      /* tmp var to decipher arg */
   ulong io_size = CHUNK; 		      /* size of I/Os; default=CHUNK */

   float hist_args[NUM_CHARTS][NUM_CHART_PARMS];  /* args to control hists */
   uint  reports_requested[NUM_REPORT_TYPES];     /* types of reports reqd */
   int   retval;				  /* return vals from syscalls*/

   assert( !errno );

   setbuf(stdout, NULL);	      	    /* deactivate output buffering */
   setbuf(stderr, NULL);	      	    /* deactivate output buffering */
   strncpy(dir[0],".",2);		    /* default setting */
   strncpy(testname,"",1);

   cpu_sample_interval = DEFAULT_CPU_SAMPLE_INTERVAL; 

  /*--------------------------------------------------
   * setup chart parameters
   *-------------------------------------------------*/
   init_hist_args( hist_args ); 
   init_report_types( reports_requested );

   assert( !errno );

  /*----------------------------------------------
   * scan args
   *----------------------------------------------*/
   for (i=1; i<(uint)argc ; i++) {

      /*
       * directory names (there may be multiple); default is "."
       */
      if  (!strcmp(argv[i],"--scratch_dir")) {
         if (strlen(argv[i+1]) > MAX_DIRNAME_LEN) {
             printf("Bertha: dir name too long: \"%s\"\n", argv[i+1]);
             exit( EXIT_BAD_COMMAND_LINE_ARG );
         }

         if ((num_dirs+1) >= MAX_DIRS ) {
            printf(
           "Bertha: maximum number of dirs (%d) exceeded; %u dirs specified\n",
                        MAX_DIRS, num_dirs);
            exit( EXIT_BAD_COMMAND_LINE_ARG );
         }                                    /* if num_dirs >= MAX_DIRS*/

          /* dirname param checks ok; clear to copy */
          strcpy(dir[num_dirs++], argv[++i]);
      }                                      /* if -d */

      /*
       * logfile name; default is "bertha.log"
       */
      else if (!strcmp(argv[i], "--logfile")) {
         if (strlen(argv[i+1]) > MAX_LOGNAME_LEN) {
             fprintf(stderr, "Bertha: logfile name too long: \"%s\"\n", 
                argv[i+1]);
             exit( EXIT_BAD_COMMAND_LINE_ARG );
         }					/* if strlen() */
          /* dirname param checks ok; clear to copy */
          strncpy(logfile, argv[++i], MAX_LOGNAME_LEN);
      }						/* if strcmp() */

      /*
       * Tracefile name. First line of tracefile contains the max block 
       * addressed (blocks are 512 bytes); each subsequent line contains 
       * an address, a number of blocks to be read/written, and a single 
       * character of either "r" or "w" to specify a read or a write operation.
       */
      else if  (strcmp(argv[i], "--tracefile") == 0)  {
         if (strlen(argv[i+1]) > MAX_REPLAYNAME_LEN) {
             printf("Bertha: datafile name too long: \"%s\"\n", argv[i+1]);
             exit( EXIT_BAD_COMMAND_LINE_ARG );
         }
          /* dirname param checks ok; clear to copy */
          strcpy(replay_file, argv[++i]);
	  do_replay = 1;
      }

      else if (!strcmp(argv[i], "--io_size"))    {
         io_size_long = atol(argv[++i]);
         if ( io_size_long > 0 ) {
            io_size = (ulong)io_size_long;
         } else {
            fprintf(stderr,"invalid --io_size value: \"%s\"\n", argv[i-1]);
            terminate( EXIT_BAD_COMMAND_LINE_ARG );  
         }						/* if io_size_long */
      } else if (!strcmp(argv[i], "--num_procs"))  {
         nprocs_int = atoi(argv[++i]);
         if (nprocs_int > 0) nprocs = (uint)nprocs_int;
         else {
            fprintf(stderr,"invalid --num_procs value: \"%s\"\n", argv[i-1]);
            terminate( EXIT_BAD_COMMAND_LINE_ARG );  
         }						/* if nprocs_int */
      } else if (!strcmp(argv[i], "--report_dir")) strcpy(rptdir, argv[++i]);
      else if (!strcmp(argv[i], "--test_name"))   {
         if ( strlen(argv[i+1])> MAX_TESTNAME_LEN) {
            fprintf(stderr, "test_name too long: \"%s\"\n",argv[i+1]);
            terminate( EXIT_BAD_COMMAND_LINE_ARG );  
         }					     /* if strlen(testname) */
         strcpy(testname,argv[++i]);
      }						     /* if --test_name */
      else if (!strcmp(argv[i], "--verbose"))    verbose++;
      else if (!strcmp(argv[i], "--record"))     record_flag   = 1;
      else if (!strcmp(argv[i], "--rereport"))   rereport_flag = 1;
      else if (!strcmp(argv[i], "--scratch_file_size")) 
                  fsize = atof(argv[++i]);
      else if (!strcmp(argv[i], "--dump_raw_metrics")) dump_raw_metrics_flag =1;
      else if (!strcmp(argv[i], "--metrics_by_proc"))  metrics_by_proc_flag =1; 
      else if (!strcmp(argv[i], "--replay_mono_file")) replay_mono_file_flag++;
      else if (!strcmp(argv[i], "--replay_scale_io_size")) 
                                                 replay_scale_io_size_flag++;
      else if (!strncmp(argv[i], "--response_time_hist",
	                strlen("--response_time_hist")))
               parse_hist_args(hist_args, argv[i], RSP_TIME, 
                                "response_time_hist" );
      else if (!strncmp(argv[i], "--xput_hist",
			strlen("--xput_hist")))
               parse_hist_args( hist_args, argv[i], XPUT, "xput_hist" );
      else if (!strncmp(argv[i], "--concurrency_hist",
			strlen("--concurrency_hist")))
               parse_hist_args( hist_args, argv[i], CONCURRENCY, 
                                 "concurrency_hist" );
      else if (!strncmp(argv[i], "--rsp_vs_xput",
			strlen("--rsp_vs_xput")))
               parse_hist_args( hist_args, argv[i], RSP_XPUT, "rsp_vs_xput" );
      else if (!strncmp(argv[i], "--rsp_vs_concurrency",
			strlen("--rsp_vs_concurrency")))
               parse_hist_args( hist_args, argv[i], RSP_CONCURRENCY, 
                                  "rsp_vs_concurrency" );
      else if (!strncmp(argv[i], "--time_line",
			strlen("--time_line")))
               parse_hist_args( hist_args, argv[i], TIME, "time_line");
      else if (!strcmp(argv[i], "--text_reports")) reports_requested[TEXT] =1;
      else if (!strcmp(argv[i], "--csv_reports"))  reports_requested[CSV]  =1;
      else if (!strcmp(argv[i], "--gnuplot_reports")) 
					          reports_requested[GNU_PLOT]=1;
      else if (!strcmp(argv[i], "--R_reports"))    reports_requested[R]    =1;
      else if (!strcmp(argv[i], "--sas_reports"))  reports_requested[SAS]  =1;
      else if (!strcmp(argv[i], "--help"))  { usage(); }
      else if (!strcmp(argv[i], "--usage"))  { usage(); }
      else if (!strcmp(argv[i], "--version")) {
         printf("%s", VERSION);
         exit(0);
      }

      else {
         fprintf(stderr, "\n\tInvalid arg: \"%s\"\n",argv[i]);
         usage();
      }							/* else */
   }							/* for */

   if ( !num_dirs ) num_dirs = 1;		/* default, 1 dir, = "." */

  /*----------------------------------------------
   *   Validate args
   *----------------------------------------------*/
   if (((fsize-1.0)<(float)((-1)*(DBL_EPSILON))) || 
       ((fsize-(double)MAX_FILESIZE)>DBL_EPSILON)){
      fprintf(stderr, "\tInvalid size: %lf (minimum is 1 MB, maximum is %ld)\n",
		fsize, (long)MAX_FILESIZE);
      usage();
   }							/* if  fsize*/

   /* Need to upper-bound the number of processes */
   if ( (!nprocs) || (nprocs > MAX_NPROCS)) {
      fprintf(stderr,
         "\tInvalid value for number of procs: %u; Max is %d, min is 1\n",
	 nprocs, MAX_NPROCS);
      exit(EXIT_BAD_COMMAND_LINE_ARG);
   }							/* if nprocs */

   assert( !errno );

   /*--------------------------------------------------
    * create log file; default is "bertha.log"
    *--------------------------------------------------*/
   if ( !strcmp(logfile,"")) 
      if ( (snprintf(logfile , MAX_LOGNAME_LEN, DEFAULT_LOGFILENAME)<0) ){
         fprintf(stderr, "Could not construct logfile name \"%s\"\n",
                 DEFAULT_LOGFILENAME);
         exit( EXIT_BAD_STRING );
      }						/* if snprintf() */

   if (!(logptr = fopen(logfile , "w"))) {
      fprintf(stderr, "Can't open logfile %s\n", logfile);
      terminate(EXIT_LOG_FILE_ERROR);
   } else {
      setbuf(logptr, NULL); 		/* deactivate output buffering */
   }
   assert( !errno );

  /*----------------------------------------------
   *   Warn if no reports selected
   *----------------------------------------------*/
   if ( !(reports_requested[TEXT] + reports_requested[CSV] +
          reports_requested[GNU_PLOT] + reports_requested[R] +
          reports_requested[SAS]) ) {
      fprintf(logptr, 
	 "Warning: No reports selected - no output will be genertated\n");
      fprintf(stderr, 
	 "Warning: No reports selected - no output will be genertated\n");
   }

   /*--------------------------------------------------
    * create rpt dir; default is "./reports"
    *--------------------------------------------------*/
   if ( !strcmp(rptdir, "") ) 
      if ( (snprintf(rptdir, MAX_DIRNAME_LEN, DEFAULT_RPT_DIR) <0) ) {
         fprintf(stderr, "Could not construct rptdir name \"%s\"\n",
                 DEFAULT_RPT_DIR);
         exit( EXIT_BAD_STRING );
      }						/* if snprintf() */
   assert( !errno );

   if ( (retval = mkdir(rptdir, 0755)) && (errno != EEXIST) ) {
      (void)snprintf(error_msg, MAX_ERROR_MSG_LEN, 
                "Cannot make rptdir \"%s\"\n", rptdir);
      fprintf(logptr, "%s", error_msg);
   } 

   if ( EEXIST ) errno = 0;			/* reset if EEXIST */
   assert( !errno );

  /* vector interupts to not leave stray shared memory during abend */
   signal(SIGINT,  (sighandler_t)sighandler_INT);
   signal(SIGQUIT, (sighandler_t)sighandler_QUIT);
   signal(SIGABRT, (sighandler_t)sighandler_ABRT);
   signal(SIGBUS,  (sighandler_t)sighandler_BUS);
   signal(SIGSEGV, (sighandler_t)sighandler_SEGV);
   signal(SIGTERM, (sighandler_t)sighandler_TERM);

#ifdef SIGSTKFLT
   signal(SIGSTKFLT, (sighandler_t)sighandler_STKFLT);
#endif

   assert( !errno );

  /*------------------------------------------------------------------------
   * dump the contents of the hist_args array - for diagnostics only
   *------------------------------------------------------------------------*/
   if ( verbose ) { 
      dump_hist_args( hist_args, logptr );
   } 

  /*--------------------------------------------------------------------
   * start the counters
   *--------------------------------------------------------------------*/
   basetime = timestamp(0);   /* baseline elapsed time */

  /*--------------------------------------------------------------------
   * Either read data from prior run and rereport or run an I/O test
   *--------------------------------------------------------------------*/
   if ( rereport_flag ) {
      MARK("rereport","Write");
      do_rereports("Write", hist_args, rptdir, testname, dump_raw_metrics_flag,
         metrics_by_proc_flag, reports_requested, logptr, verbose);

      MARK("rereport","Read");
      do_rereports("Read", hist_args, rptdir, testname, dump_raw_metrics_flag,
         metrics_by_proc_flag, reports_requested, logptr, verbose);

      MARK("rereport","ReWrite");
      do_rereports("ReWrite", hist_args, rptdir, testname, 
         dump_raw_metrics_flag, metrics_by_proc_flag, reports_requested, logptr,
         verbose);

      MARK("rereport","Replay");
      do_rereports("Replay", hist_args, rptdir, testname, dump_raw_metrics_flag,
         metrics_by_proc_flag, reports_requested, logptr, verbose);
 
      MARK("rereport","all complete");
   } else {
     /*------------------------------------------------------------------------
      * if a trace file has been supplied, then the intention is to replay the
      * file. If none has been supplied, default to standard thruput tests
      *--------------------------- -------------------------------------------*/
      if ( do_replay ) {
         if (verbose) MARK("replay test", "initiated");
            replay(nprocs, fsize, verbose, num_dirs, dir, rptdir, testname, 
                replay_file, replay_mono_file_flag, replay_scale_io_size_flag,
                hist_args, dump_raw_metrics_flag, metrics_by_proc_flag, 
                reports_requested, record_flag, logptr); 
         if (verbose) MARK("replay test", "completed"); 

         (void)sleep(1);
         /*
          * Solaris alarms to terminate sleep state cause EINTR to be set;
          * this is quite reasonable (Linux does not do this). Reset errno
          * to allow assertions ( assert(!errno) ) to pass.
          */
          if (errno == EINTR) errno = 0;

      } else {	    
         if (verbose) MARK("thuput test", "initiated");
            thruput(nprocs, fsize, verbose, num_dirs, dir, rptdir, testname, 
                io_size, hist_args, dump_raw_metrics_flag, 
                metrics_by_proc_flag, reports_requested, record_flag, logptr);
         if (verbose) MARK("thuput test", "completed");
      }							/* if do_replay */
   }							/* if rereport_flag */
   /* clean up: remove the shared memory segment for metrics */

   terminate( EXIT_NORMAL_TERMINATION ); 

   return(0); 				/* stmt here to keep splint happy */
}							/* main() */

/***********************************************************************
 * bonnie_report()
 ***********************************************************************/
void bonnie_report(char *testname, double size, uint nprocs, 
                   double delta[NTESTS][2], ulong io_size)
{
   char bonnie_testname[MAX_TESTNAME_LEN];
  /*------------------------------------------------------------------------
   * Pre-conditions
   *------------------------------------------------------------------------*/
   assert(!errno);
   if (!testname) 
      BAD_ARG_PTR(testname, "testname", "bonnie_report", "testname!=NULL");
   if (!delta) 
      BAD_ARG_PTR(delta, "delta", "bonnie_report", "delta!=NULL");
   if (!io_size) BAD_ARG_ULONG(io_size,"io_size","bonnie_report","io_size>0");

  /*------------------------------------------------------------------------*/

   /* remove trailing '_' when emitting testname in bonnie_reports */
   strncpy(bonnie_testname, testname, MAX_TESTNAME_LEN);

  /*
   *  report headers
   */
   fprintf(logptr,"\n\tBonnie Style Statistics\n");
   fprintf(logptr,"\nTest Name  MB  Procs ");
   fprintf(logptr,"---Write---- ----Read---- ---ReWrite----\n");
   fprintf(logptr,"                     ");
   fprintf(logptr,"MB/sec  %%CPU MB/sec  %%CPU MB/sec  %%CPU\n");

   fprintf(logptr,"%-8.8s %5.0lf %5u  ",testname, size / (1024 * 1024), nprocs);

   fprintf(logptr,"%6.1lf  %4.0lf %6.1lf  %4.0lf ",
       ((size)*nprocs/(delta[(int) Write][ELAPSED] * 1024.0 * 1024.0)),
       delta[(int) Write][CPU] / delta[(int) Write][ELAPSED] * 100.0,
       ((size)*nprocs/(delta[(int) Read][ELAPSED] * 1024.0 * 1024.0)),
       delta[(int) Read][CPU] / delta[(int) Read][ELAPSED] * 100.0);

   fprintf(logptr,"%6.1lf  %4.0lf\n",
       (((size)*2+io_size)*nprocs/(delta[(int) ReWrite][ELAPSED]
            *1024.0 * 1024.0)),
       delta[(int) ReWrite][CPU] / delta[(int) ReWrite][ELAPSED] * 100.0);

   printf("\n\tBonnie Style Statistics\n");
   printf("Test Name  MB  Procs ");
   printf("---Write---- ----Read---- ---ReWrite----\n");
   printf("                     ");
   printf("MB/sec  %%CPU MB/sec  %%CPU MB/sec  %%CPU\n");

   printf("%-8.8s %5.0lf %5u  ", testname, size / (1024 * 1024), nprocs);

   printf("%6.1lf  %4.0lf %6.1lf  %4.0lf ",
       (size*nprocs/(delta[(int) Write][ELAPSED] * 1024.0 * 1024.0)),
       delta[(int) Write][CPU] / delta[(int) Write][ELAPSED] * 100.0,
       (size*nprocs/(delta[(int) Read][ELAPSED] * 1024.0 * 1024.0)),
       delta[(int) Read][CPU] / delta[(int) Read][ELAPSED] * 100.0);

   printf("%6.1lf  %4.0lf\n",
       ((size*2.0+io_size)*nprocs/(delta[(int) ReWrite][ELAPSED]
            *1024.0 * 1024.0)),
       delta[(int) ReWrite][CPU] / delta[(int) ReWrite][ELAPSED] * 100.0);

  /*------------------------------------------------------------------------
   * Post-conditions
   *------------------------------------------------------------------------*/
   assert( !errno );
}							/* bonnie_report() */

/***********************************************************************
 * openfile() - open a file; the file may already exist or may need to
 *             be created.
 ***********************************************************************/
void openfile( char *name, int *fd, int create)
{
   int retval;					/* return val for syscalls */

  /*------------------------------------------------------------------------
   * Pre-conditions
   *------------------------------------------------------------------------*/
   assert(!errno);
   if (!name) BAD_ARG_PTR(name, "name", "openfile", "name!=NULL");
   if (!fd)   BAD_ARG_PTR(fd,   "fd",   "openfile", "fd!=NULL");
   if ((create!=0)&&(create!=1)) 
      BAD_ARG_INT(create,"create","openfile","create={0,1}");
  /*------------------------------------------------------------------------*/

   if (create == 1) { 				/* create from scratch */
      if (((retval = unlink(name)) == -1) && (*fd != -1)) io_error("unlink");
      if ( errno == ENOENT ) errno = 0;       /* reset if no pre-exising dir */
      *fd = open(name, O_RDWR | O_CREAT | O_EXCL , 0777);
   } 						/* create from scratch */
   else *fd = open(name, O_RDWR , 0777);

   if (*fd == -1) io_error(name);		/* error if fd not changed */

  /*------------------------------------------------------------------------
   * Post-conditions
   *------------------------------------------------------------------------*/
   assert( !errno );
}							/* openfile() */

/***********************************************************************
 * usage()
 ***********************************************************************/
static void usage()
{
   fprintf(stderr,"\nUsage: bertha [OPTIONS]\n\n");
   fprintf(stderr,"OPTIONS:\n");

   fprintf(stderr,"\t--scratch_file_size FILE_SIZE_IN_MB\n");
   fprintf(stderr,"\t--scratch_dir DIRNAME\n");
   fprintf(stderr,
         "\t\t(can be used more than once to spray I/O to multiple partitions)\n");
   fprintf(stderr,"\t--num_procs NUMBER_OF_CONCURRENT_PROCESSES\n");
   fprintf(stderr,"\t--io_size NUM_BYTES (default is 16384 (16K)\n");

   fprintf(stderr,"\n");
   fprintf(stderr,"\t--report_dir REPORT_DIR_NAME (default is \"./reports\"\n");
   fprintf(stderr,"\t--logfile LOG_FILE_NAME (default is ./bertha.log)\n");
   fprintf(stderr,"\t--testname TESTNAME (default is \"\" (empty)\n");
   fprintf(stderr,"\t--verbose (use multiple times to increase verbosity\n");

   fprintf(stderr,"\n");
   fprintf(stderr,"\t--dump_raw_metrics\n");
   fprintf(stderr,"\t--metrics_by_proc\n");

   fprintf(stderr,"\n");
   fprintf(stderr,"\t--tracefile TRACE_FILE_NAME (for \"replays\")\n");
   fprintf(stderr,"\t--replay_mono_file\n");
   fprintf(stderr,"\t--replay_scale_io_size\n");

   fprintf(stderr,"\n");
   fprintf(stderr,"\t--response_time_hist=");
   fprintf(stderr,"[lbound,ubound,bucket_size,suppress_empty]\n");

   fprintf(stderr,"\t--xput_hist=");
   fprintf(stderr,"[lbound,ubound,bucket_size,suppress_empty]\n");

   fprintf(stderr,"\t--concurrency_hist=");
   fprintf(stderr,"[lbound,ubound,bucket_size,suppress_empty]\n");

   fprintf(stderr,"\t--rsp_vs_xput=");
   fprintf(stderr,"[lbound,ubound,bucket_size,suppress_empty]\n");

   fprintf(stderr,"\t--rsp_vs_concurrency=");
   fprintf(stderr,"[lbound,ubound,bucket_size,suppress_empty]\n");

   fprintf(stderr,"\t--time_line=");
   fprintf(stderr,"[lbound,ubound,bucket_size,suppress_empty]\n");

   fprintf(stderr,"\n");
   fprintf(stderr,"\t--text_reports\n");
   fprintf(stderr,"\t--csv_reports\n");
   fprintf(stderr,"\t--gnuplot_reports\n");
   fprintf(stderr,"\t--R_reports\n");
   fprintf(stderr,"\t--sas_reports\n");

   fprintf(stderr,"\n");
   fprintf(stderr,"\t--record\n");
   fprintf(stderr,"\t--rereport\n");

   fprintf(stderr,"\n\n");
   exit(EXIT_BAD_USAGE);
}							/* usage() */

/***********************************************************************
 * sample_times()
 ***********************************************************************/
void sample_times(double basetime, double *last_elapsed_time,
				       double *last_cpu_time)
{
  /*------------------------------------------------------------------------
   * Pre-conditions
   *------------------------------------------------------------------------*/
   assert(!errno);
   if (!last_elapsed_time) 
      BAD_ARG_PTR(last_elapsed_time,"last_elapsed_time","get_delta_t",
		  "last_elapsed_time!=NULL");
   if (!last_cpu_time) 
      BAD_ARG_PTR(last_cpu_time,"last_cpu_time","get_delta_t",
		  "last_cpu_time!=NULL");
  /*------------------------------------------------------------------------*/

  *last_elapsed_time = timestamp(basetime);
  *last_cpu_time     = cpu_stamp();

  /*------------------------------------------------------------------------
   * Post-conditions
   *------------------------------------------------------------------------*/
   assert(!errno);
}							/* sample_times() */

/***********************************************************************
 * get_delta_t()
 ***********************************************************************/
void get_delta_t(tests_t test, double delta[NTESTS][2],
		        double basetime, double *last_elapsed_time,
			double *last_cpu_time)
{
  int which = (int) test;

  /*------------------------------------------------------------------------
   * Pre-conditions
   *------------------------------------------------------------------------*/
   assert(!errno);
   if (!delta) BAD_ARG_PTR(delta,"delta","get_delta_t","delta!=NULL");
  /*------------------------------------------------------------------------*/

  delta[which][ELAPSED] = MAX(0,timestamp(basetime) - *last_elapsed_time-SLEEP);
  delta[which][CPU] 	= cpu_stamp()               - *last_cpu_time;

  /*------------------------------------------------------------------------
   * Post-conditions
   *------------------------------------------------------------------------*/
   assert(!errno);
}							/* get_delta_t() */

/***********************************************************************
 * cpu_stamp()
 ***********************************************************************/
double cpu_stamp()
{
#if defined(SysV)
   struct tms tms;

   if (times(&tms) == -1) terminate(EXIT_GETTIME_ERROR);
   return ((double) tms.tms_utime) / ((double) sysconf(_SC_CLK_TCK)) +
      ((double) tms.tms_stime) / ((double) sysconf(_SC_CLK_TCK));

#else
   struct rusage rusage;
   int    retval;
   double retval_cpu_time;

   retval =  getrusage(RUSAGE_CHILDREN, &rusage);
   if (retval && errno && (errno!=EINTR)) terminate(EXIT_GETTIME_ERROR);

   retval_cpu_time =   ((double)  rusage.ru_utime.tv_sec) +
            (((double) rusage.ru_utime.tv_usec) / 1000000.0) +
            ((double)  rusage.ru_stime.tv_sec) +
            (((double) rusage.ru_stime.tv_usec) / 1000000.0);

   return (
            ((double)  rusage.ru_utime.tv_sec) +
            (((double) rusage.ru_utime.tv_usec) / 1000000.0) +
            ((double)  rusage.ru_stime.tv_sec) +
            (((double) rusage.ru_stime.tv_usec) / 1000000.0)
          );
#endif
}						/* cpu_stamp() */

/***********************************************************************
 * timestamp()
 ***********************************************************************/
double timestamp(double basetime)
{
#if defined(SysV)
   int        val;
   struct tms tms;

   if ((val = times(&tms)) == -1) terminate(EXIT_GETTIME_ERROR);
   return ((double) val) / ((double) sysconf(_SC_CLK_TCK));

#else
   struct timeval tp;
   
   if (gettimeofday(&tp,(struct timezone *)NULL)== -1) 
      terminate(EXIT_GETTIME_ERROR);
   return ((double) tp.tv_sec  + (double) tp.tv_usec/1000000.0 - basetime );
#endif
}						/* timestamp() */

/***********************************************************************
 * io_error()
 ***********************************************************************/
void io_error(char * message)
{
#define BUFF_SIZE 256
  char buff[BUFF_SIZE];

  /*--------------------------------------------------------------------
   * Pre-conditions
   *--------------------------------------------------------------------*/
   if (!logptr)  BAD_ARG_PTR(logptr,  "logptr",  "io_error", "logptr!=NULL");
   /* assert(strlen(message) < 30); */
  /*--------------------------------------------------------------------*/

   printf("io_error: %s, errno=%d\n",message, errno);
   (void)snprintf(buff, BUFF_SIZE, "bertha: drastic I/O error (%s)", message);
   perror(buff);

   if (errno == EFBIG) terminate(EXIT_SCRATCH_FILE_TOO_LARGE);
   else                terminate(EXIT_IO_ERROR);
}						/* io_error() */

/***********************************************************************
 * io_warn() - note non-fatal issue
 ***********************************************************************/
void io_warn(FILE *logptr, char * message)
{
  /*--------------------------------------------------------------------
   * Pre-conditions
   *--------------------------------------------------------------------*/
   if (!logptr)  BAD_ARG_PTR(logptr,  "logptr",  "io_warn", "logptr!=NULL");
   if (!message) BAD_ARG_PTR(message, "message", "io_warn", "message!=NULL");
  /*--------------------------------------------------------------------*/

   fprintf(logptr, "%s", message);
   perror(message);
   errno = 0;					/* reset errno */

   return;
}						/* io_warn() */

/***********************************************************************
 * init_report_types
 ***********************************************************************/
static void init_report_types( uint reports_requested[NUM_REPORT_TYPES] ) {

  /*--------------------------------------------------------------------
   * Pre-conditions
   *--------------------------------------------------------------------*/
   assert(!errno);
   if (!reports_requested) 
      BAD_ARG_PTR(reports_requested,"reports_requested","report_types",
		  "reports_requested!=NULL");
  /*--------------------------------------------------------------------*/

   reports_requested[TEXT]     = 0;
   reports_requested[CSV]      = 0;
   reports_requested[GNU_PLOT] = 0;
   reports_requested[R]        = 0;
   reports_requested[SAS]      = 0;

  /*--------------------------------------------------------------------
   * Post-conditions
   *--------------------------------------------------------------------*/
   assert(!errno);
}						/* init_report_types() */

/***********************************************************************
 * init_hist_args
 ***********************************************************************/
static void init_hist_args( float hist_args[NUM_CHARTS][NUM_CHART_PARMS] )
{
  /*--------------------------------------------------------------------
   * Pre-conditions
   *--------------------------------------------------------------------*/
   assert(!errno);
   if (!hist_args) 
      BAD_ARG_PTR(hist_args,"hist_args","init_hist_args","hist_args!=NULL");
  /*--------------------------------------------------------------------*/

   hist_args[RSP_TIME][TIME_INTERVAL] = DEFAULT_RSP_HIST_BUCKET_SIZE;
   hist_args[RSP_TIME][BUCKET_SIZE]   = DEFAULT_RSP_HIST_BUCKET_SIZE;
   hist_args[RSP_TIME][SUPPRESS_ZERO] = DEFAULT_RSP_HIST_SUPPRESS_ZERO;

   hist_args[XPUT][TIME_INTERVAL] = DEFAULT_RSP_HIST_BUCKET_SIZE;
   hist_args[XPUT][BUCKET_SIZE]   = DEFAULT_XPUT_HIST_BUCKET_SIZE;
   hist_args[XPUT][SUPPRESS_ZERO] = DEFAULT_XPUT_HIST_SUPPRESS_ZERO;

   hist_args[CONCURRENCY][TIME_INTERVAL] = DEFAULT_RSP_HIST_BUCKET_SIZE;
   hist_args[CONCURRENCY][BUCKET_SIZE] = DEFAULT_CONCURRENCY_HIST_BUCKET_SIZE;
   hist_args[CONCURRENCY][SUPPRESS_ZERO] =
					 DEFAULT_CONCURRENCY_HIST_SUPPRESS_ZERO;

   hist_args[RSP_XPUT][TIME_INTERVAL] = DEFAULT_RSP_HIST_BUCKET_SIZE;
   hist_args[RSP_XPUT][BUCKET_SIZE]=DEFAULT_RSP_XPUT_BUCKET_SIZE;
   hist_args[RSP_XPUT][SUPPRESS_ZERO]=DEFAULT_RSP_XPUT_SUPPRESS_ZERO;

   hist_args[RSP_CONCURRENCY][TIME_INTERVAL] = DEFAULT_RSP_HIST_BUCKET_SIZE;
   hist_args[RSP_CONCURRENCY][BUCKET_SIZE] = 
					DEFAULT_RSP_CONCURRENCY_BUCKET_SIZE;
   hist_args[RSP_CONCURRENCY][SUPPRESS_ZERO] =
					DEFAULT_RSP_CONCURRENCY_SUPPRESS_ZERO;

   hist_args[TIME][TIME_INTERVAL] = DEFAULT_TIME_BUCKET_SIZE;
   hist_args[TIME][BUCKET_SIZE]   = DEFAULT_TIME_BUCKET_SIZE;
   hist_args[TIME][SUPPRESS_ZERO] = DEFAULT_TIME_SUPPRESS_ZERO;

  /*--------------------------------------------------------------------
   * Post-conditions
   *--------------------------------------------------------------------*/
   assert(!errno);
}						/* init_hist_args() */

/***********************************************************************
 * dump_hist_args
 ***********************************************************************/
static void dump_hist_args( float hist_args[NUM_CHARTS][NUM_CHART_PARMS],
			    FILE *logptr)
{
  /*--------------------------------------------------------------------
   * Pre-conditions
   *--------------------------------------------------------------------*/
   assert(!errno);
   if (!hist_args) 
      BAD_ARG_PTR(hist_args,"hist_args","dump_hist_args","hist_args!=NULL");
  /*--------------------------------------------------------------------*/

   fprintf (logptr, "\nHistogram Parameters:\n");
   fprintf(logptr, "response_time_hist=[%12.6f,%12.6f,%12.0f]\n",
      hist_args[RSP_TIME][TIME_INTERVAL],
      hist_args[RSP_TIME][BUCKET_SIZE],hist_args[RSP_TIME][SUPPRESS_ZERO]);
   fprintf(logptr, "xput_hist=         [%12.6f,%12.6f,%12.0f]\n",
      hist_args[XPUT][TIME_INTERVAL],
      hist_args[XPUT][BUCKET_SIZE],hist_args[XPUT][SUPPRESS_ZERO]);
   fprintf(logptr, "concurrency_hist=  [%12.6f,%12.6f,%12.0f]\n",
      hist_args[CONCURRENCY][TIME_INTERVAL],
      hist_args[CONCURRENCY][BUCKET_SIZE],
      hist_args[CONCURRENCY][SUPPRESS_ZERO]);
   fprintf(logptr, "rsp_xput=          [%12.6f,%12.6f,%12.0f]\n",
      hist_args[RSP_XPUT][TIME_INTERVAL],
      hist_args[RSP_XPUT][TIME_INTERVAL],
      hist_args[RSP_XPUT][SUPPRESS_ZERO]);
   fprintf(logptr, "rsp_concurrency=   [%12.6f,%12.6f,%12.0f]\n",
      hist_args[RSP_CONCURRENCY][TIME_INTERVAL],
      hist_args[RSP_CONCURRENCY][BUCKET_SIZE],
      hist_args[RSP_CONCURRENCY][SUPPRESS_ZERO]);
   fprintf(logptr, "time_line=         [%12.6f,%12.6f,%12.0f]\n",
      hist_args[TIME][TIME_INTERVAL],
      hist_args[TIME][BUCKET_SIZE],
      hist_args[TIME][SUPPRESS_ZERO]);
   fprintf (logptr, "\n");

  /*--------------------------------------------------------------------
   * Post-conditions
   *--------------------------------------------------------------------*/
   assert(!errno);
}						/* dump_hist_args() */

/***********************************************************************
 * parse_hist_args - parse command line "hist" args in the format of 
 *                   a bracket-encapsulated, comma separated, three 
 *                   element set of numbers. No spaces are tolerated;
 *                   however, fields can be empty (e.g. consecutive
 *                   commas).
 *    format:
 *     [time_interval,bucket_size,suppress_flag]
 *
 *    regular expression syntax:
 *		([\d\.]*,[\d\.]*,[01])
 * 
 *    Functions such as strtok() have warnings emblazened upon their 
 *    manpages to not use them. Regex will do pattern matching, but will
 *    not conveniently return values from an expression ala PERL. Hence
 *    the necessity of a home-grown parsing routine here.
 *
 *    The function atof() will begin parsing at the address provided and stop 
 *    when it encounters '\0' or some character than cannot be part of a 
 *    floating point number; no need to right trim prior to passing strings 
 *    to atof() for translation.
 *
 ***********************************************************************/
static void parse_hist_args( float hist_args[NUM_CHARTS][NUM_CHART_PARMS], 
			     char *s, hist_t chart, char *hist_name )
{

   float time_interval = -1;   /* time-bucket size interval size */
   float bucket_size   = -1;   /* bucket size for non-time metrics */
   float suppress      =  0;   /* suppress empty buckets? */

   char *comma0;               /* location of commas in string */
   char *comma1;
   char *comma2;
   char *t, *e;			/* ptrs to '[' and ']', respectively */
   char buffer[132];

  /*--------------------------------------------------------------------
   * Pre-conditions
   *--------------------------------------------------------------------*/
   assert(!errno);
   if (!hist_args) BAD_ARG_PTR(hist_args,"hist_args","parse_hist_args",
		               "hist_args!=NULL");
   if (!s) BAD_ARG_PTR(s,"s","parse_hist_args", "s!=NULL");
   if (!hist_name) BAD_ARG_PTR(hist_name, "hist_name", "parse_hist_args", 
                    "hist_name!=NULL");
  /*--------------------------------------------------------------------*/

   /* arg should contain '[' and ']' */
   if ( !(t=index(s,'[')) || !(e=rindex(s,']')) ) {
      fprintf(stderr,"missing delimiters '[',']'\n");
      BAD_HIST_ARG(s);
   } 						/* if '[',']' */

   /* '[' should precede ']' */
   if ( ! ( t<e ) ) {
      fprintf(stderr,"\n\tInvalid arg: ']' is before '[' in \"%s\"\n",s);
      BAD_HIST_ARG(s);
   }

   /* confirm value component of string is not quasi-empty */
   if (strlen(t) < 5) {
      fprintf(stderr, 
         "Histogram argument for %s is too short, does not contain the",
         hist_name);
      fprintf(stderr, " necessary ingredients of at least \"[,,,]\"\n");
      BAD_HIST_ARG(s);
   }

   /* locate commas and verify correct number are present */
   if ((comma0 = index(t,',')) ) 
      if ((comma1 = index(&t[(int)(comma0-t)+1],',') ))
         comma2 = index(&t[(int)(comma1-t)+1],','); /*should be no 2nd ',' */

   if ( !(comma0 && comma1 && !comma2) ) {
      fprintf(stderr, "Invalid number of commas in histogram argument %s\n",
      hist_name);
      BAD_HIST_ARG(s);
   }						/* if commas found */

   /* extract numerical values between commas */
     
   if (contains_digit(&t[1],comma0)) {
      strcpy(buffer, &t[1]); 
      time_interval = (float)atof(buffer);

      if ( time_interval < FLT_EPSILON ) {
         fprintf(stderr, "Invalid time_interval for histogram %s: %f\n",
            hist_name, time_interval); 
         BAD_HIST_ARG(s);
      }						/* if bucket_size valid */

      hist_args[chart][TIME_INTERVAL] = time_interval;/* set in arg array */
   }						/* if bucket_size digits found*/

   if (contains_digit(comma0,comma1)) {
      strcpy(buffer,++comma0); 
      bucket_size = (float)atof(buffer);

      if ( bucket_size < FLT_EPSILON ) {
         fprintf(stderr, "Invalid bucket size for histogram %s: %f\n",
            hist_name, bucket_size); 
         BAD_HIST_ARG(s);
      }						/* if bucket_size valid */

      hist_args[chart][BUCKET_SIZE] = bucket_size; /* set in arg array */
   }						 /*if bucket_size digits found*/

   if (contains_digit(comma0,index(t,']'))) {
      strcpy(buffer, ++comma1);
      suppress = (float) ((uint)atof(buffer));

      if ( (!(fabs(suppress - 0.0)<FLT_EPSILON)) && 
           (!(fabs(suppress - 1.0)<FLT_EPSILON))) {
         fprintf(stderr, 
            "Invalid suppress_empty_bucket flag for histogram %s: %f\n",
            hist_name, suppress);
         BAD_HIST_ARG(s);
      }                                         /* if bucket_size valid */

      hist_args[chart][SUPPRESS_ZERO] = suppress; /* note option in arg array */
   }						/* if suppress digits found */

#ifdef DEBUG
   printf("time_interval=%f bucket_size=%f suppress=%f errno=%d\n", 
         time_interval, bucket_size, suppress, errno);
   printf("parse_hist_args() returns OK\n");
#endif

  /*--------------------------------------------------------------------
   * Post-conditions
   *--------------------------------------------------------------------*/
   assert(!errno); 
  /*--------------------------------------------------------------------*/
}						/* parse_hist_args() */

/***********************************************************************
 * allocate_shm() - allocate shared memory segment for metrics and attach
 *                  to the new segment. This routine is invoked from 
 *                  thruput() and replay().
 *
 *                  Note that metrics_shmid and shm_allocated are 
 *                  necessarily global variables. They must be so to 
 *                  provide visibility to signal handlers.
 ***********************************************************************/
struct metrics_rec *allocate_shm( size_t size )
{
   struct metrics_rec *metrics;   /* ptr to shared mem seg; this is the retval*/

  /*--------------------------------------------------------------------
   * Pre-conditions
   *--------------------------------------------------------------------*/
   assert(!errno);
   if (!size) BAD_ARG_UINT(size,"size","allocate_shm","size!=0");
  /*--------------------------------------------------------------------*/
  if ((metrics_shmid = shmget(IPC_PRIVATE, (size_t)size ,00666)) == -1){
      perror("shmget() for metrics array failed\n");
      fprintf(stderr,
         "Try: 1) Increase upper bound of Shared Memory Segment Size.\n");
      fprintf(stderr,
         "        This is typically a kernel parameter change.\n");
      fprintf(stderr,
         "     2) Check swap space - if this is exhausted, then there\n");
      fprintf(stderr,
         "        will not be virtual memory available to allocate\n\n");
      fprintf(stderr,
         "        Specifically, errno=%d\n",errno);
      exit( EXIT_SHARED_MEM_ERROR );
   }                                                    /* if */

   /* attach to the shared memory segment for metrics */
   if ((metrics = (struct metrics_rec *)shmat( metrics_shmid, NULL, 0777 )) ==
                (struct metrics_rec *)-1) {
      perror("shmat failed");
      terminate( EXIT_SHARED_MEM_ERROR );
   }                                                    /* if shmat */

  /*--------------------------------------------------------------------
   * Post-conditions
   *--------------------------------------------------------------------*/
   assert(!errno); 
  /*--------------------------------------------------------------------*/
   return( metrics );
}							/* allocate_shm() */

/***********************************************************************
 * contains_digit() - scan a set of characters from a start addr to end 
 *                    addr or '\0' is encountered. If a digit is 
 *                    encountered, then return 1 - this is likely a 
 *                    floating point number; at least it is not empty.
 *
 *                    Return 0 if no digit found.
 ***********************************************************************/
static uint contains_digit( char *start, char *end )
{
    char *ptr;

  /*--------------------------------------------------------------------
   * Pre-conditions
   *--------------------------------------------------------------------*/
   assert(!errno);
   if (!start) BAD_ARG_PTR(start,"start","contains_digit","start!=NULL");
   if (!end)   BAD_ARG_PTR(end,"end","contains_digit","end!=NULL");
  /*--------------------------------------------------------------------*/

    for ( ptr=start ; *ptr && ptr<end ; ptr++ )
       if ( isdigit(*ptr) ) return(1); /* a-ha: found a digit; return 1 */

   return( 0 );			/* no digit found if this point reached*/
}					/* contains_digit() */

/***********************************************************************
 * terminate() -  Should this benchmark abort or be interrupted, the 
 *                shared memory segment used to store the collected 
 *                metrics would linger. Care needs to be taken to clean
 *                up after a run, else subsequent runs might not be able
 *                to allocate shared memory segments.
 ***********************************************************************/
void terminate(uint exit_value)
{
   if (metrics_shmid && shmctl( metrics_shmid, IPC_RMID, NULL) ) {
      /* 
       * EINVAL is possible if both aborting child and parent attempt
       * to free the shared memory segment - this is ok.
       */
      if ( errno != EINVAL )
         perror(
           "shmctl to free shared memory for metrics failed; check \"ipcs -am\"");
   }							/* if shmctl() */

   if (replay_shmid && shmctl( replay_shmid, IPC_RMID, NULL) ) {
      /* 
       * EINVAL is possible if both aborting child and parent attempt
       * to free the shared memory segment - this is ok.
       */
      if ( errno != EINVAL )
         perror(
          "shmctl to free shared memory for replay failed; check \"ipcs -am\"");
   }							/* if shmctl() */

   if ( exit_value == EXIT_NORMAL_TERMINATION ) {
      printf("\nNormal Termination\n");
   } else {
      if ( (exit_value != EXIT_BAD_COMMAND_LINE_ARG) &&
	   (exit_value != EXIT_BAD_USAGE) ) {
         fprintf(stderr, 
          "Abended: Check exit status and log file for details of issue(s)\n");
         fprintf(stderr,
          "Manpage will contain details regarding exit status\n");

         fprintf(stderr,"\nExit status summary:\n\tExit Code: %u\n\n",
            exit_value);
         switch(exit_value) {
            case EXIT_BAD_USAGE: 
                    fprintf(stderr,"BAD_USAGE: Command line arg provided "); 
                    fprintf(stderr,"did not match any that were expected\n");
                    fprintf(stderr,"Check for arg misspelling\n");
                    break;

            case EXIT_MALLOC_FAILURE: 
                    fprintf(stderr,"MALLOC_FAILURE: could not allocate ");
                    fprintf(stderr,"requested amount of dynamically\n");
                    fprintf(stderr,"allocated RAM - check swap system ");
                    fprintf(stderr," space and process limits\n"); 
                    break;

            case EXIT_BAD_ARG_FAILURE: 
                    fprintf(stderr,"BAD_ARG_FAILURE: args supplied to a ");
                    fprintf(stderr,"function were outside of valid range\n"); 
                    break;

            case EXIT_BAD_COMMAND_LINE_ARG: 
                    fprintf(stderr,"BAD_COMMAND_LINE_ARG: Invalid command ");
                    fprintf(stderr,"line arg given at bertha invocation\n"); 
                    break;

            case EXIT_FREE_SHM_FAILURE: 
                    fprintf(stderr,"FREE_SHM_FAILURE: failure during "); 
                    fprintf(stderr,"deallocation of dynamically allocated\n");
                    fprintf(stderr,"memory. This can happen if some access ");
                    fprintf(stderr,"beyond the bounds of the dynamically\n");
                    fprintf(stderr,"memory occurred, thereby corrupting ");
                    fprintf(stderr,"the heap.\n");
                    break;

            case EXIT_FORCIBLE_TERMINATION: 
                    fprintf(stderr,"FORCIBLE_TERMINATION: signal sent to "); 
                    fprintf(stderr,"bertha to terminate execution\n");
                    break;

            case EXIT_SHARED_MEM_ERROR: 
                    fprintf(stderr,"SHARED_MEM_ERROR: Could not perform "); 
                    fprintf(stderr,"shared memory operation such as\n");
                    fprintf(stderr,"shmget(2), shmat(2), shmdt(2), or ");
                    fprintf(stderr," shmctl(2)\n");
                    break;

            case EXIT_BAD_HIST_ARG: 
                    fprintf(stderr,"BAD_HIST_ARG: Invalid time interval,, "); 
                    fprintf(stderr,"bucket_size, or suppress_zero_flag\n");
                    fprintf(stderr,"supplied in command line args and ");
                    fprintf(stderr,"could not be deciphered\n");
                    break;

            case EXIT_ARRAY_BOUNDS_EXCEEDED: 
                    fprintf(stderr,"ARRAY_BOUNDS_EXCEEDED: Attempt to address");
                    fprintf(stderr," beyond array bounds in assembling\n");
                    fprintf(stderr,"reports\n");
                    break;

            case EXIT_BOGUS_VALUE_COMPUTED: 
                    fprintf(stderr,"BOGUS_VALUE_COMPUTED: Unexpected value "); 
                    fprintf(stderr,"computed in assembling reports\n");
                    break;

            case EXIT_MEMSET_FAILURE: 
                    fprintf(stderr,"MEMSET_FAILURE: attempted to initialize "); 
                    fprintf(stderr,"dynamically allocated memory but failed\n");
                    break;

            case EXIT_IO_ERROR: 
                    fprintf(stderr,"IO_ERROR: Error performing read(2), "); 
                    fprintf(stderr,"write(2), lseek(2), fclose(2) or\n");
                    fprintf(stderr,"unlink(2)\n");
                    break;

            case EXIT_USLEEP_ERROR: 
                    fprintf(stderr,"USLEEP_ERROR: usleep() returned an "); 
                    fprintf(stderr,"error when attempting to delay after\n");
                    fprintf(stderr,"replay transaction. Check syntax and ");
                    fprintf(stderr,"values in tracefile\n"); 
                    break;

            case EXIT_INVALID_TRACEFILE_INPUT: 
                    fprintf(stderr,"INVALID_TRACEFILE_INPUT: Syntax error "); 
                    fprintf(stderr,"found in tracefile input\n");
                    break;

            case EXIT_REPORT_CREATION_ERROR: 
                    fprintf(stderr,"REPORT_CREATION_ERROR: Could not create "); 
                    fprintf(stderr,"report file; check for:\n");
                    fprintf(stderr,"1. existing report files\n");
                    fprintf(stderr,"   of the same name as specified that\n");
                    fprintf(stderr,"   already exist and have different \n");
                    fprintf(stderr,"   owner or incompatible permissions\n");
                    fprintf(stderr,"2. the path exists\n");
                    break;

            case EXIT_INSUFFICIENT_REPLAY_TRANSACTIONS: 
                    fprintf(stderr,"INSUFFICIENT_REPLAY_TRANSACTIONS: "); 
                    fprintf(stderr,"More concurrent processes exist than\n");
                    fprintf(stderr,"transactions to replay; there must be ");
                    fprintf(stderr,"least one transaction per concurrent\n");
                    fprintf(stderr,"process.\n");
                    break;

            case EXIT_LOG_FILE_ERROR: 
                    fprintf(stderr,"LOG_FILE_ERROR: Could not create "); 
                    fprintf(stderr,"log file; check for:\n");
                    fprintf(stderr,"1. existing log files\n");
                    fprintf(stderr,"   of the same name as specified that ");
                    fprintf(stderr,"   already exist and have different \n");
                    fprintf(stderr,"   owner or incompatible permissions\n");
                    fprintf(stderr,"2. the path exists\n");
                    break;

            case EXIT_REPLAY_FILESIZE_ERROR: 
                    fprintf(stderr,"REPLAY_FILESIZE_ERROR: When attempting "); 
                    fprintf(stderr,"to perform a replay test, the first \n");
                    fprintf(stderr,"line of the tracefile should contain the ");
                    fprintf(stderr,"max block address for the transactions\n");
                    fprintf(stderr," described in the tracefile. This value ");
                    fprintf(stderr,"was unreadable. Note that this is not\n");
                    fprintf(stderr,"the maximum start address for ");
                    fprintf(stderr,"transactions, but the maximum block\n"); 
                    fprintf(stderr,"will be accessed during the replay test ");
                    fprintf(stderr,"(start addr + trans length)\n");
                    break;

            case EXIT_BAD_STRING: 
                    fprintf(stderr,"BAD_STRING: snprintf() failed when "); 
                    fprintf(stderr,"constructing string (e.g. log\n"); 
                    fprintf(stderr,"filename, report filename, etc.\n");
                    break;

            case EXIT_GETTIME_ERROR: 
                    fprintf(stderr,"GETTIME_ERROR: could not capture and \n"); 
                    fprintf(stderr,"store current or consumed CPU time\n");
                    break;

            case EXIT_BAD_FORK:
                    fprintf(stderr,"BAD_FORK: could not fork(2) concurrent ");
                    fprintf(stderr,"process; check system swap space\n");
                    break;

            case EXIT_BAD_REPLAY_FILE:
                    fprintf(stderr,"BAD_REPLAY_FILE: could not open ");
                    fprintf(stderr,"specified tracefile\n");
                    break;

            case EXIT_SCRATCH_FILE_TOO_LARGE:
                    fprintf(stderr,"SCRATCH_FILE_TOO_LARGE: scratch file too ");
                    fprintf(stderr,"large for filesystem. Try remounting \n");
                    fprintf(stderr,"file system with appropriate ");
		    fprintf(stderr,"'largefiles' options\n");
                    break;

            default: 
                    fprintf(stderr, "Invalid exit value\n");
         }					/* switch */
      }						/* if !usage issue */
   }						/* if !NORMAL_TERMINATION */

   (void)fclose(logptr);	
   exit( (int)exit_value );
}							/* terminate() */

/***********************************************************************
 * sighandler() - Should this benchmark abort or be interrupted, the 
 *    shared memory segment used to store the collected metrics would linger. 
 *    Care needs to be taken to clean up after a run, else subsequent runs 
 *    might not be able to allocate shared memory segments.
 ***********************************************************************/
void sighandler(char *sig)
{
   fprintf(stderr, "\n*** ABEND: %s ***\n", sig);
   fprintf(stderr, "Signal handler invoked to remove shared mem segments.\n");
   fprintf(stderr,"Removing: metrics_shmid=%d replay_shmid=%d\nerrno=%d\n\n", 
      metrics_shmid, replay_shmid, errno);
   if (errno) perror("error at termination: ");
   
   /* clean up: remove the shared memory segment for metrics */
   terminate( EXIT_FORCIBLE_TERMINATION );
}							/* sighandler() */

/************************************************************************
 * Specific signal handlers - call generic routine and communicate 
 * which signal occurred.
 ************************************************************************/
sighandler_t sighandler_INT()    {sighandler("SIGINT");}
sighandler_t sighandler_QUIT()   {sighandler("SIGQUIT");}
sighandler_t sighandler_ABRT()   {sighandler("SIGABRT");}
sighandler_t sighandler_BUS()    {sighandler("SIGBUS");}
sighandler_t sighandler_SEGV()   {sighandler("SIGSEGV");}
sighandler_t sighandler_TERM()   {sighandler("SIGTERM");}
sighandler_t sighandler_STKFLT() {sighandler("SIGSTKFLT");}
