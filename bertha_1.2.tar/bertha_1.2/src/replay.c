/***************************************************************************
 * replay.c - perform a set of prescribed read/write operations, possibly
 *            captured from an actual application or a simulation, to mimic 
 *            production workload.
 *
 *-------------------------------------------------------------------------
 * Copyright 2006, Dave Wagoner
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *-------------------------------------------------------------------------
 *
 ***************************************************************************/

/*-------------------------------------------------------------------- 
 * header files
 *-------------------------------------------------------------------*/
#include "./bertha.h"

/*-------------------------------------------------------------------- 
 * prototypes for functions visible only to this compilation unit
 *-------------------------------------------------------------------*/
static void my_mkfile(uint fsize, char *filename, FILE *logptr);

/*************************************************************************
 * replay() - replay a set of I/O transactions as specified in a datafile
 *************************************************************************/
void replay(uint nprocs, 
	    double fsize, 
            uint  verbose, 
            uint  num_dirs, 
            char  dir[MAX_NPROCS][MAX_DIRNAME_LEN], 
            char *rptdir,  
            char *testname, 
            char  replay_file[MAX_REPLAYNAME_LEN], 
            uint  replay_mono_file_flag, 
            uint  replay_scale_io_size_flag,
            float hist_args[NUM_CHARTS][NUM_CHART_PARMS], 
            uint  dump_raw_metrics_flag, 
            uint  metrics_by_proc_flag,
            uint  reports_requested[NUM_REPORT_TYPES],
            uint  record_flag, /* store raw data for potential rereporting */  
            FILE *logptr)
{
#define IO_BUFF_INIT_STR_SIZE 10

   uint      p, p0; 		/* loop counters */
   uint      i;			/* loop counter */
   uint      j;			/* loop counter */
   ulong     trace_addr;	/* byte address on which to perform I/O */
   uint      trace_len;		/* length of data, in bytes, to I/O */
   char      trace_op[2];	/* op to do "r"=read, "w"=write */
   float     trace_post_io_delay; /* "think time" between I/Os */
   char      name[MAX_NPROCS][MAX_SCRATCHNAME_LEN];  /* unique 
   				         * filename for process to use
					 */
   char      err_msg[MAX_SCRATCHNAME_LEN + 32];
   char      tname[MAX_SCRATCHNAME_LEN]; /* temp variable to load name[][] */
   int       fd  = -1; 		/* file descriptor to scratch file */
   FILE     *fp;		/* file pointer to scratch file */
   uint      replay_recs   = 0; /* number of transactions to replay */
   char     *mbuff;		/* pointer to shared memory area - this
   				 * is the base address to an array of 
				 * transaction records (trans_rec)
				 */
   struct trans_rec *recs;	/* pointer to base of array (will 
   				 * contain the same address as mbuff,
				 * but set to an appropriate type so 
				 * array elements can easily be 
				 * addressed */
   float     scale;
   ulong replay_datafile_size; /* size of real "production" data */
   ulong replay_read_bytes = 0, replay_write_bytes = 0;
   ulong replay_read_ops   = 0, replay_write_ops   = 0;
   char              buff[MAX_REPLAY_IOP_SIZE];
   int               retval;
   int               usleep_retval;
   int               status;		/* status from waitpid; unused */
   double            delta[NTESTS][2];  /* array of DeltaT values */
   size_t 	     io_bytes;		/* number of bytes to move on I/O */
   int    	     child[MAX_NPROCS];	/* retval after fork(2)ing */
   uint              concurrent_nprocs;	/* account for replay file access */
   double io_start_time, io_end_time;

   /*
    *  Housekeeping variables to build up sample_timess for the tests;
    */
   double  last_cpu_time     = 0.0; /* for computing delta-t */
   double  last_elapsed_time = 0.0; /* for computing delta-t */
   char    test_timestamp[MAX_TSTAMP_STR_SIZE]; /* txt vrsion of time 
						  * @ test start */
   ulong   basetime_ulong;          /* format of timestamp for ctime() */
   ulong   m_index;                 /* index into metrics[] */
   ssize_t bytes_written = -1;	    /* #bytes written in replay IOP */
   ssize_t bytes_read    = -1;	    /* #bytes read    in replay IOP */
   off_t   lseek_offset  = -1;	    /* retval from lseek(2) */
   int     vals_scanned;	    /* #vals read on one line of replay file */

   struct  metrics_rec *metrics;    /* array of structs for perf results */
   char s_ptr[IO_BUFF_INIT_STR_SIZE]; /* used to init I/O buff */

  /*------------------------------------------------------------------
   * Pre-conditions
   *------------------------------------------------------------------*/
   assert( !errno );
   if (!nprocs)   BAD_ARG_UINT(nprocs, "nprocs", "replay","nprocs>0");
   if (fsize<DBL_EPSILON) BAD_ARG_FLOAT(fsize,"fsize","replay","fsize>0.0");
   if (!num_dirs)  BAD_ARG_UINT(num_dirs,"num_dirs","replay","num_dirs>0");
   if (!dir)       BAD_ARG_PTR(dir,"dir","replay","dir!=NULL");
   if (!rptdir)    BAD_ARG_PTR(rptdir,"rptdir","replay","rptdir!=NULL");
   if (!testname)  BAD_ARG_PTR(testname,"testname","replay","testname!=NULL");

   if (!replay_file) 
      BAD_ARG_PTR(replay_file,"replay_file","replay","replay_file!=NULL");
   if (replay_mono_file_flag>1) 
      BAD_ARG_UINT(replay_mono_file_flag, "replay_mono_file_flag",
                   "replay","replay_mono_file_flag = {0,1}");   
   if (!hist_args) BAD_ARG_PTR(hist_args,"hist_args","replay",
                               "testname!=NULL");
   if (dump_raw_metrics_flag> 1)
      BAD_ARG_UINT(dump_raw_metrics_flag, "dump-raw_metrics_flag",
          "replay", "dump-raw_metrics_flag= {0 | 1}");
   if (metrics_by_proc_flag > 1)
      BAD_ARG_UINT(metrics_by_proc_flag, "metrics_by_proc_flag",
          "replay", "metrics_by_proc_flag = {0 | 1}");
   if (!reports_requested)
      BAD_ARG_PTR(reports_requested,"reports_requested",
                  "replay","reports_requested!=NULL");
   if (!logptr)   BAD_ARG_PTR(logptr,"logptr","replay","logptr!=NULL");
  /*------------------------------------------------------------------*/

   /* record start time of run; subsequent times are relative to this */
   basetime_ulong = (ulong)basetime;
   strcpy( test_timestamp, ctime( (const time_t *)&basetime_ulong ));
   assert( (strlen(test_timestamp) <= MAX_TSTAMP_STR_SIZE) && 
           (strlen(test_timestamp) > 1));

   /* remove embedded '/n' from test_timestamp */
   test_timestamp[strlen(test_timestamp)-1] = '\0';

   /* seed random number generator; random numbers used to dirty write buffer */
   srandom(time(NULL));

   /*
    * account for the I/O concurrency option in the final stats. If 
    * replay_mono_file_flag set, then the IOPs in the transaction file
    * are performed once, with the concurrent processes each performing some
    * approximately equal number of transactions; the IOPs for all concurrent
    * processes will be performed on the same scratch file (i.e. the scratch 
    * file is shared).  If the flag is not set, then each process will perform 
    * all of the transactions on its own respective file.
    */
   if ( replay_mono_file_flag ) concurrent_nprocs = 1;
   else                         concurrent_nprocs = nprocs;

   /*-------------------------------------------------------------------------
    * read in the datafile
    *
    * First line contains the file size in bytes; each subsequent line 
    * contains an address, a number of bytes to be read/written, and a single 
    * character of either "r" or "w" to specify a read or a write operation.
    *-------------------------------------------------------------------------*/
   if ((fp = fopen(replay_file,"r")) == NULL ) {
      fprintf(logptr,"Can't open replay file \"%s\"\n",replay_file);
      terminate(EXIT_BAD_REPLAY_FILE);
   }						/* if fopen() */

  /* 
   * count the number of replay_recs in the file to know how big of a 
   * shared memory segment is needed
   */

   if ( fscanf(fp,"%lu",&replay_datafile_size) != 1 ) {
      fprintf(logptr, "Error reading file size (first line) of replay file\n");
      terminate( EXIT_REPLAY_FILESIZE_ERROR );
   }

   /*
    * verify replay_datafile_size is valid and content is reasonable
    */
   if ( replay_datafile_size > MAX_REPLAY_DATAFILE_SIZE ) {
      fprintf(logptr,
         "%s specifies a datafile size of %lu; ", 
         replay_file, replay_datafile_size);
      fprintf(logptr, "this exceeds the max of %lu bytes\n",
	 (ulong)MAX_REPLAY_DATAFILE_SIZE);
      terminate( EXIT_INVALID_TRACEFILE_INPUT );
   }						/* if replay_datafile_size */

  /*-------------------------------------------------------------------------
   *  Find scaling factor for replay file to test file. The transactions 
   *  being replayed are presumed to either have been captured from an actual
   *  production system or are part of a simulation. In either case, the 
   *  size of the scratch file may not match the size of the I/O area of the
   *  production system or the simulation. The scaling factor is applied to 
   *  the target address to map I/Os to a position in the scratch file that 
   *  proportionally corresponds to the target address in the production 
   *  file or simulation. The access pattern is presevered in this manner.
   *  Note that the seek location is scaled, but the amount of data is not 
   *  necessarily scaled. A flag, replay_scale_io_size_flag, must be set for 
   *  scaling of IOP lengths to take place. On extremely small datafiles, 
   *  the flag should be set else the particular benchmark attempted may not
   *  be useful. 
   *
   *  Size is passed to replay in MB; need to convert to bytes (*1024*1024)
   *-------------------------------------------------------------------------*/
   scale = (float)((fsize * MBYTE) / replay_datafile_size);
   fprintf(logptr,
      "fsize=%lu MB replay_datafile_size=%lu bytes (%16.6f MB), scale=%lf\n",
      (off_t)fsize, replay_datafile_size, 
      (double)replay_datafile_size/MBYTE, scale);

   while ((vals_scanned = 
              fscanf(fp,"%lu %u %s %f\n", &trace_addr, &trace_len, 
                     trace_op, &trace_post_io_delay)) !=EOF) {

      replay_recs++;		/* increment count of transaction records */

      if ( vals_scanned != 4) {
         fprintf(logptr, "Invalid number of values found in replay file %s ",
		replay_file);
         fprintf(logptr, "line number: %u\n", replay_recs);
         terminate(EXIT_INVALID_TRACEFILE_INPUT);
      }						/* if vals_scanned */

      if (strlen(trace_op) > sizeof(trace_op)) {
         fprintf(logptr,"bertha: op string too long: \"%s\"\n",trace_op);
	 fprintf(logptr,"IOP near tracefile line %u\n", replay_recs);
         terminate(EXIT_INVALID_TRACEFILE_INPUT);
      }						/* if strlen(op) */

      if (trace_post_io_delay < (float)((-1.0)*(FLT_EPSILON))) {
         fprintf(logptr,"bertha: invalid delay period between I/Os: \"%f\"\n",
		trace_post_io_delay);
	 fprintf(logptr,"IOP near tracefile line %u\n", replay_recs);
	 terminate( EXIT_INVALID_TRACEFILE_INPUT );
      }						/* if invalid post_io_delay */

      if (trace_addr > replay_datafile_size ) {
         fprintf(logptr,
            "replay transaction starts beyond end of scratch file\n");
	 fprintf(logptr,"%lu specified, but max address defined as %lu\n",
	    trace_addr, replay_datafile_size);
	 terminate( EXIT_INVALID_TRACEFILE_INPUT );
      }						/* if invalid address value */

      if (!trace_len) {
         fprintf(logptr,"Replay data invalid IOP length: %u\n", trace_len);
	 fprintf(logptr,"Zero-byte IOPs not tolerated\n");
	 fprintf(logptr,"IOP near tracefile line %u\n", replay_recs);
	 terminate( EXIT_INVALID_TRACEFILE_INPUT );
      }						/* if invalid length value */

      if (trace_len > MAX_REPLAY_IOP_SIZE ) {
         fprintf(logptr,"Replay data invalid IOP length: %u\n", trace_len);
	 fprintf(logptr,"This is greater than the max IOP length of %u\n",
                  MAX_REPLAY_IOP_SIZE);
	 fprintf(logptr,"IOP near tracefile line %u\n", replay_recs);
	 terminate( EXIT_INVALID_TRACEFILE_INPUT );
      }						/* if invalid length value */

      if ((trace_addr + trace_len) > replay_datafile_size ) {
         fprintf(logptr,"Replay data invalid IOP length: %u\n", trace_len);
	 fprintf(logptr,"Starting from address %lu, the end of the IOP\n",
                 trace_addr);
         fprintf(logptr,"will exceed end of file of length %lu bytes\n",
		 replay_datafile_size);
	 fprintf(logptr,"IOP near tracefile line %u\n", replay_recs);
	 terminate( EXIT_INVALID_TRACEFILE_INPUT );
      }						/* if invalid length value */

     /* 
      * scale number of bytes for this IOP if necessary
      */
      if ( replay_scale_io_size_flag ) 
         io_bytes = (size_t)(scale*trace_len); 
      else 
         io_bytes = (size_t)(trace_len); 

     /* 
      * Total # bytes to read/written; cannot do this from child processes
      * unless shared memory/pipe/msgs etc. used - must do this in parent.
      *
      * This also verifies that the op is either "r" or "w" (i.e. is valid)
      */
      if        (!strncmp(trace_op,"r",1)) {
         replay_read_bytes += io_bytes;
         replay_read_ops++;
      } else if (!strncmp(trace_op,"w",1)) {
         replay_write_bytes += io_bytes;
         replay_write_ops++;
      } else {
         fprintf(logptr,
            "bertha: op string must be either \"r\" or \"w\"; found \"%s\"\n",
             trace_op);
         terminate(EXIT_INVALID_TRACEFILE_INPUT);
      }							/* else !"r" && !"w" */
   }							/* while fscanf() */
   /* allocate a shared memory segment and load it with the transaction data */
   if ((replay_shmid = 
           shmget(IPC_PRIVATE, (size_t)(sizeof(trans_rec)*replay_recs), 00666)) 
         == -1){
      perror("shmget failed");
      terminate( EXIT_SHARED_MEM_ERROR );
   }							/* if */

   /*
    * attach to the shared memory segment; set the base of the 
    * array of transaction records to the shared memory segment
    */
   if ((mbuff = shmat( replay_shmid, NULL, 0777 )) == (char *)-1) {
      perror("shmat failed");
      terminate( EXIT_SHARED_MEM_ERROR );
   }						/* if shmat() */
   recs = (struct trans_rec *)mbuff;

   /* 
    * rewind to the beginning of the file
    */
   if (fseek(fp, 0, SEEK_SET)) {    	            /* rewind to beginning */
      fprintf(logptr,"fseek() failed\n");
      io_error( "replay(): fseek() failed\n");
   }						    /* if fseek() */

  /* 
   * read in the transaction data from the file and store in the
   * shared memory segment. The transactions have been scanned once for 
   * "syntax", so the return values from fscanf() need not be checked again
   */
   replay_recs = 0;
   (void)fscanf(fp,"%lu",&replay_datafile_size); /* value already verified */ 
   while (fscanf(fp,"%lu %u %s %f\n", 
   	   &recs[replay_recs].addr, &recs[replay_recs].len, 
	    recs[replay_recs].op, &recs[replay_recs].post_io_delay ) != EOF) {
      replay_recs++;
   }							/* while */
   (void)fclose(fp);

   /*
    * if concurrent processes are to perform I/O on a single file and are 
    * sharing the transactions, there should be at least one IOP per 
    * concurrent process
    */
   if ( replay_mono_file_flag && !(replay_recs / nprocs) ) {
      fprintf(logptr, "Too few transactions per concurrent process;\n");
      fprintf(logptr, "Transactions: %lu  Number of concurrent processes: %u\n",
			replay_recs, nprocs);
      terminate( EXIT_INSUFFICIENT_REPLAY_TRANSACTIONS );
   }

   /*
    *  Allocate shared memory segment for performance metrics and attach to it.
    */
   metrics = allocate_shm( (size_t)(sizeof(struct metrics_rec)) 
                           * concurrent_nprocs * replay_recs);
 
   init_metrics(metrics, concurrent_nprocs, replay_recs, logptr);

   /*---------------------------------------------------------------
    * Choose filenames for each concurrent process
    * and create the files thru a standard interface.
    *
    * If the replay_mono_file_flag is not set, then one file per child
    * process will be used for the replay. If the flag is indeed set,
    * then there will be but one transaction file that every child
    * process uses, where each process performs a subset of
    * the total set of transactions. 
    *
    * Note that if the replay_mono_file_flag is set, then the one scratch file
    * is created here and all process will perform IOPs to the same scratch 
    * file. If replay_mono_file_flag is not set, then each child process 
    * will create its own scratch file after fork(2)ing.
    *---------------------------------------------------------------*/
   assert( !errno );
   if (verbose) MARK("Creating scratch file(s)", "initiated");

   if ( !replay_mono_file_flag ) {
      for (p=0; p<nprocs ; p++ ) {
         strncpy( name[p], dir[p % num_dirs], strlen(dir[p % num_dirs]));
         (void)snprintf( tname, 32, "/bertha_%u.dat", p);
         strncat( name[p], tname, strlen(tname) );
         assert(strlen(name[p]) < MAX_SCRATCHNAME_LEN);
   
         /* create a scratch file; convert size to MB */
         my_mkfile((uint)(fsize * MBYTE), name[p], logptr);
      }							/* for */
   } else {
         strncpy( name[0], dir[0], strlen(dir[0]));
         (void)snprintf( tname, 32, "/bertha_%d.dat", 0);
         strncat( name[0], tname, strlen(tname) );
         assert(strlen(name[0]) < MAX_SCRATCHNAME_LEN);
     
         /* create a scratch file; convert size to MB */
         my_mkfile((uint)(fsize * MBYTE), name[0], logptr);

         if (verbose) MARK("openfile", "initiated");
	 openfile(name[0], &fd, 0);
         if (verbose) MARK("openfile", "completed");

	 SYNC("openfile");
         assert( !errno );
   }
 
   if (verbose) MARK("Creating scratch files", "completed");

  /*---------------------------------------------------
   *  fork children to generate the I/O on the file
   *---------------------------------------------------*/
   for (p=0; p<nprocs; p++ ) {
      child[p] = 0;			    /* initialize out of paranoia */
      if ((child[p] = fork()) == -1) terminate(EXIT_BAD_FORK);
      else 
         if (child[p] == 0) {
            double start_time, stop_time;   /* only needed within child proc */
	    uint start_rec, stop_rec;

           /*
            * Init buffer with unique values, dependent on process number p. 
            * When IOPs are replayed, the blks written by each proc can be 
            * distinguised. If the content of the scratch file is to be 
            * verified, be sure to comment out unlink() below.
            */
            (void)snprintf(s_ptr,IO_BUFF_INIT_STR_SIZE,"%u ",p);
            buff[0]='\0';				  /* zero out buff */
            for (j=0; (int)j<(MAX_REPLAY_IOP_SIZE-strlen(s_ptr)) ; 
                                                              j+=strlen(s_ptr)) 
               strcat(&buff[j], s_ptr);

	    /*
	     * Recall that replay_mono_file_flag is set if all IOPs should 
             * occur on the same file rather than a seperate file for each 
             * child process.  If flag not set, then open a file for the 
             * child process; else determine the subset of transactions for 
             * this child process to replay. The file will have already been 
             * opened prior to forking when replay_mono_file_flag is set.
	     */
            if ( !replay_mono_file_flag ) {
	       openfile(name[p], &fd, 0);
	       start_rec = 0;
	       stop_rec = replay_recs;
               if (verbose)
	          fprintf(logptr, "Child %u start_rec=%u stop_rec=%u\n",
		  		p, start_rec, stop_rec);
	    } else {
	       start_rec = (p + 0) * (replay_recs / nprocs);

               /*
                * When attempting mono_file replay, the number of transactions
                * in the tracefile may not be an integral number of nprocs. 
                * In this case, allow the the last process to perform the 
                * remaining transactions rather than allowing them to go 
                * unperformed.
                */
               if (p < (nprocs - 1))
                  /* all but last process */
	          stop_rec = (p + 1) * (replay_recs / nprocs);
               else 
                  /* last process */
                  stop_rec = replay_recs; 

	       if (verbose) 
	          fprintf(logptr, 
              "Child %u start_rec=%u stop_rec=%u replay_recs=%u nprocs=%u\n",
		  		p, start_rec, stop_rec, replay_recs, nprocs);
            }					/* if */

            (void)sleep(SLEEP);   /* allow all child processes to be started */
           /*
            * Solaris alarms to terminate sleep state cause EINTR to be set;
            * this is quite reasonable (Linux does not do this). Reset errno
            * to allow assertions ( assert(!errno) ) to pass.
            */
            if (errno == EINTR) errno = 0;

            start_time = timestamp(basetime);

           /*
            * replay the transaction file
            */
            for ( i=start_rec; i<stop_rec ; i++ ) {
               if ( replay_scale_io_size_flag ) 
                  io_bytes = (size_t)(scale*recs[i].len); 
               else 
                  io_bytes = (size_t)(recs[i].len); 

              /*
               * Previous checks should prevent situations where 
               * all or part of an IOP go beyond the end of a file. During
               * coding changes, however, this issue may emerge again. Code
               * left in here to aid in problem prevention & detection.
               */
               if ( (ulong)(io_bytes + recs[i].addr*scale) > 
			(replay_datafile_size*MBYTE)) {
                  io_bytes = (size_t)(replay_datafile_size*MBYTE - 
                                                           recs[i].addr*scale);
                  assert(io_bytes>0);
               }

               /* IOP time must include seek time to be realistic */
               io_start_time = timestamp(basetime);

               /* move to a "scaled" location in the file */
	       if ((lseek_offset=lseek(fd,(off_t)(recs[i].addr*scale),0))==-1){
	          fprintf(logptr, 
                     "child %u: lseek to (transaction file byte addr)%lu-> ",
		       p, recs[i].addr);
                  fprintf(logptr,
                    "(scratch file byte addr)%lu (target location)%lu failed,",
	            (recs[i].addr*scale), recs[i].addr*scale);
                  fprintf(logptr,"errno=%d\n", errno);
	          perror("lseek failed");
	          io_error("replay(): lseek failed");
	       }						/* if */

	       if (verbose >= 2) { 
	          fprintf(logptr,
                        "process %u lseek to (trans file byte addr)%lu-> ",
			p, recs[i].addr);
                  fprintf(logptr,
                     "(maps to scratch file byte addr)%lu",
	                 (ulong)(recs[i].addr*scale)); 
                  fprintf(logptr, " for \"%s\" of %lu bytes\n", 
                     recs[i].op, io_bytes);
                  fprintf(logptr, "io_bytes=%lu\n", io_bytes);
               }						/* if */

              /*---------------------------------------------------
               *  Actual I/O performed here
               *---------------------------------------------------*/
               if (!strncmp(recs[i].op,"r",1)) {
	          /*  
                   * read op 
                   */
	          if ((bytes_read = read(fd, buff, io_bytes)) 
                         != (ssize_t)io_bytes) {
	             fprintf(logptr, 
		      "child %u: read at byte addr %lu of %lu bytes failed,\n",
	               p, recs[i].addr, recs[i].len);
	             fprintf(logptr, "errno=%d\n", errno);
	             perror("read failed");
	             io_error( "replay(): read failed" );
	          }						/* if */
                  if (verbose >= 2) 
                     fprintf(logptr,
                        "proc %u: bytes_read=%ld at byte addr=%lu\n",
                        p, (long)bytes_read, recs[i].addr);

	       } else {

	          /* 
                   * write op 
                   */
		  /* soil the buffer before writing */
                  buff[random() % (uint)(MAX(1,(io_bytes-1)))]++;
	          if ((bytes_written = 
                           write(fd,buff,io_bytes)) != (ssize_t)io_bytes) {
	             fprintf(logptr, 
		       "child %u: read at byte addr %lu of %lu bytes failed,\n",
	               p, recs[i].addr, recs[i].len);
	             fprintf(logptr, "errno=%d\n", errno);
	             perror("write failed");
	             io_error( "replay(): write failed" );
	          }						/* if */
                  if (verbose >= 2)
                     fprintf(logptr,
                        "proc %u: bytes_written=%ld at byte addr=%lu\n",
			p,  (long)bytes_written, recs[i].addr);
	       }						/* if op */
               io_end_time = timestamp(basetime);
               assert(!errno);

               /* 
                * pause for the prescribed time period after the IOP. This 
                * is akin to "think time."
                */
               if ( recs[i].post_io_delay > FLT_EPSILON ) 
                  if ( (usleep_retval = 
                              usleep( (uint)recs[i].post_io_delay*1000000)) ) {
                     fprintf(logptr,"usleep() failed in replay(): returns %d\n",
			usleep_retval);
                     terminate( EXIT_USLEEP_ERROR );
                  }					/* if usleep() error */


                 /*
                  * Solaris alarms to terminate sleep state cause EINTR to be set;
                  * this is quite reasonable (Linux does not do this). Reset errno
                  * to allow assertions ( assert(!errno) ) to pass.
                  */
                  if (errno == EINTR) errno = 0;


               /* record metrics */
               if ( replay_mono_file_flag ) m_index = i;
               else m_index = i * nprocs + p; /*i=this IOP, p=currnt proc num*/

               metrics[m_index].tstamp   = io_start_time;
               metrics[m_index].rsp_time = (float)(io_end_time-io_start_time);
               metrics[m_index].io_size  = recs[i].len;

	       /*
	        * "extra" verbosity mode allows a comparison of actual access
		* patterns on the scratch file so that they can be compared to
		* access patterns of the replay file.
		*/
	       if (verbose >= 2) {
	          fprintf(logptr, 
		 "child %u does %s at byte addr %lu (%ld) for %lu bytes,",
		         p, 
			 recs[i].op, 
			 recs[i].addr, 
			 (off_t)(recs[i].addr*scale), 
			 recs[i].len);
                  fprintf(logptr, " then paused for %f seconds\n", 
			 recs[i].post_io_delay);
               }					/* if verbose==2 */
            }						/* for i */

           /* 
            * cleanup
            */
            if (close(fd) == -1) io_error("close after fast write");

            stop_time = timestamp(basetime);
            if (verbose)
               fprintf(logptr, "Replay Child %u ends; elapsed: %12.6lf\n",
                        p, stop_time - start_time);

            /*
             * be tidy and detach from the shared memory segment 
             */
            if (shmdt( mbuff ) ) {
               perror("replay(): shmdt failed");
               terminate( EXIT_SHARED_MEM_ERROR );
            }					/* if shmdt() */

            exit( EXIT_NORMAL_TERMINATION ); /* important for children! */
      }						/* if child */
   }					        /* for p */

   assert( !errno );

   /* parent waits for all children to complete, then samples CPU */

   MARK("Replay", "Start"); 
   sample_times(basetime, &last_elapsed_time, &last_cpu_time);
   for (p=0; p<nprocs; p++ ) {
      errno = 0;
      retval = waitpid(-1, &status, NULL);
      if (errno && (errno!=EINTR)) {
         printf("errno=%d\n", errno);
         perror("bertha replay(): waitpid(): ");
      }						/* if errno */

      if ( status ) {
         fprintf(logptr,
            "When generating input file, child process terminated\n");
         fprintf(logptr,"with errno: %d\n",status>>16);
        /*
         * kill off remaining children
         */
         for (p0=0; p0<nprocs ; p0++) if (child[p0]) kill(child[p0],SIGINT);

       /*
        * pop smoke and evacuate
        */

         terminate( (uint)(status>>16) );
      }                                         /* if status */
   }						/* for p */

   get_delta_t(Replay, delta, basetime, &last_elapsed_time, &last_cpu_time);
   sample_times(basetime, &last_elapsed_time, &last_cpu_time);
   MARK("Replay", "Stop"); 
   SYNC("Replay");

   fprintf(logptr, "bertha: Replay elapsed:  %7.3lf CPU: %10.6lf ",
		delta[(int)Replay][ELAPSED],delta[(int)Replay][CPU]);

   fprintf(logptr,
          "Average throughput: %7.3lf MB/sec\n",
	  (double)(nprocs) * (fsize) / (delta[(int)Replay][ELAPSED]));

   /*
    * detach from the shared memory segment 
    */
   if (shmdt( mbuff ) ) {
      perror("replay(): shmdt failed");
      terminate( EXIT_SHARED_MEM_ERROR );
   }						/* if shmdt() */
   /*
    * remove the shared memory segment
    */

   if (shmctl( replay_shmid, IPC_RMID, NULL) ) {
      perror("shmctl failed");
      terminate( EXIT_SHARED_MEM_ERROR );
   }						/* if shmctl() */
   replay_shmid = 0;	/* set to zero if successfully removed; this prevents 
                         * terminate() from attempting to remove it again.
                         */

   /*----------------------------------------------
    * generate detailed reports as requested
    *----------------------------------------------*/
   do_reports(metrics, nprocs, replay_recs, "Replay", 
              test_timestamp, hist_args, rptdir, testname, 
              dump_raw_metrics_flag, metrics_by_proc_flag, reports_requested, 
              logptr, verbose, replay_mono_file_flag);

   /*-----------------------------------------------------------------------
    * if flag set to record data for possible rereporting, store data now
    *-----------------------------------------------------------------------*/
   if (record_flag) 
      do_record(metrics, nprocs, replay_recs , "Replay", rptdir, test_timestamp,
             testname, logptr, verbose, replay_mono_file_flag);

   /*----------------------------------------------------------------------
    * remove old datafiles
    *----------------------------------------------------------------------*/
   for (p=0; p<concurrent_nprocs; p++) 
      if (unlink(name[p])) {
          (void)snprintf(err_msg, (MAX_SCRATCHNAME_LEN+32),
                   "Cannot unlink(\"%s\") errno=%d\n",name[p],errno);
          io_warn( logptr, err_msg);
          errno = 0;
      }						/* if unlink() */

   /*---------------------------------------------------------
    * convey the final stats in a quick, bonnie-style report
    *---------------------------------------------------------*/
   fprintf(logptr,
          "\n\nReplay Summary:\n---------------\n\n");
   fprintf(logptr,
          "\nMachine    Procs  size (MB)   MB I/O   (MB Read   MB Write)");
   fprintf(logptr,"  Read Ops Write Ops");
   fprintf(logptr,"    MB/sec  %%CPU");
   fprintf(logptr,"   Elapsed (sec)\n");

   fprintf(logptr,
   "%-8.8s %5u %10ld %10.3f %10.3f %10.3f %9lu %9lu %10.2f %5.1lf %8.2lf\n", 
   	     testname, 
	     nprocs, 
	     (off_t)fsize,
	     (double)((replay_read_bytes + replay_write_bytes)/MBYTE 
                 * concurrent_nprocs), 
	     (double)(replay_read_bytes/MBYTE  * concurrent_nprocs), 
	     (double)(replay_write_bytes/MBYTE * concurrent_nprocs),
	     replay_read_ops   * concurrent_nprocs, 
             replay_write_ops  * concurrent_nprocs,
	     concurrent_nprocs * (double)
                (((replay_read_bytes+replay_write_bytes)/MBYTE)
	 	/(delta[(int)Replay][ELAPSED])),
              100*(delta[(int)Replay][CPU]/delta[(int)Replay][ELAPSED]),
	      delta[(int)Replay][ELAPSED]
	     );

   printf("\n\nReplay Summary:\n---------------\n");
   printf("\nMachine    Procs  size (MB)   MB I/O   (MB Read   MB Write)");
   printf("  Read Ops Write Ops");
   printf("    MB/sec  %%CPU");
   printf("   Elapsed (sec)\n");
   printf(
   "%-8.8s %5u %10ld %10.3f %10.3f %10.3f %9lu %9lu %10.2f %5.1lf %8.2lf\n", 
   	     testname, 
	     nprocs, 
	     (off_t)fsize,
	     (double)((replay_read_bytes + replay_write_bytes)/MBYTE 
                 * concurrent_nprocs), 
	     (double)(replay_read_bytes/MBYTE  * concurrent_nprocs), 
	     (double)(replay_write_bytes/MBYTE * concurrent_nprocs),
	     replay_read_ops   * concurrent_nprocs, 
             replay_write_ops  * concurrent_nprocs,
	     concurrent_nprocs *
                 (double)(((replay_read_bytes+replay_write_bytes)/MBYTE) 
	 	/(delta[(int)Replay][ELAPSED])),
             100*(delta[(int)Replay][CPU]/delta[(int)Replay][ELAPSED]),
	     delta[(int)Replay][ELAPSED]
	   );

   printf("\n\tMB/sec   %10.2f\n",  
       (double)(concurrent_nprocs*
                  (float)(((replay_read_bytes+replay_write_bytes)/MBYTE)
		     /(delta[(int)Replay][ELAPSED]))));
   printf("\tCPU:     %10.1lf%%\n", 
            100.0*(delta[(int)Replay][CPU]/delta[(int)Replay][ELAPSED]));
   printf("\tElapsed: %10.2lf Seconds\n", delta[(int)Replay][ELAPSED]);

  /*-------------------------------------------------------------------
   * Post-conditions
   *------------------------------------------------------------------*/
   assert( !errno );
}							/* replay() */

/*************************************************************************
 * my_mkfile() - Solaris mkfile(1) equivalent; linux may or may not have 
 *               mkfile available, so the functionality must be provided
 *               here.
 *************************************************************************/
static void my_mkfile( uint fsize, char *filename, FILE *logptr ) 
{
#define MKFILE_BUFFSIZE (20480)		

   char     buff[MKFILE_BUFFSIZE];	/* buff of garbage to write to file */
   int      fd = -1;			/* file descriptor for scratch file */
   ssize_t  bytes_written;		/* #bytes written during last write() */
   ssize_t  bytes_remaining;		/* #bytes to write to finish file */
   char     err_msg[MAX_SCRATCHNAME_LEN + 32];
   uint     i;				/* loop counter */

  /*------------------------------------------------------------------
   * Pre-conditions
   *------------------------------------------------------------------*/
   assert( !errno );
   if (!fsize) 
      BAD_ARG_UINT(fsize, "fsize", "my_mkfile", "fsize>0");
   if (!filename) BAD_ARG_PTR(filename,"filename","my_mkfile","filename!=NULL");
   if (!logptr)   BAD_ARG_PTR(logptr,"logptr","replay","logptr!=NULL");
  /*------------------------------------------------------------------*/

   for (i=0; i<MKFILE_BUFFSIZE ; i++) buff[i]=32;

   /* create the file */
   openfile(filename, &fd, 1);

   /* fill a scratch file of size bytes with garbage */
   for (bytes_remaining = (ssize_t)fsize; 
           bytes_remaining; 
           bytes_remaining -= bytes_written) {
      bytes_written = write( fd, buff, 	
			         (size_t)MIN(bytes_remaining,MKFILE_BUFFSIZE));
      if ( bytes_written != (ssize_t)MIN(bytes_remaining,MKFILE_BUFFSIZE) ) {
         if (errno == EFBIG) 
            terminate(EXIT_SCRATCH_FILE_TOO_LARGE);
         else {
            fprintf(logptr, 
               "I/O error writing data to replay scratch file: \"%s\"\n",
	       filename);
            terminate( EXIT_IO_ERROR );
         }							/* if EFBIG */
      }								/* if retval */
   }								/* for i */
   assert( !errno );

   if (close(fd)) {
      (void)snprintf(err_msg, (MAX_SCRATCHNAME_LEN+32), 
               "Cannot close(\"%s\") errno=%d\n",filename,errno);
      io_warn( logptr, err_msg);
      errno = 0;
   }								/* if close() */

  /*-------------------------------------------------------------------
   * Post-conditions
   *------------------------------------------------------------------*/
   assert( !errno );
} 								/* my_mkfile()*/
