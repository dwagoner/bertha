/*---------------------------------------------------------------------
 * rsp_curves.c - Routines to generate tables and/or code to produce 
 * response time curves.
 *
 *-------------------------------------------------------------------------
 * Copyright 2006, Dave Wagoner
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *-------------------------------------------------------------------------
 *
 * At present, the following response time curves are generated:
 *
 *       Response time vs. Throughput curve
 *       Response time vs. I/O concurrency level curve
 *----------------------------------------------------------------------*/

/*-------------------------------------------------------------------- 
 * fetch header files and macro definitions
 *-------------------------------------------------------------------*/
#include "./bertha.h"

/*-------------------------------------------------------------------- 
 * structures used only in this module
 * Only one of the two elements xput and mbytes is necessary; 
 *-------------------------------------------------------------------*/
/* used for rsp_time vs. thruput  and  rsp_time vs io_concurrency curves */
struct curve_histogram_rec {
   float x;
   struct summary_rec stats;
   struct curve_rec *r;
} curve_histogram_rec;

/*-------------------------------------------------------------------- 
 * prototypes local to this module
 *-------------------------------------------------------------------*/
static void dump_curve(struct curve_histogram_rec *curve, uint intervals, 
               float suppress, char *operation, char *histogram_name, 
               char *histogram_title, uint reports_requested[NUM_REPORT_TYPES],
               char *report_prefix, char *test_timestamp, FILE *logptr);

/*-------------------------------------------------------------------- 
 * macros used only in this module
 *-------------------------------------------------------------------*/

/* allocate one element of linked to attach to linked list */
#define MALLOC_CURVE_REC_PTR_P() if ( !(p=malloc( sizeof (struct curve_rec)) ) ) { fprintf(logptr, "malloc for struct curve_rec p failed in do_rsp_curves()\n"); terminate( EXIT_MALLOC_FAILURE ); }

/***************************************************************************
 * do_rsp_curves() -  generate the curves for rsp vs. xput and 
 *		      rsp vs. io_concurrency. For each interval (bucket)
 *		      for throughput, determine and emit the average and 
 *                    median response times. Repeat this to derive rsp
 *		      vs io_concurrency data.
 *
 *                    Note: the number of IOPs used to compute the curve
 *                    may be less than the number of IOPs performed. Only
 *                    those IOPs that fall evenly within the interval will
 *                    have their response times counted in the bucket. 
 *                    A criticism of the methodology here is that the 
 *                    response times may not be counted in a particular 
 *                    interval but the throughput & I/O concurrency 
 *                    contributions are. However, the percentage of IOPs
 *                    that are not included is generally less than 1%, and
 *                    these IOPs affect median & average values, but 
 *                    generally not by a significant amount.
 * 
 ***************************************************************************/
void do_rsp_curves( struct metrics_rec *metrics , 
	     float hist_args[NUM_CHARTS][NUM_CHART_PARMS], 
             struct time_range_rec time_bounds, char *operation, 
             char *report_prefix, uint nprocs, uint iops, 
             uint reports_requested[NUM_REPORT_TYPES], FILE *logptr, 
             uint verbose, uint replay_mono_file_flag, char *test_timestamp)
{
   float  *w;				/* tmp array for values to histogram */
   uint    hist_intervals;		/* number of intervals in histogram */
   struct  summary_rec range;		/* will contain range of variable */
   uint    this_interval;		/* interval loop counter */
   struct  curve_rec *p;		/* used to traverse linked list */
   struct  curve_rec *head;		/* ptr to head of new linked list */
   struct  curve_rec *tail;		/* ptr to tail of new linked list */
   struct  curve_rec *orig;		/* ptr to io_buckets data being copied*/
   struct  curve_rec *next;		/* next element in linked list */
   uint    io_bucket_intervals;         /* number of buckets */
   struct  bucket_rec *io_buckets;      /* ptr to array of buckets for hists */

   struct  curve_histogram_rec *rsp_xput_hist;
   struct  curve_histogram_rec *rsp_concurrency_hist;

   uint    i;				/* loop counter */
   uint    j;				/* linked list element count */

   /*---------------------------------------------------------------
    * arg checks
    *---------------------------------------------------------------*/
   if ( !metrics ) 
      BAD_ARG_PTR(metrics,"metrics","do_rsp_curves","metrics!=NULL");
   if ( !hist_args ) 
      BAD_ARG_PTR(hist_args,"hist_args","do_rsp_curves","operation!=NULL");
   if ( (time_bounds.end - time_bounds.begin) < DBL_EPSILON ) 
      BAD_ARG_FLOAT(time_bounds.end,"time_bounds","do_rsp_curves",
                    "time_bounds.begin<=time_bound.end");
   if ( !operation ) 
      BAD_ARG_PTR(operation,"operation","do_rsp_curves","operation!=NULL");
   if ( !report_prefix ) 
      BAD_ARG_PTR(report_prefix,"report_prefix",
                  "do_rsp_curves","report_prefix!=NULL");
   if (!nprocs) BAD_ARG_UINT(nprocs, "nprocs", "do_rsp_curves","nprocs>0");
   if (!iops)   BAD_ARG_UINT(iops,   "iops",   "do_rsp_curves","iops>0");
   if (!reports_requested)   
      BAD_ARG_PTR(reports_requested,"reports_requested",
                  "do_rsp_curves","reports_requested!=NULL");
   if (!logptr) BAD_ARG_PTR(logptr,  "logptr",  "do_rsp_curves","logptr!=NULL");
   if (replay_mono_file_flag > 1)
      BAD_ARG_UINT(replay_mono_file_flag, "replay_mono_file_flag", 
                   "do_rsp_curves","replay_mono_file_flag>0");
   if (!test_timestamp) 
      BAD_ARG_PTR(test_timestamp,  "test_timestamp",  "do_rsp_curves",
                   "test_timestamp!=NULL");
  /*---------------------------------------------------------------*/

   /*---------------------------------------------------------------
    * rsp_time vs. xput
    *---------------------------------------------------------------*/
   /* determine the number of buckets, allocate memory, and initialize */

   /*
    * Note that the report for rsp_time vs. xput
    * will show users thruput (the independent variable) in increments 
    * of bucketsize. Using too low a resolution (e.g. too large of a 
    * bucketsize) may disguise more interesting data. If the resolution is
    * to low, thruputs will appear artificially small because bursts will 
    * be averaged with inactivity, making the result a poor representation. 
    * Setting the resolution too high (bucketsize too small) will result in
    * potentially vast quanticles of data being collected, manipulated, and
    * reported. The last of these will have the most influence on the user as
    * report contents may be unwieldy to manage. 
    */

   /*
    * Determine the number of buckets in bucketizing the data. A minimum of 
    * three buckets will be used. The "+2" is to ensure that enough buckets
    * are present to avoid exceeding array bounds.
    */
   io_bucket_intervals =
          (uint)(MAX(1,(((time_bounds.end - time_bounds.begin) / 
                 hist_args[RSP_XPUT][TIME_INTERVAL]) + 2)));
   io_buckets = bucketize(metrics, nprocs, iops, time_bounds, 
                 hist_args[RSP_XPUT][TIME_INTERVAL], io_bucket_intervals, 
	         "rsp time vs. thruput curve", logptr, verbose, 
	         replay_mono_file_flag);

   /*
    * Dynamically allocate memory for work array; this array will be used to
    * derive min & max of range of througput contained in the buckets.
    */
   if ( !(w = malloc(io_bucket_intervals * sizeof(float))) ) {
      fprintf(logptr, "Could not malloc() for do_histogram work array\n");
   }

   /* find range of values, load w with thruput values and run do_stats() on w*/
   for ( i=0 ; i<io_bucket_intervals ; i++ ) {
      w[i] = io_buckets[i].xput;
   }							/* for i */

   /*
    * determine number of intervals for histogram; need to add one 
    * to accomodate the lowest interval.
    */
   range = do_stats( w, io_bucket_intervals );
   range.min = (float)((uint)range.min); /* round down to next lowest int */

   free( w );				/* release mem from tmp array */
   hist_intervals = (uint)(((range.max - range.min) /
			hist_args[RSP_XPUT][BUCKET_SIZE])+1);

   /*
    * Allocate array to contain histogram data; need to allocate 
    * hist_intervals + 1 because the algorithm below is accessing
    * the next interval to identify where the current interval ends. Note
    * that the loop below reads "i <= hist_intervals", not "i < hist_intervals"
    */
   if ( !(rsp_xput_hist = (struct curve_histogram_rec *)malloc( 
             (size_t)((hist_intervals + 1) * 
		                 sizeof( struct curve_histogram_rec ))))) {
      fprintf(logptr, 
         "Could not malloc() for do_hist array for rsp_xput_hist\n");
      terminate( EXIT_MALLOC_FAILURE );
   }							/* if malloc() */

   /* 
    * Intialize buckets in histogram array. range.min is currently truncated 
    * to the next lowest integer, so * histogram buckets become nicely aligned 
    * (e.g. from 0.0) to the next increment up to the range.max.
    */
   for (i=0 ; i<=hist_intervals ; i++)  {
      rsp_xput_hist[i].x = (float)((i*hist_args[RSP_XPUT][BUCKET_SIZE]) + 
								range.min);
      rsp_xput_hist[i].stats.min =    0.0;
      rsp_xput_hist[i].stats.median = 0.0;
      rsp_xput_hist[i].stats.mean =   0.0;
      rsp_xput_hist[i].stats.p75 =    0.0;
      rsp_xput_hist[i].stats.p90 =    0.0;
      rsp_xput_hist[i].stats.p95 =    0.0;
      rsp_xput_hist[i].stats.p99 =    0.0;
      rsp_xput_hist[i].stats.max =    0.0;
      rsp_xput_hist[i].stats.stddev = 0.0;
      rsp_xput_hist[i].stats.n =      0;
      rsp_xput_hist[i].r =            NULL;
   }							/* for i */

   /* 
    * populate histogram with rsp times; the io_buckets structure must be
    * left intact, so the rsp elements must be cloned and attached to the 
    * appropriate buckets in rsp_xput_hist
    */ 
   for (i=0 ; i<io_bucket_intervals ; i++ ) {
      this_interval = (uint)((io_buckets[i].xput-range.min) / 
		           hist_args[RSP_XPUT][BUCKET_SIZE]);
      assert(this_interval < hist_intervals);
      
      /* skip empty buckets - nothing to read thru here, go to next bucket */
      if (!io_buckets[i].head) continue;


      /* clone the linked list pointed to by io_buckets[i].head*/
      tail = NULL;
      head = NULL;
      orig = io_buckets[i].head;

      while (orig) {
         MALLOC_CURVE_REC_PTR_P();   /* allocate an element of the linked list*/
         p->rsp  = orig->rsp;	     /* copy the response time value */
         p->next = NULL;	     /* init ptr to next element */
         if (tail) tail->next = p;   /* attach element to end of list */
         else head = p;		     /* this is first element; store addr */
         tail = p;		     /* store addr of new item for next iter */

         orig = orig->next;	     /* point to the next elem of orig list */
      }

      /* to populate merely means to append linked lists of rsp times */
      if ( !rsp_xput_hist[ this_interval ].r ) {
         /* list was empty, just point to list in buckets */
         rsp_xput_hist[ this_interval ].r = head;

      } else {
         /* list was NOT empty, append buckets list to existing list */
         p = rsp_xput_hist[ this_interval ].r;
         while ( p->next ) p = p->next;    /* traverse current list to tail */
         p->next = head;		   /* append new list segment */

      }							/* if .r */
   }							/* for i */

   /* for each histogram interval, summarize relevant rsp time stats  */

   for (this_interval=0 ; this_interval < hist_intervals ; this_interval++) {
      if (!rsp_xput_hist[this_interval].r) continue;

      /* count number of rsp times in linked list */
      for (p=rsp_xput_hist[this_interval].r, i=1 ; p->next ; i++, p=p->next);

      /* allocate scratch array */
      if ( !(w = malloc(i * sizeof(float))) ) {
         fprintf(logptr, "malloc() for w in do_rsp_curves() fails\n");
         terminate( EXIT_MALLOC_FAILURE );
      }							/* if malloc() */

      /* populate scratch array */
      for (p=rsp_xput_hist[this_interval].r, j=0 ; p->next ; j++, p=p->next){
         assert ( j<i );
         w[j] = p->rsp * 1000;	/* convert from sec to millisec here */
      }
      
      /* derive summary stats for this interval */ 
      rsp_xput_hist[this_interval].stats = do_stats(w, i);

      free(w);					/* release tmp array mem */
   }						/* for this_interval */


   dump_curve(rsp_xput_hist, hist_intervals, hist_args[RSP_XPUT][SUPPRESS_ZERO],
              operation, "rsp_xput", "Aggregate Throughput (MB/sec)", 
              reports_requested, report_prefix, test_timestamp, logptr);

   /*
    * free each member of linked list of rsp times within rsp_xput_hist before
    * deallocating the io_buckets structure itself 
    */
   for (i=0 ; i<hist_intervals ; i++ ) {     /* for each of the io_buckets[] */
      for ( p=rsp_xput_hist[i].r ; p ; ){  /* scan thru list */
          if ( !p->next ) {		/* is this the end of the list? */
             free( p );			/* end of list; free current element */
             p = NULL;			/* set condition to end for loop */
          } else {
             next = p->next;		/* grab addr of next element in list */
             free( p );			/* free current element */
             p = next;			/* point to next element in list */
          }
      }							/* for p */
   }					                /* for i */
   free(rsp_xput_hist);			/* release mem containing histogram */
   assert(!errno);

   /*---------------------------------------------------------------
    * rsp_time vs. io_concurrency
    *---------------------------------------------------------------*/
   /* determine the number of buckets, allocate memory, and initialize */

   if ( (fabsf(hist_args[RSP_CONCURRENCY][TIME_INTERVAL] - 
               hist_args[RSP_XPUT][TIME_INTERVAL])
            <FLT_EPSILON) 
      )  {

       free_io_buckets( io_buckets, io_bucket_intervals );

       io_bucket_intervals =
           (uint)(MAX(1,(((time_bounds.end - time_bounds.begin) / 
               hist_args[RSP_CONCURRENCY][TIME_INTERVAL]) + 2)));
       io_buckets = bucketize(metrics, nprocs, iops, time_bounds, 
                     hist_args[RSP_CONCURRENCY][TIME_INTERVAL], 
                     io_bucket_intervals, "rsp time vs. thruput curve", logptr,
                     verbose, replay_mono_file_flag);
   }				/* if need to re-bucketize */

   /*
    * Dynamically allocate memory for work array; this array will be used to
    * derive min & max of range of buckets
    */
   if ( !(w = malloc(io_bucket_intervals * sizeof(float))) ) {
      fprintf(logptr, "Could not malloc() for do_histogram work array\n");
   }

   /* find range of values, load w with rsp_times and run do_stats() on w... */
   for ( i = 0  ;  i < io_bucket_intervals  ;  i++ ) {
      w[ i ] = io_buckets[ i ].io_concurrency;
   }							/* for i */

   /*
    * determine number of intervals for histogram; need to add one 
    * to accomodate the lowest interval
    */
   range = do_stats( w, io_bucket_intervals );
   range.min = (float)((uint)range.min); /* round down to next lowest int */

   free( w );				/* release mem from tmp array */

   hist_intervals = (uint)(((range.max - range.min) /
		       hist_args[RSP_CONCURRENCY][BUCKET_SIZE])+1);

   /*
    * allocate array to contain histogram data; need to allocate 
    * hist_intervals + 1 because the algorithm below is accessing
    * the next interval to identify where the current interval ends. Note
    * that the loop below reads "i <= hist_intervals", not "i < hist_intervals"
    */
   if ( !(rsp_concurrency_hist = (struct curve_histogram_rec *)malloc( 
             (size_t)((hist_intervals + 1) * 
		                 sizeof( struct curve_histogram_rec ))))) {
      fprintf(logptr, 
         "Could not malloc() for do_hist array for rsp_concurrency_hist\n");
      terminate( EXIT_MALLOC_FAILURE );
   }							/* if malloc() */

   /* intialize buckets in histogram array */
   for ( i = 0  ;  i <= hist_intervals  ;  i++ )  {
      rsp_concurrency_hist[ i ].x = 
          (float)((i*hist_args[RSP_CONCURRENCY][BUCKET_SIZE]) + range.min);
      rsp_concurrency_hist[ i ].stats.min =    0.0;
      rsp_concurrency_hist[ i ].stats.median = 0.0;
      rsp_concurrency_hist[ i ].stats.mean =   0.0;
      rsp_concurrency_hist[ i ].stats.p75 =    0.0;
      rsp_concurrency_hist[ i ].stats.p90 =    0.0;
      rsp_concurrency_hist[ i ].stats.p95 =    0.0;
      rsp_concurrency_hist[ i ].stats.p99 =    0.0;
      rsp_concurrency_hist[ i ].stats.max =    0.0;
      rsp_concurrency_hist[ i ].stats.stddev = 0.0;
      rsp_concurrency_hist[ i ].stats.n =      0;
      rsp_concurrency_hist[ i ].r =            NULL;
   }							/* for i */

   /* populate histogram with rsp times*/ 
   for ( i=0 ; i<io_bucket_intervals ; i++ ) {
      this_interval = (uint)((io_buckets[i].io_concurrency-range.min) 
		          / hist_args[RSP_CONCURRENCY][BUCKET_SIZE]);
      assert(this_interval < hist_intervals);
      
      if (!io_buckets[i].head) continue;
      
      /* clone the linked list pointed to by io_buckets[i].head */
      tail = NULL;
      head = NULL;
      orig = io_buckets[i].head;

      while ( orig ) {
         MALLOC_CURVE_REC_PTR_P();  /* allocate an element of the linked list*/
         p->rsp  = orig->rsp;	     /* copy the response time value */
         p->next = NULL;	     /* init ptr to next element */
         if ( tail ) tail->next = p; /* attach element to end of list */
         else head = p;		     /* this is first element; store addr */
         tail = p;		     /* store addr of new item for next iter */

         orig = orig->next;	     /* point to the next elem of orig list */
      }

      /* to populate merely means to append linked lists of rsp times */
      if ( !rsp_concurrency_hist[ this_interval ].r ) {
         /* list was empty, just point to list in buckets */
         rsp_concurrency_hist[ this_interval ].r = head;

      } else {
         /* list was NOT empty, append buckets list to existing list */
         p = rsp_concurrency_hist[ this_interval ].r;
         while ( p->next ) p = p->next;
         p->next = head;

      }							/* if .r */
   }							/* for i */

   /* for each histogram interval, summarize relevant rsp time stats  */
   for (this_interval=0 ; this_interval < hist_intervals ; this_interval++ ) {
      if ( !rsp_concurrency_hist[ this_interval ].r ) continue;

      /* count number of rsp times in linked list */
      for (p=rsp_concurrency_hist[ this_interval ].r, i=1 ; p->next ; 
								i++, p=p->next);

      /* allocate scratch array */
      if ( !(w = malloc(i * sizeof(float))) ) {
         fprintf(logptr, "malloc() for w in do_rsp_curves() fails\n");
         terminate( EXIT_MALLOC_FAILURE );
      }							/* if malloc() */

      /* populate scratch array */
      for (p=rsp_concurrency_hist[ this_interval ].r, j=0 ; p->next ; 
							     j++, p=p->next){
         assert ( j < i );
         w[ j ] = p->rsp * 1000;   /* convert from sec to millisec here */
      }
      
      /* derive summary stats for this interval */ 
      rsp_concurrency_hist[ this_interval ].stats = do_stats( w, i );

      free( w );				/* release tmp array mem */
   }						/* for this_interval */

   dump_curve(rsp_concurrency_hist, hist_intervals, 
              hist_args[RSP_CONCURRENCY][SUPPRESS_ZERO], operation, 
              "rsp_concurrency", "IO Concurrency (# of active IOPs)", 
              reports_requested, report_prefix, test_timestamp, logptr); 
   /*
    * free each member of linked list of rsp times within 
    * rsp_concurrency_hist before deallocating the io_buckets structure itself 
    */
   for (i=0 ; i<hist_intervals ; i++ ) {     /* for each of the io_buckets[] */
      for ( p=rsp_concurrency_hist[i].r ; p ; ){  /* scan thru list */
          if ( !p->next ) {		/* is this the end of the list? */
             free( p );			/* end of list; free current element */

             p = NULL;			/* set condition to end for loop */
          } else {
             next = p->next;		/* grab addr of next element in list */
             free( p );			/* free current element */
             p = next;			/* point to next element in list */
          }
      }							/* for p */
   }					                /* for i */
   free( rsp_concurrency_hist );	/* release mem containing histogram */
   free_io_buckets( io_buckets, io_bucket_intervals );

  /*---------------------------------------------------------------
   * Post-conditions
   *---------------------------------------------------------------*/
   assert(!errno);
}							/* do_rsp_curves */

/***************************************************************************
 * dump_curve() - 
 ***************************************************************************/
static void dump_curve(struct curve_histogram_rec *curve, uint intervals, 
               float suppress, char *operation, char *histogram_name, 
               char *histogram_title, uint reports_requested[NUM_REPORT_TYPES], 
               char *report_prefix, char *test_timestamp, FILE *logptr)
{

   uint   i;					/* loop variable */
   char   report_filename[MAX_REPORTNAME_SIZE];
   char   dat_filename[MAX_REPORTNAME_SIZE];
   char   error_msg[ERROR_MSG_MAX_LEN];
   char   xlab[128];				/* x-axis label for R plots */
   FILE  *outfile;                              /* report output file ptr */

  /*---------------------------------------------------------------
   * Pre-conditions
   *---------------------------------------------------------------*/
   assert(!errno);
   if ( !curve ) 
      BAD_ARG_PTR(curve,"curve","dump_curve","curve!=NULL");
   if ( !intervals ) 
      BAD_ARG_UINT(intervals, "intervals", "dump_curve","intervals>0");
   if ( (uint)suppress > 1)
      BAD_ARG_UINT((uint)suppress, "suppress", "dump_histogram",
                  "suppress={0,1}");
   if ( !operation ) 
      BAD_ARG_PTR(operation,"operation","dump_curve","operation!=NULL");
   if ( !histogram_name) 
      BAD_ARG_PTR(histogram_name ,"histogram_name","dump_curve",
                  "histogram_name!=NULL");
   if ( !histogram_title) 
      BAD_ARG_PTR(histogram_title ,"histogram_title","dump_curve",
                  "histogram_title!=NULL");
   if (!reports_requested)   
      BAD_ARG_PTR(reports_requested,"reports_requested",
                  "dump_curve","reports_requested!=NULL");
   if (!report_prefix) BAD_ARG_PTR(report_prefix,  "report_prefix",  
                   "dump_curve","report_prefix!=NULL");
   if (!test_timestamp) 
      BAD_ARG_PTR(test_timestamp,  "test_timestamp",  "dump_curve",
         "test_timestamp!=NULL");
   if (!logptr) BAD_ARG_PTR(logptr,  "logptr",  "dump_curve","logptr!=NULL");
  /*------------------------------------------------------------------------*/

  /*--------------------------------------------------------------
   * TEXT
   *--------------------------------------------------------------*/
   if ( reports_requested[TEXT] ) {
      strcpy(report_filename, report_prefix);
      strcat(report_filename, "curve_");
      strcat(report_filename, histogram_name);
      strcat(report_filename, "_");
      strcat(report_filename, operation);
      strcat(report_filename, ".txt" );
      assert( strlen(report_filename)<MAX_REPORTNAME_SIZE );

      if ( !(outfile = fopen(report_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", report_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }							/* if fopen() error */
      fprintf(outfile, "\n\n\t\tCurve Table\n");
      fprintf(outfile, "\t%s - %s\n\n", operation, histogram_title); 
      fprintf(outfile, "\t    Test Run: %s\n\n", test_timestamp); 
      fprintf(outfile, 
       "Intvl             Range             Num        Median         Avg\n");
      fprintf(outfile, 
      "          From     -    Up To      Values       (ms)          (ms)\n\n");
   
      for (i=0 ; i<intervals ; i++ ) {
         if ( (fabsf(suppress)<FLT_EPSILON) || (curve[i].stats.n > 0)) 
            fprintf(outfile, "%5u %12.6f - %12.6f  %6u %12.6f	%12.6f\n", 
               i, curve[ i ].x, curve[ i+1 ].x, curve[ i ].stats.n,
	       curve[ i ].stats.median,  curve[ i ].stats.mean);
      }							/* for i */

      fprintf(outfile, "\n\n");
      if (fclose( outfile )) {
         (void)snprintf(error_msg, ERROR_MSG_MAX_LEN, 
                   "fclose() failed on file %s\n", report_filename);
         io_error(error_msg);
      }							/* if fclose() */
      assert(!errno);
   }							/* if TEXT */

   /*--------------------------------------------------------------
    * CSV 
    *--------------------------------------------------------------*/
  if ( reports_requested[CSV] ) {
      strcpy(report_filename, report_prefix);
      strcat(report_filename, "curve_");
      strcat(report_filename, histogram_name);
      strcat(report_filename, "_");
      strcat(report_filename, operation);
      strcat(report_filename, ".csv" );
      assert( strlen(report_filename)<MAX_REPORTNAME_SIZE );

      if ( !(outfile = fopen(report_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", report_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }							/* if fopen() error */
      fprintf(outfile, "\n\n\t\tCurve Table\n");
      fprintf(outfile, "\t%s - %s\n\n", operation, histogram_title); 
      fprintf(outfile, "\t    Test Run:,%s\n\n", test_timestamp); 
      fprintf(outfile, 
       "Intvl,,           Range,,           Num,       Median,        Avg\n");
      fprintf(outfile, 
      ",         From,    -,   Up To,     Values,      (ms),         (ms)\n\n");
   
      for (i=0 ; i<intervals ; i++ ) {
         if ( (fabsf(suppress)<FLT_EPSILON) || (curve[i].stats.n > 0)) 
            fprintf(outfile, "%5u,%12.6f,-,%12.6f, %6u,%12.6f,%12.6f\n", 
               i, curve[i].x, curve[i+1].x, curve[i].stats.n,
	       curve[i].stats.median,  curve[i].stats.mean);
      }							/* for i */

      fprintf(outfile, "\n\n");
      if (fclose( outfile )) {
         (void)snprintf(error_msg, ERROR_MSG_MAX_LEN, 
                   "fclose() failed on file %s\n", report_filename);
         io_error(error_msg);
      }							/* if fclose() */
      assert(!errno);
   }							/* if CSV*/


  /*--------------------------------------------------------------------
   * SAS reports
   *--------------------------------------------------------------------*/
   if ( reports_requested[SAS] ) {
      strcpy(report_filename, report_prefix);
      strcat(report_filename, "curve_");
      strcat(report_filename, histogram_name);
      strcat(report_filename, "_");
      strcat(report_filename, operation);
      strcat(report_filename, ".sas" );
      assert( strlen(report_filename) < MAX_REPORTNAME_SIZE);

      if ( !(outfile = fopen(report_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", report_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }                                                 /* if fopen() error */

      fprintf(outfile, "/************************************************\n");
      fprintf(outfile, " *\n");
      fprintf(outfile, " * hist_%s_%s.sas - produce histogram charts to\n",
                   histogram_name, operation);
      fprintf(outfile, " *     visualize data collected during\n");
      fprintf(outfile, " *     '%s' component of a Bertha test\n", operation);
      fprintf(outfile, " *\n");
      fprintf(outfile, " ************************************************/\n");
      fprintf(outfile, "\n");
      fprintf(outfile, "   data RAW;\n");
      fprintf(outfile, "\n");
      fprintf(outfile, "      label RANGE_LBOUND ='%s';\n", histogram_title);
      fprintf(outfile, "      label RANGE_UBOUND ='Upper bound of bucket';\n");
      fprintf(outfile, "      label AVG_RSP      ='Avg Rsp Time (ms)';\n");
      fprintf(outfile, "      label MEDIAN_RSP   ='Median Rsp Time (ms)';\n");
      fprintf(outfile, "      label N='Number of samples';\n");
      fprintf(outfile, "\n");
      fprintf(outfile, 
                  "      format RANGE_LBOUND RANGE_UBOUND 12.6 N comma10.;\n");
      fprintf(outfile, "      input RANGE_LBOUND RANGE_UBOUND N ");
      fprintf(outfile, "MEDIAN_RSP AVG_RSP;\n");
      fprintf(outfile, "      cards;\n");

      for (i=0 ; i<intervals ; i++ ) {
         if ( (fabsf(suppress)<FLT_EPSILON) || (curve[i].stats.n > 0)) 
            fprintf(outfile, "%12.6f %12.6f %6u %12.6f %12.6f\n", 
               curve[i].x, curve[i+1].x, curve[i].stats.n,
	       curve[i].stats.median,  curve[i].stats.mean);
      }							/* for i */

      fprintf(outfile,";\n");
      fprintf(outfile,"   run;\n");
      fprintf(outfile,"\n");
      fprintf(outfile,"  /*---------------------------------------------\n");
      fprintf(outfile,"   * Prepare to emit chart(s)\n");
      fprintf(outfile,"   *---------------------------------------------*/\n");
      fprintf(outfile,"   goptions reset=all;\n\n");
      fprintf(outfile,"   title1 j=c '%s - %s';\n",
          operation, histogram_title);
      fprintf(outfile,"   title2 j=c 'Test Run on: %s';\n",test_timestamp);
      fprintf(outfile,"   symbol1 color=black h=0.3 v=0.3 value=dot;\n");
      fprintf(outfile,"   symbol2 color=red   h=0.3 v=0.3 value=dot;\n");
      fprintf(outfile,"   axis1 label=(j=c 'Milliseconds');\n");
      fprintf(outfile,"\n");
      fprintf(outfile,"  /*---------------------------------------------\n");
      fprintf(outfile,"   * emit chart(s)\n");
      fprintf(outfile,"   *---------------------------------------------*/\n");
      fprintf(outfile,"*  filename G '/var/tmp/curve_%s_%s.gif';\n",
          histogram_name, operation);
      fprintf(outfile,"*  goptions dev=gif733 gsfname=G gsfmode=replace;\n");

      fprintf(outfile,"   proc gplot data=RAW;\n");
      fprintf(outfile,"      plot (MEDIAN_RSP AVG_RSP) * RANGE_LBOUND /\n");
      fprintf(outfile,"         vaxis=axis1\n");
      fprintf(outfile,"         legend grid overlay;\n");
      fprintf(outfile,"   run;\n   quit;\n");
      fprintf(outfile,"\n");

      if (fclose(outfile)) {
         (void)snprintf(error_msg, ERROR_MSG_MAX_LEN, 
                   "fclose() failed on file %s\n", report_filename);
         io_error(error_msg);
      }							/* if fclose() */

      assert(!errno);
   }							/* if SAS */

  /*--------------------------------------------------------------------
   * GNU_PLOT reports
   *--------------------------------------------------------------------*/
   if ( reports_requested[GNU_PLOT] ) {

      /* gnuplot data file name */
      strcpy(dat_filename, report_prefix);
      strcat(dat_filename, "curve_");
      strcat(dat_filename, histogram_name);
      strcat(dat_filename, "_");
      strcat(dat_filename, operation);
      strcat(dat_filename, ".gin" );
      assert( strlen(dat_filename) < MAX_REPORTNAME_SIZE);

      /* gnuplot script*/
      strcpy(report_filename, report_prefix);
      strcat(report_filename, "curve_");
      strcat(report_filename, histogram_name);
      strcat(report_filename, "_");
      strcat(report_filename, operation);
      strcat(report_filename, ".gp" );
      assert( strlen(report_filename) < MAX_REPORTNAME_SIZE);

      if ( !(outfile = fopen(report_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", report_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }                                                 /* if fopen() error */

      fprintf(outfile, "#\n# gnuplot rsp time curve data for %s\n#\n\n", 
	 operation);
      fprintf(outfile, "#\n# uncomment next two lines to produce");
      fprintf(outfile, " postscript output\n#\n\n");
      fprintf(outfile, "# set output \"gnuplot_%s_%s.ps\"\n",
         histogram_name, operation);
      fprintf(outfile, "# set terminal postscript landscape\n\n");
      fprintf(outfile, "set grid\n");

      if ( !strcmp(histogram_name,"rsp_concurrency") )  {
         fprintf(outfile,
            "set xlabel \"I/O Concurrency (number of active I/Os)\"\n");
      } else {
         fprintf(outfile, 
            "set xlabel \"Thruput (MB/sec)\"\n");
      }							/* if strcmp */

      fprintf(outfile, "set ylabel \"Rsp Time (msec)\"\n\n");
      fprintf(outfile, "plot \"%s\" using 1:4 title \"Median Rsp Time\",", 
          dat_filename);
      fprintf(outfile, "\"%s\" using 1:5 title \"Avg Rsp Time\"\n\n", 
          dat_filename);
      fclose(outfile);

      /* gnuplot data */
      if ( !(outfile = fopen(dat_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", dat_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }                                                 /* if fopen() error */

      for (i=0 ; i<intervals ; i++ ) {
         if ( (fabsf(suppress)<FLT_EPSILON) || (curve[i].stats.n > 0)) 
            fprintf(outfile, "%12.6f %12.6f %6u %12.6f %12.6f\n", 
               curve[i].x, curve[i+1].x, curve[i].stats.n,
	       curve[i].stats.median, curve[i].stats.mean);
      }							/* for i */
      fclose(outfile);

      assert(!errno);
   }							/* if GNU_PLOT */

  /*--------------------------------------------------------------------
   * R reports
   *--------------------------------------------------------------------*/
   if ( reports_requested[R] ) {

      /* R data file name */
      strcpy(dat_filename, report_prefix);
      strcat(dat_filename, "curve_");
      strcat(dat_filename, histogram_name);
      strcat(dat_filename, "_");
      strcat(dat_filename, operation);
      strcat(dat_filename, ".rin" );
      assert( strlen(dat_filename) < MAX_REPORTNAME_SIZE);

      /* R script*/
      strcpy(report_filename, report_prefix);
      strcat(report_filename, "curve_");
      strcat(report_filename, histogram_name);
      strcat(report_filename, "_");
      strcat(report_filename, operation);
      strcat(report_filename, ".r" );
      assert( strlen(report_filename) < MAX_REPORTNAME_SIZE);

      if ( !(outfile = fopen(report_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", report_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }                                                 /* if fopen() error */

      /* R script */
      fprintf(outfile,
         "#\n# R script to generate response time curve for %s test\n#\n\n",
         operation);

      fprintf(outfile,
         "#\n# Comment out following line to generate postscript output\n#\n");
      fprintf(outfile, "# postscript(\"%scurve_%s_%s_R.ps\")\n\n",
         report_prefix, histogram_name, operation);

      if ( !strcmp(histogram_name,"rsp_concurrency") )  {
         strcpy(xlab, "I/O Concurrency (number of active I/Os)");
      } else {
         strcpy(xlab, "Thruput (MB/sec)");
      }							/* if strcmp */

      fprintf(outfile, "#\n# AVERAGE rsp time\n#\n");
      fprintf(outfile, "df1 <- read.table(\"%s\")\n", dat_filename);
      fprintf(outfile, "plot(df1[,1],df1[,5], ");
      fprintf(outfile, "xlab=\"%s\", ", xlab);
      fprintf(outfile, "ylab=\"Rsp Time (msec)\", ");
      fprintf(outfile, "main=\"Avg Rsp Time vs. %s for %s Test\",tck=1)\n\n",
         xlab, operation);

      fprintf(outfile, "#\n# MEDIAN rsp time\n#\n");
      fprintf(outfile, "df1 <- read.table(\"%s\")\n", dat_filename);
      fprintf(outfile, "plot(df1[,1],df1[,4], ");
      fprintf(outfile, "xlab=\"%s\", ", xlab);
      fprintf(outfile, "ylab=\"Rsp Time (msec)\", ");
      fprintf(outfile, "main=\"Median Rsp Time vs. %s for %s Test\",tck=1)\n\n",
         xlab, operation);

      fclose(outfile);

      /* R data */
      if ( !(outfile = fopen(dat_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", dat_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }                                                 /* if fopen() error */

      for (i=0 ; i<intervals ; i++ ) {
         if ( (fabsf(suppress)<FLT_EPSILON) || (curve[i].stats.n > 0)) 
            fprintf(outfile, "%12.6f %12.6f %6u %12.6f %12.6f\n", 
               curve[i].x, curve[i+1].x, curve[i].stats.n,
	       curve[i].stats.median, curve[i].stats.mean);
      }							/* for i */
      fclose(outfile);
      assert(!errno);
   }							/* if R */

  /*---------------------------------------------------------------
   * Post-conditions
   *---------------------------------------------------------------*/
   assert(!errno);
}						/* dump_curve() */
