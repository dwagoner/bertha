/***************************************************************************
 * stats.c - Routines to perform statistical summary operations. 
 *
 *-------------------------------------------------------------------------
 * Copyright 2006, Dave Wagoner
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *-------------------------------------------------------------------------
 * 
 *     Current summary stat are:
 *
 *		median, median, p75, p90, p95, max
 ***************************************************************************/

/*-------------------------------------------------------------------- 
 * fetch header files and macro definitions
 *-------------------------------------------------------------------*/
#include "./bertha.h"

/*-------------------------------------------------------------------- 
 * structures used only in this module
 * Only one of the two elements xput and mbytes is necessary; 
 *-------------------------------------------------------------------*/

/*-------------------------------------------------------------------- 
 * prototypes local to this module
 *-------------------------------------------------------------------*/
static int compare_float( void const *a, void const *b);

/*-------------------------------------------------------------------- 
 * macros used only in this module
 *-------------------------------------------------------------------*/
#define DUMP_STAT(A,B) {uint t; for (t=0;t<nprocs;t++) {if (!t) fprintf(outfile,A); fprintf(outfile,"%12.6f",(double)proc_stats[t].B);} fprintf(outfile,"\n"); }
#define DUMP_STAT_CSV(A,B) {uint t; for (t=0;t<nprocs;t++) {if (!t) fprintf(outfile,A); fprintf(outfile,",%12.6f",(double)proc_stats[t].B);} fprintf(outfile,"\n"); }

/***************************************************************************
 * dump_buckets() - routine to emit current array of collected metrics. 
 *                  This is the raw collected data from the run.
 ***************************************************************************/
void dump_buckets(struct bucket_rec *buckets, uint intervals,
                         char *operation, uint suppress, 
                         uint reports_requested[NUM_REPORT_TYPES],
                         char *report_prefix, char *test_timestamp, 
                         FILE *logptr)
{
   uint  this_interval;			      /* loop counter */
   char  report_filename[MAX_REPORTNAME_SIZE];
   char  dat_filename[MAX_REPORTNAME_SIZE];
   FILE *outfile;			      /* ptr to output (report) file*/
   char  error_msg[ERROR_MSG_MAX_LEN];   

  /*--------------------------------------------------------------------
   * Pre-conditions
   *--------------------------------------------------------------------*/
   assert(!errno);
   if (!buckets)   
      BAD_ARG_PTR(buckets,"buckets","dump_buckets","dump_buckets!=NULL");
   if (!intervals) 
      BAD_ARG_UINT(intervals, "intervals", "dump_buckets","intervals>0");
   if (!operation)   
      BAD_ARG_PTR(operation,"operation","dump_buckets","operation!=NULL");
   if (suppress>1) 
      BAD_ARG_UINT(suppress, "suppress", "dump_buckets","suppress={0,1}");
   if (!reports_requested)   
      BAD_ARG_PTR(reports_requested,"reports_requested","dump_buckets",
         "reports_requested!=NULL");
   if (!test_timestamp)   
      BAD_ARG_PTR(test_timestamp,"test_timestamp","dump_buckets",
         "test_timestamp!=NULL");
   if (!report_prefix)   
      BAD_ARG_PTR(report_prefix,"report_prefix","dump_buckets",
         "report_prefix!=NULL");
  /*--------------------------------------------------------------------*/

  /*--------------------------------------------------------------------
   * TEXT format
   *--------------------------------------------------------------------*/
   if ( reports_requested[TEXT] ) {
      strcpy(report_filename, report_prefix);
      strcat(report_filename, "time_");
      strcat(report_filename, operation);
      strcat(report_filename, ".txt");

      assert( strlen(report_filename) < MAX_REPORTNAME_SIZE);
      if ( !(outfile = fopen(report_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", report_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }                                                 /* if fopen() error */

      fprintf(outfile, "\n\n");
      fprintf(outfile, "                          %s Test Timeline\n\n", 
         operation);
      fprintf(outfile, "                Test started at: %s\n", 
         test_timestamp);
      fprintf(outfile, "Intrvl    Timestamp       IOPs       Throughput    ");
      fprintf(outfile, "MBytes        I/O\t\n");

      fprintf(outfile, "Number    (seconds)      Started     (MB/sec)      ");
      fprintf(outfile, "Moved     Concurrency\t\n\n");

      /* emit buckets in columns (text format output) */
      for ( this_interval=0; this_interval<intervals ; this_interval++ ) {
         if ( !suppress || (buckets[this_interval].io_started>0) ) 
            fprintf(outfile, "%6u  %12.6f %12lu %12.6f %12.6f %12.6f\n", 
	       this_interval, buckets[this_interval].tstamp, 
	       buckets[this_interval].io_started, buckets[this_interval].xput,
               buckets[this_interval].mbytes,
               buckets[this_interval].io_concurrency);
      }							/* for this_interval */
      fprintf(outfile,"\n\n");
      if (fclose(outfile)) {
         (void)snprintf(error_msg, ERROR_MSG_MAX_LEN, 
                   "fclose() failed on file %s\n", report_filename);
         io_error(error_msg);
      }							/* if fclose() */
      assert(!errno);
   }							/* if TEXT */

  /*---------------------------------------------------------------------
   *  CSV format
   *---------------------------------------------------------------------*/
   if ( reports_requested[CSV] ) {
      strcpy(report_filename, report_prefix);
      strcat(report_filename, "time_");
      strcat(report_filename, operation);
      strcat(report_filename, ".csv");

      assert( strlen(report_filename) < MAX_REPORTNAME_SIZE);
      if ( !(outfile = fopen(report_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", report_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }                                                 /* if fopen() error */

      fprintf(outfile, "\n\n");
      fprintf(outfile, "%s Test Timeline\n\n", 
         operation);
      fprintf(outfile, "Test started at:,%s\n", 
         test_timestamp);
      fprintf(outfile, "Intrvl,Timestamp,IOPs,Throughput,MBytes,I/O\n");

      fprintf(outfile, 
         "Number,(seconds),Started,(MB/sec),Moved,Concurrency\n\n");

      /* emit buckets in columns (text format output) */
      for ( this_interval=0; this_interval<intervals ; this_interval++ ) {
         if ( !suppress || (buckets[this_interval].io_started>0) ) 
            fprintf(outfile, "%6u,%12.6f,%12lu,%12.6f,%12.6f,%12.6f\n", 
	       this_interval, buckets[this_interval].tstamp, 
	       buckets[this_interval].io_started, buckets[this_interval].xput,
               buckets[this_interval].mbytes,
               buckets[this_interval].io_concurrency);
      }							/* for this_interval */
      fprintf(outfile,"\n\n");
      if (fclose(outfile)) {
         (void)snprintf(error_msg, ERROR_MSG_MAX_LEN, 
                   "fclose() failed on file %s\n", report_filename);
         io_error(error_msg);
      }							/* if fclose() */
      assert(!errno);
   }							/* if CSV */

  /*--------------------------------------------------------------------
   * SAS reports
   *--------------------------------------------------------------------*/
   if ( reports_requested[SAS] ) {
      strcpy(report_filename, report_prefix);
      strcat(report_filename, "time_");
      strcat(report_filename, operation);
      strcat(report_filename, ".sas");

      assert( strlen(report_filename) < MAX_REPORTNAME_SIZE);
      if ( !(outfile = fopen(report_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", report_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }                                                 /* if fopen() error */

      fprintf(outfile, "/************************************************\n");
      fprintf(outfile, " *\n");
      fprintf(outfile, " * time_%s.sas - produce simple charts to\n",operation);
      fprintf(outfile, " *     visualize data collected during\n");
      fprintf(outfile, " *     '%s' component of a Bertha test\n", operation);
      fprintf(outfile, " *\n");
      fprintf(outfile, " ************************************************/\n");
      fprintf(outfile, "\n");
      fprintf(outfile, "   data RAW;\n");
      fprintf(outfile, "\n");
      fprintf(outfile, "      label TSEC ='Seconds since test started';\n");
      fprintf(outfile, "      label IOPS_STARTED ='IOPs started during interval';\n");
      fprintf(outfile, "      label XPUT         ='Throughput (MB/sec)';\n");
      fprintf(outfile, "      label MB_MOVED     ='MB moved this interval';\n");
      fprintf(outfile, "      label CONCURRENCY  = 'I/O Concurrency';\n");
      fprintf(outfile, "\n");
      fprintf(outfile, "      format TSEC 6.1 IOPS_STARTED comma10.\n");
      fprintf(outfile, "             XPUT MB_MOVED CONCURRENCY 10.3;\n");
      fprintf(outfile, "\n");
      fprintf(outfile, "      input TSEC IOPS_STARTED XPUT MB_MOVED");
      fprintf(outfile, " CONCURRENCY;\n");
      fprintf(outfile, "      cards;\n");


      /* emit buckets in columns (text format output) */
      for ( this_interval=0; this_interval<intervals ; this_interval++ ) {
         if ( !suppress || (buckets[this_interval].io_started>0) ) 
            fprintf(outfile, "%12.6f %12lu %12.6f %12.6f %12.6f\n", 
	       buckets[this_interval].tstamp, 
	       buckets[this_interval].io_started, buckets[this_interval].xput,
               buckets[this_interval].mbytes,
               buckets[this_interval].io_concurrency);
      }							/* for this_interval */

      fprintf(outfile,";\n");
      fprintf(outfile,"   run;\n");
      fprintf(outfile,"\n");
      fprintf(outfile,"  /*---------------------------------------------\n");
      fprintf(outfile,"   * Prepare to emit chart(s)\n");
      fprintf(outfile,"   *---------------------------------------------*/\n");
      fprintf(outfile,"   goptions reset=all;\n\n");
      fprintf(outfile,"   title1 j=c 'Timeline During %s Test';\n",operation);
      fprintf(outfile,"   title2 j=c 'Test Run on: %s';\n",test_timestamp);
      fprintf(outfile,"   symbol1 color=black h=0.3 v=0.3 value=dot;\n");
      fprintf(outfile,"   symbol2 color=red   h=0.3 v=0.3 value=dot;\n");
      fprintf(outfile,"\n");
      fprintf(outfile,"  /*---------------------------------------------\n");
      fprintf(outfile,"   * emit chart(s)\n");
      fprintf(outfile,"   *---------------------------------------------*/\n");
      fprintf(outfile,"*  filename G '/var/tmp/time_%s_xput.gif';\n",operation);
      fprintf(outfile,"*  goptions dev=gif733 gsfname=G gsfmode=replace;\n");
      fprintf(outfile,"   proc gplot data=RAW;\n");
      fprintf(outfile,"      plot (XPUT) * TSEC /\n");
      fprintf(outfile,"         legend grid overlay;\n");
      fprintf(outfile,"   run;\n   quit;\n");
      fprintf(outfile,"\n");
      fprintf(outfile,"*  filename G '/var/tmp/time_%s_concurrency.gif';\n",
                  operation);
      fprintf(outfile,"*  goptions dev=gif733 gsfname=G gsfmode=replace;\n");
      fprintf(outfile,"   proc gplot data=RAW;\n");
      fprintf(outfile,"      plot (CONCURRENCY) * TSEC /\n");
      fprintf(outfile,"         legend grid overlay;\n");
      fprintf(outfile,"   run;\n   quit;\n");

      if (fclose(outfile)) {
         (void)snprintf(error_msg, ERROR_MSG_MAX_LEN, 
                   "fclose() failed on file %s\n", report_filename);
         io_error(error_msg);
      }							/* if fclose() */

      assert(!errno);
   }							/* if SAS */

  /*--------------------------------------------------------------------
   * GNU_PLOT reports
   *--------------------------------------------------------------------*/
   if ( reports_requested[GNU_PLOT] ) {
      /* gnuplot script name */
      strcpy(report_filename, report_prefix);
      strcat(report_filename, "time_");
      strcat(report_filename, operation);
      strcat(report_filename, ".gp");
      assert( strlen(report_filename) < MAX_REPORTNAME_SIZE);

      if ( !(outfile = fopen(report_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", report_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }                                                 /* if fopen() error */

      /* gnuplot raw data filename */
      strcpy(dat_filename, report_prefix);
      strcat(dat_filename, "time_");
      strcat(dat_filename, operation);
      strcat(dat_filename, ".gin");
      assert( strlen(dat_filename) < MAX_REPORTNAME_SIZE);

      /* gnuplot script*/
      fprintf(outfile, "#\n# gnuplot time-based data for %s\n#\n\n", operation);
      fprintf(outfile, "#\n# uncomment next two lines to produce"); 
      fprintf(outfile, " postscript output\n#\n\n");
      fprintf(outfile, "# set output \"gnuplot_%s.ps\"\n",operation);
      fprintf(outfile, "# set terminal postscript landscape\n\n");
      fprintf(outfile, "set grid\n");
      fprintf(outfile, 
          "set xlabel \"Time (Sec since beginning of test at %s)\"\n",
	  test_timestamp);
      fprintf(outfile, "set ylabel \"Throughput (MB/sec)\"\n\n");
      fprintf(outfile, "plot \"%s\" using 1:3 title \"MB/sec for %s test\"\n\n",
		dat_filename, operation);
      fprintf(outfile, "pause -1 \"Hit return for I/O Concurrency plot\"\n");
      fprintf(outfile, 
         "set ylabel \"I/O Concurrency (Number of Active I/Os)\"\n\n");
      fprintf(outfile, 
         "plot \"%stime_%s.gin\" using 1:5 title \"I/O Concurrency for %s test\"\n\n",
		report_prefix, operation, operation);
      fprintf(outfile, "\n");
      fclose(outfile);

      /* gnuplot data */
      if ( !(outfile = fopen(dat_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", dat_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }                                                 /* if fopen() error */

      /* emit buckets in columns (text format output) */
      for ( this_interval=0; this_interval<intervals ; this_interval++ ) {
         if ( !suppress || (buckets[this_interval].io_started>0) )  
            fprintf(outfile, "%12.6f %12lu %12.6f %12.6f %12.6f\n", 
	       buckets[this_interval].tstamp, 
	       buckets[this_interval].io_started, buckets[this_interval].xput,
               buckets[this_interval].mbytes,
               buckets[this_interval].io_concurrency);
      }							/* for this_interval */

      fclose(outfile);
      assert(!errno);
   } 							/* if GNU_PLOT */

  /*--------------------------------------------------------------------
   * R reports
   *--------------------------------------------------------------------*/
   if ( reports_requested[R] ) {
      /* R script name */
      strcpy(report_filename, report_prefix);
      strcat(report_filename, "time_");
      strcat(report_filename, operation);
      strcat(report_filename, ".r");
      assert( strlen(report_filename) < MAX_REPORTNAME_SIZE);

      if ( !(outfile = fopen(report_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", report_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }                                                 /* if fopen() error */

      /* R raw data filename */
      strcpy(dat_filename, report_prefix);
      strcat(dat_filename, "time_");
      strcat(dat_filename, operation);
      strcat(dat_filename, ".rin");
      assert(strlen(dat_filename) < MAX_REPORTNAME_SIZE);

      /* R script */
      fprintf(outfile, 
         "#\n# R script to generate time based plot for %s test\n#\n\n",
         operation);

      fprintf(outfile, 
         "#\n# Comment out following line to generate postscript output\n#\n");
      fprintf(outfile, "# postscript(\"%stime_%s_R.ps\")\n\n",
         report_prefix, operation);

      fprintf(outfile, "df1 <- read.table(\"%s\")\n", dat_filename);
      fprintf(outfile, "plot(df1[,1],df1[,3], ");
      fprintf(outfile, "xlab=\"Time (Sec since beginning of test at %s)\", ",
		test_timestamp);
      fprintf(outfile, "ylab=\"Throughput (MB/sec)\", ");
      fprintf(outfile, "main=\"Throughput for %s Test\", tck=1)\n", operation);
      fclose(outfile);

      /* R datafile*/
      if ( !(outfile = fopen(dat_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", dat_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }                                                 /* if fopen() error */

      /* emit buckets in columns (text format output) */
      for ( this_interval=0; this_interval<intervals ; this_interval++ ) {
         if ( !suppress || (buckets[this_interval].io_started>0) )  
            fprintf(outfile, "%12.6f %12lu %12.6f %12.6f %12.6f\n", 
	       buckets[this_interval].tstamp, 
	       buckets[this_interval].io_started, buckets[this_interval].xput,
               buckets[this_interval].mbytes,
               buckets[this_interval].io_concurrency);
      }							/* for this_interval */

      fclose(outfile);
      assert(!errno);
   }							/* if R */

  /*--------------------------------------------------------------------
   * Post-conditions
   *--------------------------------------------------------------------*/
   assert(!errno);					/* post condition */
}							/* dump_buckets() */

/***************************************************************************
 * dump_metrics() - diagnostic routine to emit current array of collected 
 *                  metrics. This is the raw collected data from the run.
 ***************************************************************************/
void dump_metrics(char *operation, struct metrics_rec *metrics, uint nprocs, 
               uint iops, char *report_prefix,
	       uint reports_requested[NUM_REPORT_TYPES], char *test_timestamp,
               uint replay_mono_file_flag, FILE *logptr)
{

   uint  this_iop, this_proc;
   uint  max_iop_rows;
   uint  m_index;
   char  report_filename[MAX_REPORTNAME_SIZE];
   FILE *outfile;		  /* file pointer for report to be generated */
   char  error_msg[ERROR_MSG_MAX_LEN];   

  /*--------------------------------------------------------------------
   * Pre-conditions
   *--------------------------------------------------------------------*/
   assert(!errno);
   if (!metrics)   
      BAD_ARG_PTR(metrics,"metrics","dump_metrics","metrics!=NULL");
   if (!nprocs)   BAD_ARG_UINT(nprocs, "nprocs", "dump_metrics","nprocs > 0");
   if (!iops)     BAD_ARG_UINT(iops,   "iops",   "dump_metrics","iops > 0");
   if (!report_prefix)   
      BAD_ARG_PTR(report_prefix,"report_prefix","dump_metrics",
                  "report_prefix!=NULL");
   if (!reports_requested)   
      BAD_ARG_PTR(reports_requested,"reports_requested",
                  "dump_metrics","reports_requested!=NULL");
   if (!test_timestamp) 
      BAD_ARG_PTR(test_timestamp,"test_timestamp",
         "dump_metrics","test_timestamp!=NULL");
   if (replay_mono_file_flag>1)   
      BAD_ARG_UINT(replay_mono_file_flag, "replay_mono_file_flag", 
                   "dump_metrics","replay_mono_file_flag={0,1}");
   if (!logptr) BAD_ARG_PTR(logptr,"logptr","dump_metrics","logptr!=NULL");
  /*--------------------------------------------------------------------*/

  /*--------------------------------------------------------------------
   *  TEXT reports
   *--------------------------------------------------------------------*/
   if ( reports_requested[TEXT] ) {
      strcpy(report_filename, report_prefix);
      strcat(report_filename, "raw_metrics_");
      strcat(report_filename, operation);
      strcat(report_filename, ".txt");
      assert( strlen(report_filename) < MAX_REPORTNAME_SIZE);
      if ( !(outfile = fopen(report_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", report_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }							/* if fopen() error */
      fprintf(outfile, "\nRaw Metrics Dump:\n-----------------\n");
      fprintf(outfile, "\nTest Run: %s\n\n",test_timestamp);
      fprintf(outfile, 
         "\tNumber of Processes:%12u\n\tNumber of IOPS:     %12u\n\n", 
         nprocs, iops);

   /* emit headers for output table */
      fprintf(outfile,"     ");
      for (this_proc=0; this_proc < nprocs; this_proc++) 
         fprintf(outfile,"       Process %6u %3s",this_proc,"");
      fprintf(outfile,"\n");

      fprintf(outfile,"      ");
      for (this_proc=0 ; this_proc < nprocs ; this_proc++ ) 
         fprintf(outfile," ----------------------- ");
      fprintf(outfile,"\n");

      fprintf(outfile,"IOP# ");
      for (this_proc=0 ; this_proc < nprocs ; this_proc++ ) 
         fprintf(outfile,"   Timestamp    Rsp (ms) ");
      fprintf(outfile,"\n\n");
   
      /* emit table contents, show rsp time in milliseconds */
      if (replay_mono_file_flag) 
         max_iop_rows = (iops/nprocs) + (iops - nprocs*(iops/nprocs));
      else 
         max_iop_rows = iops;

      for ( this_iop=0; this_iop < max_iop_rows; this_iop++ ) {
         fprintf(outfile,"%5u ",this_iop);
         for ( this_proc=0; this_proc < nprocs; this_proc++ ) {
            if (replay_mono_file_flag) 
               m_index = this_proc*(iops/nprocs) + this_iop;
            else 
               m_index = this_iop*nprocs+this_proc;

           /*
            * for concurrent replay mode, the number of IOPs in the 
            * transaction file may not be an integral number of nprocs. In 
            * this case, the last process executes the remainder of the IOPS;
            * when emitting output, blanks to properly space output.
            */
            if (replay_mono_file_flag  && (this_iop >= (iops/nprocs)) &&
			(this_proc < (nprocs-1)) ) {
               /* fprintf(outfile,"%11s %11s      ","",""); */
               fprintf(outfile,"                         ");
            } else {
               fprintf(outfile,"%11.6f %11.6f  ",
		   metrics[m_index].tstamp,
		   metrics[m_index].rsp_time * 1000);
            }						/* if replay */
         }						/* for this_iop */
         fprintf(outfile,"\n");
      }							/* for this_proc */

      if (fclose( outfile )) {
         (void)snprintf(error_msg, ERROR_MSG_MAX_LEN, 
                   "fclose() failed on file %s\n", report_filename);
         io_error(error_msg);
      }							/* if fclose() */
      assert(!errno);
   } 							/* if TEXT */

  /*--------------------------------------------------------------------
   *  CSV reports
   *--------------------------------------------------------------------*/
   if ( reports_requested[CSV] ) {
      strcpy(report_filename, report_prefix);
      strcat(report_filename, "raw_metrics_");
      strcat(report_filename, operation);
      strcat(report_filename, ".csv");
      assert( strlen(report_filename) < MAX_REPORTNAME_SIZE);
      if ( !(outfile = fopen(report_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", report_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }							/* if fopen() error */
      fprintf(outfile, "\nRaw Metrics Dump:\n-----------------\n");
      fprintf(outfile, "\nTest Run:,%s\n\n",test_timestamp);
      fprintf(outfile, 
         "\tNumber of Processes:,%12u,\n\tNumber of IOPS:,%12u\n\n", 
         nprocs, iops);

   /* emit headers for output table */
      fprintf(outfile,"Process,");
      for (this_proc=0; this_proc < nprocs; this_proc++) 
         fprintf(outfile,"%6u,,",this_proc);
      fprintf(outfile,"\n");

      fprintf(outfile,",");
      for (this_proc=0 ; this_proc < nprocs ; this_proc++ ) 
         fprintf(outfile,"-----,------,");
      fprintf(outfile,"\n");

      fprintf(outfile,"IOP#,");
      for (this_proc=0 ; this_proc < nprocs ; this_proc++ ) 
         fprintf(outfile,"   Timestamp,    Rsp (ms), ");
      fprintf(outfile,"\n\n");
   
      /* emit table contents, show rsp time in milliseconds */
      if (replay_mono_file_flag) 
         max_iop_rows = (iops/nprocs) + (iops - nprocs*(iops/nprocs));
      else 
         max_iop_rows = iops;

      for ( this_iop=0; this_iop < max_iop_rows; this_iop++ ) {
         fprintf(outfile,"%5u,",this_iop);
         for ( this_proc=0; this_proc < nprocs; this_proc++ ) {
            if (replay_mono_file_flag) 
               m_index = this_proc*(iops/nprocs) + this_iop;
            else 
               m_index = this_iop*nprocs+this_proc;

           /*
            * for concurrent replay mode, the number of IOPs in the 
            * transaction file may not be an integral number of nprocs. In 
            * this case, the last process executes the remainder of the IOPS;
            * when emitting output, blanks to properly space output.
            */
            if (replay_mono_file_flag  && (this_iop >= (iops/nprocs)) &&
			(this_proc < (nprocs-1)) ) {
               fprintf(outfile,"                         ");
            } else {
               fprintf(outfile,"%11.6f,%11.6f, ",
		   metrics[m_index].tstamp,
		   metrics[m_index].rsp_time * 1000);
            }						/* if replay */
         }						/* for this_iop */
         fprintf(outfile,"\n");
      }							/* for this_proc */

      if (fclose( outfile )) {
         (void)snprintf(error_msg, ERROR_MSG_MAX_LEN, 
                   "fclose() failed on file %s\n", report_filename);
         io_error(error_msg);
      }							/* if fclose() */
      assert(!errno);
   }							/* if CSV */

  /*--------------------------------------------------------------------
   * Post-conditions
   *--------------------------------------------------------------------*/
   assert(!errno);					/* post condition */
}					        	/* dump_metrics */

/***************************************************************************
 * summarize_metrics_proc() - provide statistics summary of rsp time 
 *     by individual process. This is useful in spotting anomalies during 
 *     a test; that is, some degree of assurance that the test was reasonable
 *     can be gained by comparing results for each process - the summary
 *     statistics should be comparable for a valid test. 
 *
 *     The output of this routine is more for diagnostics than producing 
 *     comparable numbers when running benchmarks. The routine 
 *     summarize_metric() is more useful for comparitive adventures.
 ***************************************************************************/
void summarize_metrics_proc(
		char 		   *operation, 
		struct metrics_rec *metrics, 
                uint 		    nprocs, 
		uint 		    iops, 		/* iops per process */
                uint    	    reports_requested[NUM_REPORT_TYPES],
                char 		   *report_prefix,
		uint		    replay_mono_file_flag,
                char 		   *test_timestamp,
                FILE               *logptr
            )
{
   uint   this_proc, this_iop;  /* loop counters */
   uint   iops_this_proc;	/* for replay, concurrent procs do only
                                 * a portion of total transactions. The
                                 * number of iops per proc for 
                                 * concurrent procs needs to be 
                                 * determined. 
                                 */

   float *w;			/* pointer to work array */
   uint   m_index;		/* index into struct metrics */
   uint   w_size;		/* size of w[] array for stats summary*/
   FILE  *outfile;		/* ptr to report output */

   char   report_filename[MAX_REPORTNAME_SIZE];
   char   error_msg[ERROR_MSG_MAX_LEN];

   struct summary_rec *proc_stats;  /* ptr to array of process summary stats */
   
  /*--------------------------------------------------------------------
   * Pre-conditions
   *--------------------------------------------------------------------*/
   assert(!errno);
   if (!operation)   
      BAD_ARG_PTR(operation,"operation","summarize_metrics_proc",
                  "operation!=NULL");
   if (!metrics)   
      BAD_ARG_PTR(metrics,"metrics","summarize_metrics_proc","metrics!=NULL");
   if (!nprocs)   
      BAD_ARG_UINT(nprocs, "nprocs", "summarize_metrics_proc","nprocs > 0");
   if (!iops)     
      BAD_ARG_UINT(iops,   "iops",   "summarize_metrics_proc","iops > 0");
   if (!reports_requested)   
      BAD_ARG_PTR(reports_requested,"reports_requested",
                  "summarize_metrics_proc","reports_requested!=NULL");
   if (!report_prefix)   
      BAD_ARG_PTR(report_prefix,"report_prefix","summarize_metrics_proc",
                  "report_prefix!=NULL");
   if (replay_mono_file_flag > 1)
      BAD_ARG_UINT(replay_mono_file_flag, "replay_mono_file_flag", 
                   "summarize_metrics_proc","replay_mono_file_flag>0");
   if (!test_timestamp) 
      BAD_ARG_PTR(test_timestamp,"test_timestamp",
         "summarize_metrics_proc","test_timestamp!=NULL");
   if (!logptr) 
      BAD_ARG_PTR(logptr,"logptr","summarize_metrics_proc","logptr!=NULL");
  /*--------------------------------------------------------------------*/

   /*
    * for replay, if replay_mono_file_flag is set, then each process ran 
    * a subset of transactions, but each transaction was run precisely once.
    * The variable iops is interpreted as iops per process, so need to adjust
    * this value to reflect that transactions are done once.
    */

   if ( replay_mono_file_flag ) { 
      /*
       * number of transactions for replay may not be an integral number
       * if nprocs; need to have w[] sized to accommodate the largest case,
       * which is the last process - the process that handles the remainder
       * transactions.
       */
      w_size = (iops/nprocs) + iops - (nprocs * (iops/nprocs));
   } else {
      w_size = iops;
   }

   if ( !(proc_stats = malloc( sizeof(struct summary_rec)*nprocs ))) {
      fprintf(logptr, "Cannot malloc() space for proc_stats array\n");
      terminate( EXIT_MALLOC_FAILURE );
   }						/* if malloc() */

   /* Dynamically allocate memory for work array; */
   if ( !(w = malloc((w_size) * sizeof(float))) ) {
      fprintf(logptr, 
         "Could not malloc() for summarize_metrics_proc work array\n");
      terminate( EXIT_MALLOC_FAILURE );
   }							      /* if malloc() */

   /*
    *  first, show results by individual processes to identify any problem
    *  children that may be distorting results  
    */
   for ( this_proc=0 ; this_proc<nprocs ; this_proc++ ) {
      
      if (replay_mono_file_flag) {
         if ( this_proc < (nprocs - 1)) iops_this_proc = iops/nprocs;
         else     iops_this_proc = iops/nprocs + (iops - nprocs*(iops/nprocs));
      } else 
         iops_this_proc = iops;

      for (this_iop=0 ; this_iop<iops_this_proc ; this_iop++) {
         if (replay_mono_file_flag) 
            m_index = this_proc * (iops/nprocs) + this_iop;
         else 
            m_index = this_iop * nprocs + this_proc;

         /* convert seconds to milliseconds here */
         w[this_iop] = (metrics[ m_index ].rsp_time) * 1000; 
      }						/* for each iop */
      
      /* fetch summary statistics */

      proc_stats[this_proc] = do_stats(w, iops_this_proc);
   }							/* for each proc */

   assert( !errno );

   /*------------------------------------------------------------------
    * TEXT
    *------------------------------------------------------------------*/
   if (reports_requested[TEXT]) {
      strcpy(report_filename, report_prefix);
      strcat(report_filename, "proc_summaries_");
      strcat(report_filename, operation);
      strcat(report_filename, ".txt" );
      assert( strlen(report_filename)<MAX_REPORTNAME_SIZE );

      if ( !(outfile = fopen(report_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", report_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }						/* fopen() */

      fprintf(outfile, "\n\n\t                     %s\n",operation);
      fprintf(outfile, "\n\t         Test Run: %s\n\n",test_timestamp);
      fprintf(outfile, 
         "\tResponse Time (msec) Metrics Summary for Each Process\n\n");

      fprintf(outfile, "\n\nProc Num:");
      for (this_proc=0; this_proc<nprocs; this_proc++) 
         fprintf(outfile, "   %5u    ", this_proc);
      fprintf(outfile, "\n\n");

      /* 
       * emit summary metrics by process; this output appended after output of
       * dump_metrics() 
       */
      DUMP_STAT("Min:      ",  min);
      DUMP_STAT("Median:   ",  median);
      DUMP_STAT("Avg:      ",  mean);
      DUMP_STAT("75 %%tile: ", p75);
      DUMP_STAT("90 %%tile: ", p90);
      DUMP_STAT("95 %%tile: ", p95);
      DUMP_STAT("99 %%tile: ", p99);
      DUMP_STAT("Max:      ",  max);
      DUMP_STAT("N:        ",  n);
      DUMP_STAT("Stddev:   ",  stddev);

      if (fclose( outfile )) {
         (void)snprintf(error_msg, ERROR_MSG_MAX_LEN, 
                   "fclose() failed on file %s\n", report_filename);
         io_error(error_msg);
      }							/* if fclose() */
      assert(!errno);
   }							/* if TEXT */

   /*------------------------------------------------------------------
    * CSV
    *------------------------------------------------------------------*/
   if (reports_requested[CSV]) {
      strcpy(report_filename, report_prefix);
      strcat(report_filename, "proc_summaries_");
      strcat(report_filename, operation);
      strcat(report_filename, ".csv" );
      assert( strlen(report_filename)<MAX_REPORTNAME_SIZE );

      if ( !(outfile = fopen(report_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", report_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }						/* fopen() */

      fprintf(outfile, "%s\n",operation);
      fprintf(outfile, "Test Run:,%s\n\n",test_timestamp);
      fprintf(outfile, 
         "\tResponse Time (msec) Metrics Summary for Each Process\n\n");

      fprintf(outfile, "\n\nProc Num:,");
      for (this_proc=0; this_proc<nprocs; this_proc++) 
         fprintf(outfile, "%5u,", this_proc);
      fprintf(outfile, "\n\n");

      /* 
       * emit summary metrics by process; this output appended after output of
       * dump_metrics() 
       */
      DUMP_STAT_CSV("Min:      ",  min);
      DUMP_STAT_CSV("Median:   ",  median);
      DUMP_STAT_CSV("Avg:      ",  mean);
      DUMP_STAT_CSV("75 %%tile: ", p75);
      DUMP_STAT_CSV("90 %%tile: ", p90);
      DUMP_STAT_CSV("95 %%tile: ", p95);
      DUMP_STAT_CSV("99 %%tile: ", p99);
      DUMP_STAT_CSV("Max:      ",  max);
      DUMP_STAT_CSV("N:        ",  n);
      DUMP_STAT_CSV("Stddev:   ",  stddev);

      if (fclose( outfile )) {
         (void)snprintf(error_msg, ERROR_MSG_MAX_LEN, 
                   "fclose() failed on file %s\n", report_filename);
         io_error(error_msg);
      }							/* if fclose() */
      assert(!errno);
   }							/* if CSV */


   /*------------------------------------------------------------------
    * Cleanup - free dynamically allocated memory
    *------------------------------------------------------------------*/
   free( proc_stats ); /* relinquish dynamically allocated mem for stats*/ 
   free(w);		

  /*--------------------------------------------------------------------
   * Post-conditions
   *--------------------------------------------------------------------*/
   assert(!errno);
}						/* summarize_metrics_proc() */

/***************************************************************************
 * summarize_metric () - provide statistical summary of a specific metric
 ***************************************************************************/
void summarize_metric (	   
	       char 		  *operation, 
	       char 		  *summary_title, 
	       struct metrics_rec *metrics, 
	       uint 	           nprocs, 
	       uint 	           iops, 
               uint                reports_requested[NUM_REPORT_TYPES],
               char 		  *report_prefix,
   	       uint		   replay_mono_file_flag,
               char 		  *test_timestamp,
               FILE               *logptr
             )
{
   uint   this_iop;		        /* loop counters */
   float *w;				/* pointer to work array */
   uint   n = 0;			/* loop ctr for temp array */
   uint   num_vals;                     /* num of vals in tmp array */
   uint   non_zero_vals;                /* num of non-null vals in tmp array */
   char   report_filename[MAX_REPORTNAME_SIZE];
   char   error_msg[ERROR_MSG_MAX_LEN];
   FILE  *outfile;

   struct summary_rec  all_stats;   /* summary stats for entire data set */

  /*--------------------------------------------------------------------
   * Pre-conditions 
   *--------------------------------------------------------------------*/
   assert(!errno);
   if (!operation)   
      BAD_ARG_PTR(operation,"operation","summarize_metric", "operation!=NULL");
   if (!summary_title)   
      BAD_ARG_PTR(summary_title,"summary_title","summarize_metric", 
                  "summary_title!=NULL");
   if (!metrics)   
      BAD_ARG_PTR(metrics,"metrics","summarize_metric","metrics!=NULL");
   if (!nprocs)   
      BAD_ARG_UINT(nprocs, "nprocs", "summarize_metric","nprocs>0");
   if (!iops)     
      BAD_ARG_UINT(iops,   "iops",   "summarize_metric","iops>0");
   if (!reports_requested)   
      BAD_ARG_PTR(reports_requested,"reports_requested",
                  "summarize_metric","reports_requested!=NULL");
   if (!report_prefix)   
      BAD_ARG_PTR(report_prefix,"report_prefix","summarize_metric",
                  "report_prefix!=NULL");
   if (replay_mono_file_flag > 1)
      BAD_ARG_UINT(replay_mono_file_flag, "replay_mono_file_flag", 
                   "summarize_metric","replay_mono_file_flag={0,1}");
   if (!test_timestamp) 
      BAD_ARG_PTR(test_timestamp,"test_timestamp",
         "summarize_metric","test_timestamp!=NULL");
   if (!logptr) 
      BAD_ARG_PTR(logptr,"logptr","summarize_metric","logptr!=NULL");
  /*------------------------------------------------------------------*/

   /* number of values in temporary array */
   if ( replay_mono_file_flag ) num_vals = iops;
   else                          num_vals = iops * nprocs;

   /*
    * Dynamically allocate memory for work array; 
    */
   if ( !(w = malloc(num_vals * sizeof(float))) ) {
     fprintf(logptr,
         "Could not malloc() for summarize_metrics_proc work array\n");
      terminate( EXIT_MALLOC_FAILURE );
   }							/* if malloc() */

   /*
    * load array for summarization by do_stats()
    */
   for ( this_iop=0, non_zero_vals=0 ; this_iop<num_vals; this_iop++ ) {
        /*
         * A "null" transaction may appear in the metrics in the case when
         * a replay is done and the number of transactions in the tracefile
         * is not an integral number of nprocs. Skip "null" transactions.
         */
         if (replay_mono_file_flag&&(metrics[this_iop].io_size<=0)) 
            continue;

         /* convert seconds to milliseconds here */
         non_zero_vals++;
         w[n++] = (metrics[this_iop].rsp_time) * 1000; 
         assert( (n <= num_vals) && (n <= non_zero_vals) );
      }						/* for each iop */

   all_stats = do_stats(w, non_zero_vals);
   assert(!errno);

   /*---------------------------------------------------------------
    * TEXT
    *---------------------------------------------------------------*/
   if (reports_requested[TEXT]) {
      strcpy(report_filename, report_prefix);
      strcat(report_filename, "summary_");
      strcat(report_filename, operation);
      strcat(report_filename, ".txt" );
      assert( strlen(report_filename)<MAX_REPORTNAME_SIZE );

      if ( !(outfile = fopen(report_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", report_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }						

      fprintf(outfile, "\n\n\t                     %s %s\n",
                 operation, summary_title);
      fprintf(outfile, "\n\t              Test Run: %s\n\n", test_timestamp);
      fprintf(outfile,  
                 "\tResponse Time (msec) Metrics Summary for Entire Run\n\n");

      fprintf(outfile, "\n\n");
      fprintf(outfile, "Min:      %12.6f\n",   all_stats.min);
      fprintf(outfile, "Median:   %12.6f\n",   all_stats.median);
      fprintf(outfile, "Avg:      %12.6f\n",   all_stats.mean);
      fprintf(outfile, "75 %%tile: %12.6f\n",  all_stats.p75);
      fprintf(outfile, "90 %%tile: %12.6f\n",  all_stats.p90);
      fprintf(outfile, "95 %%tile: %12.6f\n",  all_stats.p95);
      fprintf(outfile, "99 %%tile: %12.6f\n",  all_stats.p99);
      fprintf(outfile, "Max:      %12.6f\n",   all_stats.max);
      fprintf(outfile, "Num Vals: %12u\n",     all_stats.n);
      fprintf(outfile, "Stddev:   %12.6f\n\n", all_stats.stddev);

      if (fclose( outfile )) {
         (void)snprintf(error_msg, ERROR_MSG_MAX_LEN, 
                   "fclose() failed on file %s\n", report_filename);
         io_error(error_msg);
      }							/* if fclose() */
      assert(!errno);
   }							/* if TEXT */

   /*---------------------------------------------------------------
    * CSV 
    *---------------------------------------------------------------*/
   if (reports_requested[CSV]) {
      strcpy(report_filename, report_prefix);
      strcat(report_filename, "summary_");
      strcat(report_filename, operation);
      strcat(report_filename, ".csv" );
      assert( strlen(report_filename)<MAX_REPORTNAME_SIZE );

      if ( !(outfile = fopen(report_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", report_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }						

      fprintf(outfile, "\n\n\t                     %s %s\n",
                 operation, summary_title);
      fprintf(outfile, "\nTest Run:,%s\n\n", test_timestamp);
      fprintf(outfile,  
                 "\tResponse Time (msec) Metrics Summary for Entire Run\n\n");

      fprintf(outfile, "\n\n");
      fprintf(outfile, "Min:,     %12.6f\n",   all_stats.min);
      fprintf(outfile, "Median:,  %12.6f\n",   all_stats.median);
      fprintf(outfile, "Avg:,     %12.6f\n",   all_stats.mean);
      fprintf(outfile, "75 %%tile:,%12.6f\n",  all_stats.p75);
      fprintf(outfile, "90 %%tile:,%12.6f\n",  all_stats.p90);
      fprintf(outfile, "95 %%tile:,%12.6f\n",  all_stats.p95);
      fprintf(outfile, "99 %%tile:,%12.6f\n",  all_stats.p99);
      fprintf(outfile, "Max:,     %12.6f\n",   all_stats.max);
      fprintf(outfile, "Num Vals:,%12u\n",     all_stats.n);
      fprintf(outfile, "Stddev:,  %12.6f\n\n", all_stats.stddev);

      if (fclose( outfile )) {
         (void)snprintf(error_msg, ERROR_MSG_MAX_LEN, 
                   "fclose() failed on file %s\n", report_filename);
         io_error(error_msg);
      }							/* if fclose() */
      assert(!errno);
   }							/* if CSV*/

   free(w);		

  /*--------------------------------------------------------------------
   * Post-conditions 
   *--------------------------------------------------------------------*/
   assert(!errno);
}					        /* summarize_metric() */

/***************************************************************************
 * do_stats() - given an arbitrary array of floating point values, return
 *              summary statistics (min, max, median, avg, percentiles, stddev).
 ***************************************************************************/
struct summary_rec do_stats(float *w, uint n)
{
   struct summary_rec retval;
   uint               i;		/* loop variable */
   float              variance; 

  /*--------------------------------------------------------------------
   * Pre-conditions
   *--------------------------------------------------------------------*/
   assert(!errno);
   if ( !w )   BAD_ARG_PTR(w,"w","do_stats","w!=NULL");
   if ( !n )   BAD_ARG_UINT(n,"n","do_stats","n>0");
  /*--------------------------------------------------------------------*/

  /*--------------------------------------------------------------------
   * generate stats
   *--------------------------------------------------------------------*/
   /* array must be sorted to obtain useful percentiles */
   qsort((void *)w, (size_t)n, sizeof(float), compare_float);

   /* fetch the percentiles */
      if (!(n % 2)) {
         retval.median = 
               (float)((w[(int)(((n-1)/2))]+w[(int)(((n-1)/2)+1)])/2.0);
      } else {
         retval.median = (float)(w[(int)((n-1)/2)]);
      }
      
      retval.min = w[0];
      retval.p75 = w[(int)((n-1)*0.75)];
      retval.p90 = w[(int)((n-1)*0.90)];
      retval.p95 = w[(int)((n-1)*0.95)];
      retval.p99 = w[(int)((n-1)*0.99)];
      retval.n   = n;
      retval.max = w[n-1];

      /* assert(retval.min <= retval.max);  verify compare_float() working */

      /* derive mean */
      retval.mean = 0;
      if ( !n ) retval.mean = 0;
      else {
         for ( i=0; i<n ; i++ ) retval.mean += w[i];
         retval.mean /= n;
      }							/* if n */

      /* summarize variability by obtaining standard deviation */
      variance = 0;
      for ( i=0; i<n; i++ ) {
         variance += pow( (w[i] - retval.mean), 2);
      }
      retval.stddev = (float)sqrt(variance);

  /*--------------------------------------------------------------------
   * Post-conditions
   *--------------------------------------------------------------------*/
   assert(!errno);
  /*--------------------------------------------------------------------*/

   return( retval );
}						/* do_stats() */

/***************************************************************************
 * compare_float() - comparison routine used for qsort(3)
 ***************************************************************************/
static int compare_float( void const *a, void const *b) 
{
   float af;
   float bf;

  /*--------------------------------------------------------------
   * Pre-conditions
   *--------------------------------------------------------------*/
   if (!a) BAD_ARG_PTR(a,"a","compare_float","a!=NULL");
   if (!b) BAD_ARG_PTR(b,"b","compare_float","a!=NULL");
  /*--------------------------------------------------------------*/

   /* keep the compiler warnings quiet by assigning to values to floats */
   af = *(float *)a;
   bf = *(float *)b;

   if ((af-bf)    <FLT_EPSILON) return(-1);
   if (fabs(af-bf)<FLT_EPSILON) return( 0);
   return (1);
}						/* compare_float() */

