/*---------------------------------------------------------------------
 * histograms.c - Routines to generate histograms 
 *
 *-------------------------------------------------------------------------
 * Copyright 2006, Dave Wagoner
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *-------------------------------------------------------------------------
 *
 *
 * At present, histograms generated are:
 *
 *       Response time, by I/O Operation
 *       Aggregate Bertha Throughput, by each time increment during run
 *       I/O concurrency level, by each time increment during run
 *--------------------------------------------------------------------------*/

/*-------------------------------------------------------------------- 
 * fetch header files and macro definitions
 *-------------------------------------------------------------------*/
#include "./bertha.h"

/*-------------------------------------------------------------------- 
 * structures used only in this module
 * Only one of the two elements xput and mbytes is necessary; 
 *-------------------------------------------------------------------*/
struct histogram_rec {
   float x;		/* bucket start point */
   uint  y;  		/* aggregated variable for this bucket */
} histogram_rec;

/*-------------------------------------------------------------------- 
 * prototypes local to this module
 *-------------------------------------------------------------------*/
static void dump_histogram( struct histogram_rec *hist, float bucket_size,
               uint elements, float suppress, 
               char *operation /* {read|write|re-write} */,
               char *histogram_name, char *histogram_title,
               uint reports_requested[NUM_REPORT_TYPES], char *report_prefix,
	       char *test_timestamp, FILE *logptr);

/***************************************************************************
 * do_histograms() - 
 ***************************************************************************/
void do_histograms(struct metrics_rec *metrics, 
			  float  hist_args[NUM_CHARTS][NUM_CHART_PARMS],
                          struct time_range_rec time_bounds, 
			  char *operation, char *report_prefix, uint nprocs, 
	                  uint iops, uint reports_requested[NUM_REPORT_TYPES],
			  FILE *logptr, uint verbose, 
                          uint replay_mono_file_flag, char *test_timestamp)
{
   uint    i;				/* loop counter */
   float  *w;				/* tmp array for values to histogram */
   uint    hist_intervals;		/* number of intervals in histogram */
   struct  summary_rec range;		/* will contain range of variable */
   struct  histogram_rec *rsp_hist;     /* histogram for response times */
   struct  histogram_rec *xput_hist;    /* histogram for aggregate thruput */
   struct  histogram_rec *concurrency_hist; /* histogram for io concurrency */
   uint    this_proc, this_iop;		/* loop counters */
   uint    m_index;			/* index into metrics array */
   struct  bucket_rec *io_buckets;	/* pointer to array of hist buckets */
   uint    io_bucket_intervals;		/* number of buckets in histogram */
   uint    concurrent_nprocs; 		/* number of concurrent procs - used
 					 * to address metrics data. This value
                                         * is adjusted to accommodate replay
                                         * tests, where each process *may*
					 * be performing only a subset of the
                                         * transactions in the tracefile.
                                         */
   
  /*---------------------------------------------------------------
   * Pre-conditions
   *---------------------------------------------------------------*/
   assert(!errno);
   if (!metrics) 
      BAD_ARG_PTR(metrics,  "metrics",  "do_histograms","metrics!=NULL");
   if (!hist_args) 
      BAD_ARG_PTR(hist_args,"hist_args","do_histograms","operation!=NULL");
   if ( (time_bounds.end - time_bounds.begin) < DBL_EPSILON ) 
      BAD_ARG_FLOAT(time_bounds.end,"time_bounds","do_histograms",
                    "time_bounds.begin<=time_bound.end");
   if (!operation) 
      BAD_ARG_PTR(operation,"operation","do_histograms","operation!=NULL");
   if (!report_prefix) 
      BAD_ARG_PTR(report_prefix,"report_prefix",
                  "do_histograms","report_prefix!=NULL");
   if (!nprocs) BAD_ARG_UINT(nprocs, "nprocs", "do_histograms","nprocs>0");
   if (!iops)   BAD_ARG_UINT(iops,   "iops",   "do_histograms","iops>0");
   if (!reports_requested)   
      BAD_ARG_PTR(reports_requested,"reports_requested",
                  "do_histograms","reports_requested!=NULL");
   if (!logptr) 
      BAD_ARG_PTR(logptr,  "logptr",  "do_histograms","logptr!=NULL");
   if (replay_mono_file_flag > 1)
      BAD_ARG_UINT(replay_mono_file_flag, "replay_mono_file_flag", 
                   "do_histograms","replay_mono_file_flag={0,1}");
   if (!test_timestamp) 
      BAD_ARG_PTR(test_timestamp,  "test_timestamp",  "do_histograms",
         "test_timestamp!=NULL");
  /*-----------------------------------------------------------------*/

  /*----------------------------------------------------------------- 
   * histogram of response times 
   *-----------------------------------------------------------------*/
   io_bucket_intervals   = (uint)(MAX(1,(((time_bounds.end-time_bounds.begin) / 
			            hist_args[RSP_TIME][TIME_INTERVAL])+2)));
   io_buckets = bucketize(metrics, nprocs, iops, 
                    time_bounds, hist_args[RSP_TIME][TIME_INTERVAL],
                    io_bucket_intervals, "rsp time histogram", logptr, verbose,
		    replay_mono_file_flag);

   if ( replay_mono_file_flag ) concurrent_nprocs = 1;
   else                          concurrent_nprocs = nprocs;

   /*
    * Dynamically allocate memory for work array; this array will be used to
    * derive min & max of range of buckets
    */
   if ( !(w = malloc(concurrent_nprocs * iops * sizeof(float))) ) {
      fprintf(logptr, "Could not malloc() for do_histograms() work array\n");
   }							/* if malloc() */

   /* find range of values, load w with rsp_times and run do_stats() on w... */
   for ( this_proc=0, i=0 ; this_proc<concurrent_nprocs; this_proc++ ) {
      for ( this_iop=0 ; this_iop<iops ; this_iop++ ) {
         m_index = this_iop * concurrent_nprocs + this_proc;
         assert(m_index < (concurrent_nprocs * iops));
         w[i++] = metrics[m_index].rsp_time;
      }							/* for this_iop */
   }							/* for this_proc */

   /* do_stats() to find min,max of data; needed for finding # of intervals */
   range = do_stats(w, (concurrent_nprocs * iops));
   range.min = (float)((uint)range.min); /* round down to next lowest int */

   /*
    * determine number of intervals for histogram; need to add one 
    * to accommodate the lowest interval
    */
   hist_intervals = (uint)((range.max - range.min) /
				         hist_args[RSP_TIME][TIME_INTERVAL]+1);

   /*
    * allocate array to contain histogram data; need to allocate 
    * hist_intervals + 1 because the algorithm below is accessing
    * the next interval to identify where the current interval ends. Note
    * that the loop below reads "i <= hist_intervals", not "i < hist_intervals"
    */
   if ( !(rsp_hist = (struct histogram_rec *)malloc( 
              (size_t)((hist_intervals+1) * sizeof( struct histogram_rec ))))){
      fprintf(logptr, "Could not malloc() for do_hist array for rsp_hist\n");
      terminate( EXIT_MALLOC_FAILURE );
   }							/* if malloc() */

   /* intialize buckets in histogram array */
   for ( i=0 ; i<=hist_intervals ; i++)  {
      rsp_hist[i].x = (float)((i*hist_args[RSP_TIME][TIME_INTERVAL])+range.min) 
			    * 1000; /* sec->ms */
      rsp_hist[i].y = 0;
   }							/* for i */

   /* populate histogram with response time values from w[] */ 
   for ( i=0  ;  i < (concurrent_nprocs * iops)  ;  i++ ) {
      assert( ((uint)((w[i] - range.min ) / hist_args[RSP_TIME][TIME_INTERVAL]))
			< hist_intervals);
     /* 
      * count only non-zero values; assumption here is that zero values will
      * occur before and after IOPs. If zero values occur in the middle of the
      * test, this will appear in the time plots - this also means that much
      * larger problems are being experienced...
      */
      if (w[i] > FLT_EPSILON)
         rsp_hist[(uint)((w[i]-range.min)
                                    /hist_args[RSP_TIME][TIME_INTERVAL])].y++;
   }							/* for i */

   /* suppress set to 1 for now - remove empty buckets from histogram */
   dump_histogram( rsp_hist, hist_args[RSP_TIME][TIME_INTERVAL], hist_intervals,
       hist_args[RSP_TIME][SUPPRESS_ZERO], operation, "rsp", 
       "I/O Response Time (ms)", reports_requested, report_prefix, 
       test_timestamp, logptr); 
   free(rsp_hist);			/* release mem containging histogram */
   free(w);				/* deallocate mem for scratch array */
   assert(!errno);

   /*----------------------------------------------------------------- 
    * histogram of aggregate throughput
    *-----------------------------------------------------------------*/
   /* 
    * Raw metric data has been bucketized; only rebucketize iff necessary;
    * if same time intervals are to be used, rebucketizing would be redundant.
    */
   if ( (fabsf(hist_args[RSP_TIME][TIME_INTERVAL] 
            - hist_args[XPUT][TIME_INTERVAL])
            <FLT_EPSILON) 
      )  {

      free_io_buckets( io_buckets, io_bucket_intervals );
      io_bucket_intervals =
          (uint)(MAX(1,(((time_bounds.end - time_bounds.begin) / 
                                      hist_args[XPUT][TIME_INTERVAL])+2)));

      io_buckets = bucketize(metrics, nprocs, iops, time_bounds, 
                    hist_args[XPUT][TIME_INTERVAL], io_bucket_intervals, 
                    "throughput histogram", logptr, verbose,
                    replay_mono_file_flag);
   }						/* if need to rebucketize */

   /*
    * Dynamically allocate memory for work array; this array will be used to
    * derive min & max of range of buckets
    */
   if ( !(w = malloc((size_t)(io_bucket_intervals * sizeof(float)))) ) {
      fprintf(logptr, "Could not malloc() for do_histogram work array\n");
   }

   /* find range of values, load w with thruput vals and run do_stats() on w */
   
   for ( i=0 ; i<io_bucket_intervals ; i++ ) {
      w[i] = io_buckets[i].xput;
   }							/* for i */

   /*
    * determine number of intervals for histogram; need to add one 
    * to accomodate the lowest interval. Assumption made here is that
    * intervals with zero thruput are of no interest because they are before
    * or after the IOPS were run.
    */
   range = do_stats(w, io_bucket_intervals);
   range.min = (float)((uint)range.min); /* round down to next lowest int */

   hist_intervals = (uint)(((range.max - range.min) /
			 hist_args[XPUT][BUCKET_SIZE]) + 1);

   /*
    * allocate array to contain histogram data; need to allocate 
    * hist_intervals + 1 because the algorithm below is accessing
    * the next interval to identify where the current interval ends. Note
    * that the loop below reads "i <= hist_intervals", not "i < hist_intervals"
    */
   if ( !(xput_hist = (struct histogram_rec *)malloc( 
             (size_t)((hist_intervals + 1) * sizeof( struct histogram_rec ))))){
      fprintf(logptr, "Could not malloc() for do_hist array for xput_hist\n");
      terminate( EXIT_MALLOC_FAILURE );
   }							/* if malloc() */

   /* intialize buckets in histogram array */
   for ( i=0 ; i <= hist_intervals ; i++ )  {
      xput_hist[i].x = (float)((i*hist_args[XPUT][BUCKET_SIZE]) + range.min);
      xput_hist[i].y = 0;
   }							/* for i */

   /* populate histogram */ 
   for ( i=0  ;  i<io_bucket_intervals ;  i++ ) {
      if ( !( ((uint)((w[i]-range.min )/hist_args[XPUT][BUCKET_SIZE]))
                                                           < hist_intervals) ){
         fprintf(logptr, "Attempt to address xput_hist[ %u ].y made, but\n",
	    ((uint)((w[i] - range.min ) / hist_args[XPUT][BUCKET_SIZE])) );
         fprintf(logptr, 
            "hist_intervals in xput_hist=%u; w[%u]=%f range.min=%f ",
             hist_intervals , i, w[i], range.min);
         fprintf(logptr, "=%f\n", hist_args[XPUT][BUCKET_SIZE]);
         terminate(EXIT_ARRAY_BOUNDS_EXCEEDED);
      } 						/* if out of range */

     /* 
      * count only non-zero values; assumption here is that zero values will
      * occur before and after IOPs. If zero values occur in the middle of the
      * test, this will appear in the time plots - this also means that much
      * larger problems are being experienced...
      */
      if (w[i] > FLT_EPSILON)
         xput_hist[(uint)((w[i]-range.min) / hist_args[XPUT][BUCKET_SIZE])].y++;
   }							/* for i */

   /* suppress set to 1 for now - remove empty buckets from histogram */
   dump_histogram(xput_hist, hist_args[XPUT][BUCKET_SIZE], hist_intervals, 
                  hist_args[XPUT][SUPPRESS_ZERO], operation, "xput", 
                  "Aggregate Throughput (MB/sec)", reports_requested, 
                  report_prefix, test_timestamp, logptr); 
   free(w);				/* deallocate mem for scratch array */
   free(xput_hist);			/* release mem containging histogram */
   assert(!errno);

   /*----------------------------------------------------------------- 
    * histogram of concurrency 
    *-----------------------------------------------------------------*/
   /* 
    * Raw metric data has been bucketized; only rebucketize iff necessary;
    * if same time intervals are to be used, rebucketizing would be redundant.
    */
   if ((fabsf(hist_args[CONCURRENCY][TIME_INTERVAL]
          - hist_args[XPUT][TIME_INTERVAL])
            <FLT_EPSILON) 
      )  {

      free_io_buckets( io_buckets, io_bucket_intervals );
      io_bucket_intervals =
          (uint)(MAX(1,(((time_bounds.end - time_bounds.begin) / 
                                    hist_args[CONCURRENCY][TIME_INTERVAL])+2)));

      io_buckets = bucketize(metrics, nprocs, iops, time_bounds, 
                    hist_args[CONCURRENCY][TIME_INTERVAL], io_bucket_intervals, 
                    "concurrency histogram", logptr, verbose, 
                    replay_mono_file_flag);
   }						/* if need to rebucketize */

   /*
    * Dynamically allocate memory for work array; this array will be used to
    * derive min & max of range of buckets
    */
   if ( !(w = malloc(io_bucket_intervals * sizeof(float))) ) {
      fprintf(logptr, "Could not malloc() for do_histogram work array\n");
   }

   /* find range of values, load w with rsp_times and run do_stats() on w... */
   for ( i=0 ; i<io_bucket_intervals ; i++ ) {
      w[i] = io_buckets[i].io_concurrency;
   }							/* for i */

   /*
    * determine number of intervals for histogram; need to add one 
    * to accomodate the lowest interval
    */
   range = do_stats( w, io_bucket_intervals );
   range.min = (float)((uint)range.min); /* round down to next lowest int */

   hist_intervals = (uint)(((range.max - range.min) /
			        hist_args[CONCURRENCY][BUCKET_SIZE])+1);

   /*
    * allocate array to contain histogram data; need to allocate 
    * hist_intervals + 1 because the algorithm below is accessing
    * the next interval to identify where the current interval ends. Note
    * that the loop below reads "i <= hist_intervals", not "i < hist_intervals"
    */
   if ( !(concurrency_hist = (struct histogram_rec *)malloc( 
             (size_t)((hist_intervals + 1) * sizeof( struct histogram_rec ))))){
      fprintf(logptr, 
         "Could not malloc() for do_hist array for concurrency_hist\n");
      terminate( EXIT_MALLOC_FAILURE );
   }							/* if malloc() */

   /* intialize buckets in histogram array */
   for ( i=0 ; i<=hist_intervals ; i++ )  {
      concurrency_hist[i].x = (float)((i * hist_args[CONCURRENCY][BUCKET_SIZE]) 
			                                          + range.min);
      concurrency_hist[i].y = 0;
   }							/* for i */

   /* populate histogram */ 
   for ( i=0 ; i<io_bucket_intervals ; i++ ) {
      if ( !( ((uint)((w[i]-range.min )/hist_args[CONCURRENCY][BUCKET_SIZE])) 
			                               < hist_intervals ) ){
         fprintf(logptr, 
            "Attempt to address concurrency_hist[ %u ].y made, but\n",
	    ((uint)((w[i]-range.min) / hist_args[CONCURRENCY][BUCKET_SIZE])) );
         fprintf(logptr, 
            "hist_intervals in concurrency_hist=%u; w[%u]=%f range.min=%f ",
             hist_intervals , i, w[i], range.min);
         fprintf(logptr,"hist_args[CONCURRENCY][BUCKET_SIZE]=%f\n",
					  hist_args[CONCURRENCY][BUCKET_SIZE]);
         terminate(EXIT_ARRAY_BOUNDS_EXCEEDED);
      }							/* if out of bounds */

     /* 
      * count only non-zero values; assumption here is that zero values will
      * occur before and after IOPs. If zero values occur in the middle of the
      * test, this will appear in the time plots - this also means that much
      * larger problems are being experienced...
      */
      if (w[i] > FLT_EPSILON)
         concurrency_hist[(uint)((w[i]-range.min) / 
			           hist_args[CONCURRENCY][BUCKET_SIZE]) ].y++;
   }

   /* suppress set to 1 for now - remove empty buckets from histogram */
   dump_histogram(concurrency_hist, hist_args[CONCURRENCY][BUCKET_SIZE],
                  hist_intervals, hist_args[CONCURRENCY][SUPPRESS_ZERO], 
                  operation, "concurrency", 
                  "I/O Concurrency (Number of IOPs currently active)", 
		  reports_requested, report_prefix, test_timestamp, logptr); 

   free(concurrency_hist);		/* release mem containging histogram */
   free(w);				/* deallocate mem for scratch array */
   free_io_buckets( io_buckets, io_bucket_intervals );

  /*---------------------------------------------------------------
   * Pre-conditions
   *---------------------------------------------------------------*/
   assert(!errno);
}						/* do_histograms */

/***************************************************************************
 * dump_histogram() - 
 ***************************************************************************/
static void dump_histogram( 
               struct histogram_rec *hist, 
               float bucket_size,
	       uint elements, 
               float suppress, 
               char *operation,              /* {read|write|re-write} */
               char *histogram_name, 
               char *histogram_title,
               uint reports_requested[NUM_REPORT_TYPES], 
               char *report_prefix,
               char *test_timestamp,
               FILE *logptr
           )
{
#define DOC_STRING_MAX_SIZE 2048

   uint   i;				   /* loop variable */
   uint   sum = 0;			   /* accumulated number of samples */
   char   report_filename[MAX_REPORTNAME_SIZE] = "";
   char   dat_filename[MAX_REPORTNAME_SIZE] = "";
   char   error_msg[ERROR_MSG_MAX_LEN] = "";
   FILE  *outfile;				/* report output file ptr */
   char   doc_string[DOC_STRING_MAX_SIZE] = ""; /* documentation for hist */
   char   chart_title[128] = "";		/* line label for gnuplot */

   /*---------------------------------------------------------------
    * Pre-conditions
    *---------------------------------------------------------------*/
   assert(!errno);
   if ( !hist ) 
      BAD_ARG_PTR(hist,"hist","dump_histogram","hist!=NULL");
   if (bucket_size < FLT_EPSILON) 
      BAD_ARG_FLOAT(bucket_size,"bucket_size","dump_histogram",
                   "bucket_size>FLT_EPSILON");
   if ( !elements ) 
      BAD_ARG_UINT(elements, "elements", "dump_histogram","elements>0");
   if ( (uint)suppress > 1)
      BAD_ARG_UINT((uint)suppress, "suppress", "dump_histogram",
                   "suppress={0,1}");
   if ( !operation ) 
      BAD_ARG_PTR(operation,"operation","dump_histogram","operation!=NULL");
   if ( !histogram_name ) 
      BAD_ARG_PTR(histogram_name ,"histogram_name","dump_histogram",
                  "histogram_name!=NULL");
   if ( !histogram_title ) 
      BAD_ARG_PTR(histogram_title ,"histogram_title","dump_histogram",
                  "histogram_title!=NULL");
   if (!reports_requested) 
      BAD_ARG_PTR(reports_requested,"reports_requested","dump_histogram", 
                  "reports_requested!=NULL");
   if (!report_prefix) 
      BAD_ARG_PTR(report_prefix,"report_prefix","dump_histogram", 
                  "report_prefix!=NULL");
   if (!test_timestamp) 
      BAD_ARG_PTR(test_timestamp ,"test_timestamp","dump_histogram", 
                  "test_timestamp!=NULL");
   if (!logptr) BAD_ARG_PTR(logptr ,"logptr","dump_histogram", "logptr!=NULL");
  /*---------------------------------------------------------------------*/

  /*--------------------------------------------------------------------
   * provide documentation so that infrequent users have some notion of
   * what they are seeing in the report
   *--------------------------------------------------------------------*/
   if ( !strcmp(histogram_name, "rsp") ) {
      snprintf(doc_string, DOC_STRING_MAX_SIZE, "Description: This histogram shows the number of samples that\nwere categorized into buckets of size %f milliseconds\n\n",bucket_size*1000);
   } else if (!strcmp(histogram_name, "xput") ) {
      snprintf(doc_string, DOC_STRING_MAX_SIZE, "Description: This histogram shows the number of time intervals that\nwere categorized into buckets of size %f MB/sec.\nThe frequency represents the number of sample intervals where the aggregate\nsystem I/O was in the range given by the bucket size\n\n",bucket_size);
   } else if (!strcmp(histogram_name, "concurrency")) {
      snprintf(doc_string, DOC_STRING_MAX_SIZE, "Description: This histogram shows the number of time intervals that\nwere categorized into buckets of size %f concurrent IOPs/sec.\nThe frequency represents the number of sample intervals where the average\nnumber of concurrent operations were within the particular sample interval.\n\n",bucket_size);
   }

  /*--------------------------------------------------------------
   * TEXT
   *--------------------------------------------------------------*/
   if ( reports_requested[TEXT] ) {
      strcpy(report_filename, report_prefix);
      strcat(report_filename, "hist_");
      strcat(report_filename, histogram_name);
      strcat(report_filename, "_");
      strcat(report_filename, operation);
      strcat(report_filename, ".txt" );
      assert( strlen(report_filename)<MAX_REPORTNAME_SIZE );

      if ( !(outfile = fopen(report_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", report_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }							 /* if !outfile */

      fprintf(outfile, "\n\n\t\tHistogram Table\n");
      fprintf(outfile, "\t%s - %s\n\n", operation, histogram_title); 
      fprintf(outfile, "\tTest Run: %s\n\n", test_timestamp); 
      fprintf(outfile, "Intvl             Range                   Freq\n");
      fprintf(outfile, "           From    -    Up To\n\n");

      for (i=0 ; i<elements ; i++ ) {
         if ( (fabsf(suppress)<FLT_EPSILON) || (hist[i].y > 0) ) {
            fprintf(outfile, "%5u %12.6f - %12.6f       %6u\n", 
               i, hist[i].x, hist[i+1].x, hist[i].y);
            sum += hist[i].y;
         }						/* if to print */
      }							/* for i */

      fprintf(outfile, "\n");
      fprintf(outfile, "                                        ------\n");
      fprintf(outfile, "Total number of samples:                %6u\n",sum);
      fprintf(outfile, "\n\n");

      fprintf(outfile,"%s",doc_string);

      if (fclose( outfile )) {
         (void)snprintf(error_msg, ERROR_MSG_MAX_LEN, 
                   "fclose() failed on file %s\n", report_filename);
         io_error(error_msg);
      }							/* if fclose() */
      assert(!errno);
   }      						/* if TEXT */

  /*--------------------------------------------------------------
   * CSV
   *--------------------------------------------------------------*/
   if ( reports_requested[CSV] ) {
      strcpy(report_filename, report_prefix);
      strcat(report_filename, "hist_");
      strcat(report_filename, histogram_name);
      strcat(report_filename, "_");
      strcat(report_filename, operation);
      strcat(report_filename, ".csv" );
      assert( strlen(report_filename)<MAX_REPORTNAME_SIZE );

      if ( !(outfile = fopen(report_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", report_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }							 /* if !outfile */

      fprintf(outfile, "\n\n\t\tHistogram Table\n");
      fprintf(outfile, "\t%s - %s\n\n", operation, histogram_title); 
      fprintf(outfile, "\tTest Run:,%s\n\n", test_timestamp); 
      fprintf(outfile, "Intvl,,         Range,,                  Freq\n");
      fprintf(outfile, ",          From,   -,   Up To,\n\n");

      for (i=0 ; i<elements ; i++ ) {
         if ( (fabsf(suppress)<FLT_EPSILON) || (hist[i].y > 0) ) {
            fprintf(outfile, "%5u,%12.6f,-,%12.6f,%6u\n", 
               i, hist[i].x, hist[i+1].x, hist[i].y);
            sum += hist[i].y;
         }						/* if to print */
      }							/* for i */

      fprintf(outfile, "\n");
      fprintf(outfile, ",,,,------\n");
      fprintf(outfile, "Total number of samples: ,,,,%6u\n",sum);
      fprintf(outfile, "\n\n");

      fprintf(outfile,"%s",doc_string);

      if (fclose( outfile )) {
         (void)snprintf(error_msg, ERROR_MSG_MAX_LEN, 
                   "fclose() failed on file %s\n", report_filename);
         io_error(error_msg);
      }							/* if fclose() */
      assert(!errno);
   }      						/* if CSV*/

  /*--------------------------------------------------------------------
   * SAS reports
   *--------------------------------------------------------------------*/
   if ( reports_requested[SAS] ) {
      strcpy(report_filename, report_prefix);
      strcat(report_filename, "hist_");
      strcat(report_filename, histogram_name);
      strcat(report_filename, "_");
      strcat(report_filename, operation);
      strcat(report_filename, ".sas" );

      assert( strlen(report_filename) < MAX_REPORTNAME_SIZE);
      if ( !(outfile = fopen(report_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", report_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }                                                 /* if fopen() error */

      fprintf(outfile, "/************************************************\n");
      fprintf(outfile, " *\n");
      fprintf(outfile, " * hist_%s_%s.sas - produce histogram charts to\n",
                   histogram_name, operation);
      fprintf(outfile, " *     visualize data collected during\n");
      fprintf(outfile, " *     '%s' component of a Bertha test\n", operation);
      fprintf(outfile, " *\n");
      fprintf(outfile, " ************************************************/\n");
      fprintf(outfile, "\n");
      fprintf(outfile, "   data RAW;\n");
      fprintf(outfile, "\n");
      fprintf(outfile, "      label RANGE_LBOUND ='%s';\n", histogram_title);
      fprintf(outfile, "      label RANGE_UBOUND ='Upper bound of bucket';\n");
      fprintf(outfile, "      label N='Number of Samples';\n");
      fprintf(outfile, "\n");
      fprintf(outfile, 
                  "      format RANGE_LBOUND RANGE_UBOUND 12.6 N comma10.;\n");
      fprintf(outfile, "      input RANGE_LBOUND RANGE_UBOUND N;\n");
      fprintf(outfile, "      cards;\n");

      for (i=0 ; i<elements ; i++ ) {
         if ( (fabsf(suppress)<FLT_EPSILON) || (hist[i].y > 0) ) {
            fprintf(outfile, "%12.6f %12.6f %6u\n", 
               hist[i].x, hist[i+1].x, hist[i].y);
         }						/* if to print */
      }							/* for i */

      fprintf(outfile,";\n");
      fprintf(outfile,"   run;\n");
      fprintf(outfile,"\n");
      fprintf(outfile,"  /*---------------------------------------------\n");
      fprintf(outfile,"   * Prepare to emit chart(s)\n");
      fprintf(outfile,"   *---------------------------------------------*/\n");
      fprintf(outfile,"   goptions reset=all;\n\n");
      fprintf(outfile,"   title1 j=c '%s - %s';\n",
          operation, histogram_title);
      fprintf(outfile,"   title2 j=c 'Test Run on: %s';\n",test_timestamp);
      fprintf(outfile,"   symbol1 color=black h=0.3 v=0.3 value=dot;\n");
      fprintf(outfile,"   symbol2 color=red   h=0.3 v=0.3 value=dot;\n");
      fprintf(outfile,"\n");
      fprintf(outfile,"  /*---------------------------------------------\n");
      fprintf(outfile,"   * emit chart(s)\n");
      fprintf(outfile,"   *---------------------------------------------*/\n");
      fprintf(outfile,"*  filename G '/var/tmp/hist_%s_%s_xput.gif';\n",
          histogram_name, operation);
      fprintf(outfile,"*  goptions dev=gif733 gsfname=G gsfmode=replace;\n");
      fprintf(outfile,"   proc gchart data=RAW;\n");
      fprintf(outfile,"      format N comma10.;\n");
      fprintf(outfile,"      vbar RANGE_LBOUND /type=sum sumvar=N\n");
      fprintf(outfile,"         frame discrete sum autoref;\n");
      fprintf(outfile,"   run;\n   quit;\n");
      fprintf(outfile,"\n");

      if (fclose(outfile)) {
         (void)snprintf(error_msg, ERROR_MSG_MAX_LEN, 
                   "fclose() failed on file %s\n", report_filename);
         io_error(error_msg);
      }							/* if fclose() */

      assert(!errno);
   }							/* if SAS */

  /*--------------------------------------------------------------------
   * GNU_PLOT reports
   *--------------------------------------------------------------------*/
   if ( reports_requested[GNU_PLOT] ) {

      /* gnuplot datafile name */
      strcpy(dat_filename, report_prefix);
      strcat(dat_filename, "hist_");
      strcat(dat_filename, histogram_name);
      strcat(dat_filename, "_");
      strcat(dat_filename, operation);
      strcat(dat_filename, ".gin" );
      assert( strlen(dat_filename) < MAX_REPORTNAME_SIZE);

      /* gnuplot script */
      strcpy(report_filename, report_prefix);
      strcat(report_filename, "hist_");
      strcat(report_filename, histogram_name);
      strcat(report_filename, "_");
      strcat(report_filename, operation);
      strcat(report_filename, ".gp" );
      assert( strlen(report_filename) < MAX_REPORTNAME_SIZE);

      if ( !(outfile = fopen(report_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", report_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }                                                 /* if fopen() error */

      fprintf(outfile, "#\n# gnuplot rsp time curve data for %s\n#\n\n",
         operation);
      fprintf(outfile, "#\n# uncomment next two lines to produce");
      fprintf(outfile, " postscript output\n#\n\n");
      fprintf(outfile, "# set output \"gnuplot_%s_%s.ps\"\n",
         histogram_name, operation);
      fprintf(outfile, "# set terminal postscript landscape\n\n");
      fprintf(outfile, "set grid\n");
      fprintf(outfile, "#set style fill\n");

      if ( !strcmp(histogram_name,"rsp") )  
         strcpy(chart_title, "Response Time (msec)");
      else if (!strcmp(histogram_name, "xput")) 
              strcpy(chart_title, "Throughput (MB/sec)");
           else if (!strcmp(histogram_name, "concurrency"))
                  strcpy(chart_title,"I/O Concurrency (number of active I/Os)");
                else 
                   strcpy(chart_title,"Unknown");

      fprintf(outfile, "set xlabel \"%s\"\n", chart_title);
      fprintf(outfile, "set ylabel \"Frequency\"\n\n");
      fprintf(outfile, 
         "plot \"%s\" using 1:3 title \"%s during %s test\" with boxes\n", 
          dat_filename, chart_title, operation);
      fclose(outfile);

      /* gnuplot datafile */
      if ( !(outfile = fopen(dat_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", dat_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }                                                 /* if fopen() error */

      for (i=0 ; i<elements ; i++ ) {
         if ( (fabsf(suppress)<FLT_EPSILON) || (hist[i].y > 0) ) {
            fprintf(outfile, "%12.6f %12.6f %6u\n", 
               hist[i].x, hist[i+1].x, hist[i].y);
         }						/* if to print */
      }							/* for i */

      fclose(outfile);
      assert(!errno);
   }							/* if GNU_PLOT */


  /*--------------------------------------------------------------------
   * R reports
   *--------------------------------------------------------------------*/
   if ( reports_requested[R] ) {

      /* R datafile name */
      /* R has a built-in histogram function, but it is a bit painful to
       * force fit here, paritcularly for response times.
       */
      strcpy(dat_filename, report_prefix);
      strcat(dat_filename, "hist_");
      strcat(dat_filename, histogram_name);
      strcat(dat_filename, "_");
      strcat(dat_filename, operation);
      strcat(dat_filename, ".rin" );
      assert( strlen(dat_filename) < MAX_REPORTNAME_SIZE);

      /* R script */
      strcpy(report_filename, report_prefix);
      strcat(report_filename, "hist_");
      strcat(report_filename, histogram_name);
      strcat(report_filename, "_");
      strcat(report_filename, operation);
      strcat(report_filename, ".r" );
      assert( strlen(report_filename) < MAX_REPORTNAME_SIZE);

      if ( !(outfile = fopen(report_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", report_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }                                                 /* if fopen() error */

     /* R script */
      fprintf(outfile,
         "#\n# R script to generate %s histogram for %s test\n#\n\n",
         histogram_name, operation);

      fprintf(outfile,
         "#\n# Comment out following line to generate postscript output\n#\n");
      fprintf(outfile, "# postscript(\"%shist_%s_%s_R.ps\")\n\n",
         report_prefix, histogram_name, operation);

      if ( !strcmp(histogram_name,"rsp") )  
         strcpy(chart_title, "Response Time (msec)");
      else if (!strcmp(histogram_name, "xput")) 
              strcpy(chart_title, "Throughput (MB/sec)");
           else if (!strcmp(histogram_name, "concurrency"))
                  strcpy(chart_title,"I/O Concurrency (number of active I/Os)");
                else 
                   strcpy(chart_title,"Unknown");

      fprintf(outfile, "df1 <- read.table(\"%s\")\n", dat_filename);
      fprintf(outfile, "plot(df1[,1],df1[,3], ");
      fprintf(outfile, "xlab=\"%s\", ", chart_title);
      fprintf(outfile, "ylab=\"Frequency\", ");
      fprintf(outfile, "main=\"%s during %s Test\",tck=1)\n\n",
         chart_title, operation);

      fclose(outfile);

      /* R datafile */
      if ( !(outfile = fopen(dat_filename ,"w"))) {
         fprintf(logptr, "Cannot create file: \"%s\"\n", dat_filename);
         terminate( EXIT_REPORT_CREATION_ERROR );
      }                                                 /* if fopen() error */

      for (i=0 ; i<elements ; i++ ) {
         if ( (fabsf(suppress)<FLT_EPSILON) || hist[i].y ) {
            fprintf(outfile, "%12.6f %12.6f %6u\n", 
               hist[i].x, hist[i+1].x, hist[i].y);
         }						/* if to print */
      }							/* for i */

      fclose(outfile);
      assert(!errno);
   }                                                    /* if R */

  /*--------------------------------------------------------------
   * Post-conditions
   *--------------------------------------------------------------*/
   assert(!errno);
}							/* dump_histogram() */
