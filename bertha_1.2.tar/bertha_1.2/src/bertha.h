/*****************************************************************************
 * bertha.h
 *
 *-------------------------------------------------------------------------
 * Copyright 2006, Dave Wagoner
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *-------------------------------------------------------------------------
 *
 *****************************************************************************/

#define VERSION "Bertha Version 1.2, 11 Nov 2006\n"

/*-------------------------------------------------------------------- 
 * header files
 *-------------------------------------------------------------------*/
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/time.h>
#include <stdlib.h>
#include <time.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/resource.h>
#include <math.h>
#include <string.h>
#include <strings.h>
#include <assert.h>
#include <signal.h>

#ifdef RHEL4
#include <bits/huge_valf.h>
#endif

/*-------------------------------------------------------------------------
 * Solaris does not have fabsf(); Linux does, but this is a trivial
 * difference. By adding this macro, the same code with the same compile 
 * options compiles on both Linux and Solaris
 *-------------------------------------------------------------------------*/
#define fabsf (float)fabs

/*-------------------------------------------------------------------------
 * type shortcuts
 *-------------------------------------------------------------------------*/
#ifdef LINUX
typedef unsigned int  uint;
typedef unsigned long ulong;  /* size_t & off_t are unsigned long as well */
#endif 

typedef void (*sighandler_t)(int);
typedef enum { Write, Read, ReWrite, Random, Replay } tests_t;
typedef enum { RSP_TIME, XPUT, CONCURRENCY, RSP_XPUT, RSP_CONCURRENCY, TIME} hist_t;
typedef enum { TIME_INTERVAL, BUCKET_SIZE, SUPPRESS_ZERO } hist_parms_t;
typedef enum { TEXT, CSV, GNU_PLOT, R, SAS } report_types_t;

/*------------------------------------------------------------------------
 * Macros for floating point comparisons. These help address errors 
 * introduced by floating point data representation issues. These two 
 * macros may be defined in the include files of some version of UNIX but 
 * not others - declare here for completeness.
 *------------------------------------------------------------------------*/
#define FLT_EPSILON 1.19209290e-07F
#define DBL_EPSILON 2.2204460492503131e-16

/*-------------------------------------------------------------------- 
 * macros
 *-------------------------------------------------------------------*/
#define IntSize (sizeof(int))

#define CPU        		(0)
#define ELAPSED    		(1)
#define StartTime  		(1)
#define EndTime    		(2)
#define CHUNK      		(16384)   		/* max is 2^64 bytes */
#define DEFAULT_CPU_SAMPLE_INTERVAL (3)
#define DEFAULT_TIME_INTERVAL   (1.0)
#define DEFAULT_LOGFILENAME 	"bertha.log"
#define DEFAULT_RPT_DIR          "./reports"
#define ERROR_MSG_MAX_LEN 512
#define MBYTE                   (1048576.0)
#define MAX_NPROCS 		(5000)
#define MAX_DIRS   		(MAX_NPROCS)
#define MAX_DIRNAME_LEN 	(255)
#define MAX_REPLAYNAME_LEN      (255)
#define MAX_REPORT_PREFIX_SIZE  (514)
#define MAX_REPORTNAME_SIZE     (550)
#define MAX_LOGNAME_LEN         (255)
#define MAX_TESTNAME_LEN        (255)
#define MAX_SCRATCHNAME_LEN     (255)
#define MAX_FILESIZE		(65536)    /* max possible file size in MB */
#define MAX_ERROR_MSG_LEN       (512)
#define MAX_REPLAY_IOP_SIZE     (262144)   /* 256 MB */
#define MAX_TSTAMP_STR_SIZE     (132)
#define SLEEP                   (2)
#define MAX_REPLAY_DATAFILE_SIZE 2147483647 /* max size in bytes */
#define MARK(OP,M) if (verbose) {time_t ltime; ltime=time(0);fprintf(logptr,"%s %s at %s\n",OP,M,ctime(&ltime));} 
#define SYNC(OP)   {(void)system("sync");(void)system("sync");(void)system("sync");MARK(OP,"Sync completed");(void)sleep(5);if (errno==EINTR) errno=0; MARK(OP,"sleep() completed");}
#define MAX(A,B) (((((double)A)-((double)B))>DBL_EPSILON)?((double)A):((double)B))
#define MIN(A,B)                (((A)<(B))?(A):(B))
#define VERBOSE(A)              printf(A);

#define EXIT_NORMAL_TERMINATION                (0)
#define EXIT_BAD_USAGE                         (1)
#define EXIT_MALLOC_FAILURE                    (2)
#define EXIT_BAD_ARG_FAILURE                   (3)
#define EXIT_BAD_COMMAND_LINE_ARG              (4)
#define EXIT_FREE_SHM_FAILURE                  (5)
#define EXIT_FORCIBLE_TERMINATION              (6)
#define EXIT_SHARED_MEM_ERROR                  (7)
#define EXIT_BAD_HIST_ARG                      (8)
#define EXIT_RECORD_FILE_ERROR                 (9)
#define EXIT_ARRAY_BOUNDS_EXCEEDED            (10)
#define EXIT_BOGUS_VALUE_COMPUTED             (11)
#define EXIT_MEMSET_FAILURE                   (12)
#define EXIT_IO_ERROR                         (13)
#define EXIT_USLEEP_ERROR                     (14)
#define EXIT_INVALID_TRACEFILE_INPUT          (15)
#define EXIT_REPORT_CREATION_ERROR            (16)
#define EXIT_INSUFFICIENT_REPLAY_TRANSACTIONS (17)
#define EXIT_LOG_FILE_ERROR                   (18)
#define EXIT_REPLAY_FILESIZE_ERROR            (19)
#define EXIT_BAD_STRING                       (20)
#define EXIT_GETTIME_ERROR                    (21)
#define EXIT_BAD_FORK                         (22)
#define EXIT_BAD_REPLAY_FILE                  (23)
#define EXIT_SCRATCH_FILE_TOO_LARGE           (24)

#define NUM_CHARTS       (6)		/* number of hist_t */
#define NUM_CHART_PARMS  (3)		/* number of hist_parms_t */
#define NUM_REPORT_TYPES (5) 		/* number of report_types_t */

#define DEFAULT_RSP_HIST_BUCKET_SIZE               (1.0)
#define DEFAULT_RSP_HIST_SUPPRESS_ZERO             (0)

#define DEFAULT_XPUT_HIST_BUCKET_SIZE              (10.0)
#define DEFAULT_XPUT_HIST_SUPPRESS_ZERO            (0)

#define DEFAULT_CONCURRENCY_HIST_BUCKET_SIZE       (1.0)
#define DEFAULT_CONCURRENCY_HIST_SUPPRESS_ZERO     (0)

#define DEFAULT_RSP_XPUT_BUCKET_SIZE               (10.0)
#define DEFAULT_RSP_XPUT_SUPPRESS_ZERO             (0)

#define DEFAULT_RSP_CONCURRENCY_BUCKET_SIZE        (1.0)
#define DEFAULT_RSP_CONCURRENCY_SUPPRESS_ZERO      (0)

#define DEFAULT_TIME_BUCKET_SIZE                   (1.0)
#define DEFAULT_TIME_SUPPRESS_ZERO                 (0)

#define DEFAULT_DUMP_RAW_METRICS_FLAG		   (0)
#define DEFAULT_METRICS_BY_PROC_FLAG               (0) 

#define NTESTS                  ((((int)Random)) + 2) /* sneak in replay */
#define BAD_ARG_INT(x,x_str,rtn,range) {fprintf(stderr,"BugCheck: invalid value for \"%s\" passed to %s(): value passed: %d valid range= %s \n",x_str, rtn, x, range);terminate( EXIT_BAD_ARG_FAILURE );}
#define BAD_ARG_UINT(x,x_str,rtn,range) {fprintf(stderr,"BugCheck: invalid value for \"%s\" passed to %s(): value passed: %u valid range= %s \n",x_str, rtn, x, range);terminate( EXIT_BAD_ARG_FAILURE );}
#define BAD_ARG_ULONG(x,x_str,rtn,range) {fprintf(stderr,"BugCheck: invalid value for \"%s\" passed to %s(): value passed: %lu valid range= %s \n",x_str, rtn, x, range);terminate( EXIT_BAD_ARG_FAILURE );}
#define BAD_ARG_FLOAT(x,x_str,rtn,range) {fprintf(stderr,"BugCheck: invalid value for \"%s\" passed to %s(): value passed: %f valid range= %s \n",x_str, rtn, x, range);terminate( EXIT_BAD_ARG_FAILURE );}
#define BAD_ARGS_FLOAT(x,y,x_str,rtn,range) {fprintf(stderr,"BugCheck: invalid value for \"%s\" passed to %s(): values passed: (%f,%f) valid range= %s \n",x_str, rtn, x, y , range);terminate( EXIT_BAD_ARG_FAILURE );}
#define BAD_ARG_PTR(x,x_str,rtn,range) {fprintf(stderr,"BugCheck: invalid value for \"%s\" passed to %s(): value passed: 0x%lx valid range= %s \n",x_str, rtn, (ulong)x, range);terminate( EXIT_BAD_ARG_FAILURE );}

#define BAD_HIST_ARG(str) {fprintf(stderr,"Invalid hist arg: \"%s\"\n",str);terminate(EXIT_BAD_HIST_ARG);}


/*-------------------------------------------------------------------------
 * data structure definitions
 *-------------------------------------------------------------------------*/
/*
 * record to contain transactions captured from production for replay on
 * test file
 */
struct trans_rec {
   long unsigned int addr;
   unsigned int      len;
   char              op[2];
   float             post_io_delay;
} trans_rec;

/* data elements in linked list; contains only rsp time */
struct curve_rec {
   float rsp;
   struct curve_rec *next;
} curve_rec;

/*
 * bucket_rec - used to hold "bucketized" data; this is done for aggregation
 *              to form a basis on which to product various reports.
 */
struct bucket_rec {
   double tstamp;         /* bucket start point */
   ulong  io_started;     /* discrete - number of IOPs started during interval*/
   float  xput;           /* continuous - throughput accumulated for interval */
   float  mbytes;         /* continuous - bytes moved during this interval */
   float  io_concurrency; /* continuous - # of IOPs in flight during interval*/
   struct curve_rec *head;/* pointer to linked list of structures containing
                              response times recorded during this interval */
   struct curve_rec *tail;
} bucket_rec;

struct time_range_rec {
   double begin;
   double end;
} time_range_rec;

/* data structure to contain summary stats by process */
struct summary_rec {
   float min;                           /* min value */
   float median;                        /* 50th percentile */
   float mean;                          /* average */
   float p75;                           /* 75th percentile */
   float p90;                           /* 90th percentile */
   float p95;                           /* 95th percentile */
   float p99;                           /* 99th percentile */
   float max;                           /* max value */
   uint  n;                             /* number of elements summarized */
   float stddev;                        /* standard deviation */
} summary_rec;

/*
 * Metrics Record Data Structure
 * =============================
 * The metrics structure should contain not only response time, but also the
 * system time when the I/O op was initiated - convenience for graphing
 * as well as system forensics (recall that this code has exposed numerous 
 * bugs in commercial software, including some that have resulted in hanging
 * systems and corrupted file systems).
 *
 * The io_size field was added because the replay facility has a potential for
 * variable size I/Os to be performed. Simple thruput tests do not have this
 * issue since a fixed I/O size is used for each I/O. It then becomes a 
 * design decision regarding expanding metrics_rec to house the io_size 
 * field for thruput as the data is redundant versus removing it from the 
 * metrics_rec structure and having a second data structure to hold io_size 
 * for each transaction and only use that structure when performing replays. 
 * This would perhaps add some complexity to the code. The trade off is that 
 * the amount of memory used to house metrics_rec data would be reduced - a 
 * concern for large tests. However, the sizeof (metrics_rec) is 24 bytes if 
 * io_size is included. For 16KB IOPs, this means that the amount of data 
 * needed to house metrics is 1.5 MB for each GB of scratch file for each 
 * process. On contemporary systems, even a small Linux system with 1GB of 
 * RAM can then perform a test with a total scratch file size of over 7GB 
 * without grief. Because contemporary systems have this capacity, the design 
 * choice of including the io_size in the metrics record was made.
 *
 * This is a long way from having to do Fortran code overlays on a PDP-11 
 * using RT11 to save 1 KByte...
 */
struct metrics_rec {
   double tstamp;
   float  rsp_time;
   ulong  io_size;	/* io_size is uniform for thruput, but not for replay */
} metrics_rec;

/*-------------------------------------------------------------------
 * function prototypes
 *-----------------------------------------------------------------*/
double timestamp(double basetime);
void   bonnie_report(char * testname, double size, uint nprocs, 
          double delta[NTESTS][2], ulong io_size);
void   sample_times(double basetime, double *last_elapsed_time,
          double *last_cpu_time);
double cpu_stamp();
void   get_delta_t(tests_t test, double delta[NTESTS][2],
          double basetime, double *last_elapsed_time, double *last_cpu_time);
void   io_error(char *message);
void   io_warn(FILE *logptr, char *message);
void   openfile(char *name, int * fd, int create);

void   replay(uint nprocs, double size, uint verbose,
          uint num_dirs, char dir[MAX_NPROCS][MAX_DIRNAME_LEN],
          char *rptdir, char *testname, char replay_file[MAX_REPLAYNAME_LEN], 
          uint replay_mono_file_flag, uint replay_scale_io_size_flag,
          float hist_args[NUM_CHARTS][NUM_CHART_PARMS], 
	  uint dump_raw_metrics_flag, uint metrics_by_proc_flag,
          uint reports_requested[NUM_REPORT_TYPES], 
          uint record_flag, FILE *fp);
void   thruput(uint nprocs, double size, uint verbose,
          uint num_dirs, char dir[MAX_NPROCS][MAX_DIRNAME_LEN], char *rptdir, 
          char *testname, ulong io_size, 
          float hist_args[NUM_CHARTS][NUM_CHART_PARMS], 
          uint dump_raw_metrics_flag, uint metrics_by_proc_flag,
          uint reports_requested[NUM_REPORT_TYPES], uint record_flag, 
          FILE *fp);
void   init_metrics(struct metrics_rec *metrics, uint nprocs, uint iops,
          FILE *logptr);
void   do_reports(struct metrics_rec *metrics, uint nprocs, uint iops, 
	  char *operation, char *test_timestamp,
          float hist_args[NUM_CHARTS][NUM_CHART_PARMS], char *rptdir, 
          char *testname, uint dump_raw_metrics_flag, 
          uint metrics_by_proc_flag, uint reports_requested[NUM_REPORT_TYPES], 
          FILE *logptr, uint verbose, uint replay_mono_file_flag);
void   do_record(struct metrics_rec *metrics, uint nprocs, uint iops,
          char *operation, char *rptdir, char *test_timestamp, char *testname, 
          FILE *logptr, uint verbose, uint replay_mono_file_flag);
void   do_rereports(char *operation, 
          float hist_args[NUM_CHARTS][NUM_CHART_PARMS], 
          char *rptdir, char *testname, uint dump_raw_metrics_flag, 
          uint metrics_by_proc_flag, uint reports_requested[NUM_REPORT_TYPES], 
          FILE *logptr, uint verbose);
struct time_range_rec find_time_bounds(struct metrics_rec *metrics,
          uint nprocs, uint iops, uint replay_mono_file_flag);
void do_histograms(struct metrics_rec *metrics,
          float  hist_args[NUM_CHARTS][NUM_CHART_PARMS],
          struct time_range_rec time_bounds, char *operation, 
	  char *report_prefix, uint nprocs, uint iops, 
          uint reports_requested[NUM_REPORT_TYPES], FILE *fp, uint verbose, 
          uint replay_mono_file_flag, char *test_timestamp);
void free_io_buckets(struct bucket_rec *io_buckets, uint intervals);
struct bucket_rec *bucketize(struct metrics_rec *metrics, uint nprocs,
          uint iops, struct time_range_rec time_bounds,
          float bucket_size, uint intervals, char *rpt_name, FILE *fp,
          uint verbose, uint replay_mono_file_flag);
struct summary_rec do_stats(float *w, uint elements);
void do_rsp_curves( struct metrics_rec *metrics,
          float hist_args[NUM_CHARTS][NUM_CHART_PARMS],
          struct time_range_rec time_bounds, char *operation, 
          char *report_prefix, uint nprocs, uint iops, 
          uint reports_requested[NUM_REPORT_TYPES], FILE *fp,
          uint verbose, uint replay_mono_file_flag, char *test_timestamp);
void dump_metrics(char *operation, struct metrics_rec *metrics,
          uint nprocs, uint iops, char *rptdir,
          uint reports_requested[NUM_REPORT_TYPES], char *test_timestamp,
          uint replay_mono_file_flag, FILE *logptr);
void dump_buckets(struct bucket_rec *buckets, uint intervals,
          char *operation, uint suppress,
          uint reports_requested[NUM_REPORT_TYPES], char *report_prefix,
          char *test_timestamp, FILE *logptr);
void summarize_metrics_proc( char *operation,
          struct metrics_rec *metrics, uint nprocs, uint iops,
          uint reports_requested[NUM_REPORT_TYPES], char *report_prefix,
          uint replay_mono_file_flag, char *test_timestamp, FILE *logptr);
void summarize_metric( char *operation, char *summary_title,
          struct metrics_rec *metrics, uint nprocs, uint iops, 
          uint reports_requested[NUM_REPORT_TYPES], char *report_prefix, 
          uint replay_mono_file_flag, char *test_timestamp, FILE *logptr);




struct metrics_rec *allocate_shm( size_t size );

void sighandler(char *sig);
sighandler_t sighandler_INT();
sighandler_t sighandler_QUIT();
sighandler_t sighandler_ABRT();
sighandler_t sighandler_BUS();
sighandler_t sighandler_SEGV();
sighandler_t sighandler_TERM();
sighandler_t sighandler_STKFLT();

/* sighandler_t fetch_cpu(); */
void   terminate(); /* free shared memory segment, terminate execution */

/*---------------------------------------------------------------------
 * manditory global variable
 *--------------------------------------------------------------------*/
extern int errno;  /* interface for passing syscall/libcall error numbers */

/* 
 * must have shared memory IDs global so that sighandler() has visibility to
 * them and can free the shared memory segments
 */ 

   /* ID of shared memory segment containing response time metrics.  */
int metrics_shmid; 

  /* ID of shared memory segment containing transaction data for replay. */
int replay_shmid; 

/*
 * The following variables must be global so that they are visible to the 
 * signal handlers. A static declaration is not adequate as they are accessed
 * from multiple compilation modules.
 */

uint    cpu_sample_interval; /* arg to alarm() */
double  basetime;	     /* use this instead of number of secs since 1970*/

