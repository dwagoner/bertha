/***************************************************************************
 * thruput.c - run set of thruput tests which are composed of writing, 
 *             reading, and re-writing (write, rewind, read).
 *
 *-------------------------------------------------------------------------
 * Copyright 2006, Dave Wagoner
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *-------------------------------------------------------------------------
 *
 ***************************************************************************/

/*-------------------------------------------------------------------- 
 * header files
 *-------------------------------------------------------------------*/
#include "./bertha.h"

/***********************************************************************
 * thruput() - default set of thruput tests
 ***********************************************************************/
void thruput(uint nprocs,   /* number of concurrent processes generating IOPs*/ 
             double fsize,  /* size of scratch files on which to perform IOPs */
             uint  verbose,  /* verbose flag */
             uint  num_dirs, /* # dirs where scratch files will reside */
             char  dir[MAX_NPROCS][MAX_DIRNAME_LEN],  /* scratch dir names */ 
             char *rptdir,  /* where to write results */
	     char *testname,/* label to uniquely identify test results */
             ulong io_size,  /* IOP size - default is 16K */
             float hist_args[NUM_CHARTS][NUM_CHART_PARMS], /* histogram args */
             uint  dump_raw_metrics_flag, /* show every transaction */
             uint  metrics_by_proc_flag,  /* summary trans by concurrent proc */
             uint  reports_requested[NUM_REPORT_TYPES],
             uint  record_flag, /* store raw data for potential rereporting */  
             FILE *logptr)
{
   char  *buff;			      /* buffer to hold data used for I/O */
   int    buffindex;		      /* ptr into buffer */
   uint   iops;                       /* #IOPs to perform per concurrent proc */
   int    child[MAX_NPROCS];
   int    fd            = -1;	      /* file descriptor, used by each child*/
   char   name[MAX_NPROCS][MAX_SCRATCHNAME_LEN]; 
   off_t  data_size;
   char   tname[256];
   int    retval;		       /* return value */
   int    status;		       /* status from waitpid; unused */
   uint   this_iop;                    /* counter for IO operations */
   uint   p, p0;		       /* loop counters */
   double start_time, stop_time;
   double io_start_time, io_end_time;
   ssize_t read_io_bytes;	       /* #bytes read by read(2) */
   ssize_t write_io_bytes;	       /* #bytes written by write(2) */

   ulong   num_writes = 1;

   double delta[NTESTS][2];           /* array of DeltaT values */
   double last_cpu_time     = 0.0;    /* for computing delta-t */
   double last_elapsed_time = 0.0;    /* for computing delta-t */
   uint   m_index;		      /* index into array of metrics_recs */
   ulong  basetime_ulong;	      /* format of timestamp for ctime() */
   struct metrics_rec *metrics;       /* where to write tstamp & rsp times*/
   char   test_timestamp[MAX_TSTAMP_STR_SIZE]; /*txt vers of strt time of test*/

   /*--------------------------------------------------------------------
    * Pre-conditions
    *--------------------------------------------------------------------*/
   assert(!errno);
   if (!nprocs)   BAD_ARG_UINT(nprocs, "nprocs", "thruput","nprocs > 0");
   if (fsize<DBL_EPSILON) BAD_ARG_FLOAT(fsize,"fsize","thruput","fsize>0.0");
   if (!num_dirs)  BAD_ARG_UINT(num_dirs,"num_dirs","thruput","num_dirs>0");
   if (!dir)       BAD_ARG_PTR(dir,"dir","thruput","dir!=NULL");
   if (!rptdir)    BAD_ARG_PTR(rptdir,"rptdir","thruput","rptdir!=NULL");
   if (!testname)  BAD_ARG_PTR(testname,"testname","thruput","testname!=NULL");
   if (!io_size)   BAD_ARG_ULONG(io_size, "io_size", "thruput", "io_size>0");
   if (!hist_args) BAD_ARG_PTR(hist_args,"hist_args","thruput",
                               "testname!=NULL");
   if (dump_raw_metrics_flag> 1)
      BAD_ARG_UINT(dump_raw_metrics_flag, "dump-raw_metrics_flag",
          "thruput", "dump-raw_metrics_flag= {0 | 1}");
   if (metrics_by_proc_flag > 1)
      BAD_ARG_UINT(metrics_by_proc_flag, "metrics_by_proc_flag",
          "thruput", "metrics_by_proc_flag = {0 | 1}");
   if (!reports_requested)
      BAD_ARG_PTR(reports_requested,"reports_requested",
                  "thruput","reports_requested!=NULL");
   if (!logptr)   BAD_ARG_PTR(logptr,"logptr","thruput","logptr!=NULL");
   /*-------------------------------------------------------------------*/

   /* record start time of run; subsequent times are relative to this */
   basetime_ulong = (ulong)basetime;
   strcpy( test_timestamp, ctime( (const time_t *)&basetime_ulong ));
   assert( (strlen(test_timestamp) <= MAX_TSTAMP_STR_SIZE) &&
	   (strlen(test_timestamp) > 1));

   /* remove embedded '/n' from test_timestamp */
   test_timestamp[strlen(test_timestamp)-1] = '\0';
    
   /* allocate shared memory segment and attach to it */
   iops = (uint)((fsize*1024*1024) / io_size); /* number of IO ops to be done */

   metrics = allocate_shm((size_t)sizeof(struct metrics_rec)*nprocs*iops);

   /*-----------------------------------------------------------------------
    * Dynamically allocate buffer to be used for I/O. No need to init the 
    * contents of the buffer - garbage is ok. Just need something to write
    * and a place to read.
    *-----------------------------------------------------------------------*/
   if ( !(buff = (char *)malloc( (size_t)io_size ) ) ) {
      fprintf(logptr, "malloc() for buf failed in thruput()\n");
      terminate( EXIT_MALLOC_FAILURE );
   }

   /*--------------------------------------------------
    * choose filenames for each concurrent "process"
    *--------------------------------------------------*/
   for (p=0; p<nprocs ; p++ ) {
      strncpy( name[p], dir[p % num_dirs], strlen(dir[p % num_dirs]));
      (void)snprintf( tname, 32, "/bertha_%u.dat", p);
      strcat(name[p], tname);
      assert(strlen(name[p]) < MAX_SCRATCHNAME_LEN);
   }							/* for p */

  /*==============================================
   *   start the real work
   *==============================================*/
  /* fsize is in meg, rounded down to multiple of io_size */
  fsize     = (double)( io_size * ((1024*1024)/io_size) * (ulong)fsize );
  data_size = (off_t)(io_size/sizeof(ulong));

  /*---------------------------------------------------
   *  "Write" test - Write the whole file from scratch
   *---------------------------------------------------*/
   if (verbose) fprintf(logptr, "\nbertha: Sequential Write:\n");
   sample_times(basetime, &last_elapsed_time, &last_cpu_time);

   /* initialize shared memory segment that will contain the rsp metrics */
   init_metrics(metrics, nprocs, iops, logptr);

   for (p=0; p<nprocs ; p++) {
      child[p] = 0;			/* initialize out of paranoia */
      if ((child[p] = fork()) == -1) terminate(EXIT_BAD_FORK); 
      else
         if (child[p] == 0) {
           /*
            * Child process - this generates the I/O
            */
            /* double start_time, stop_time; */
            (void)sleep(SLEEP);/* Allow all children processes to be started 
				* at approximately the same time; for high
				* numbers of offspring, this will prevent the 
				* CPU from being drained by the first few  
				* children, thereby preventing the parent 
				* from creating the remainder of the syblings.
 				*/

           /*
            * Solaris alarms to terminate sleep state cause EINTR to be set;
            * this is quite reasonable (Linux does not do this). Reset errno
            * to allow assertions ( assert(!errno) ) to pass.
            */
            if (errno == EINTR) errno = 0;
	    
            start_time = timestamp(basetime);

            openfile(name[p], &fd, 1);   /* create new file */
            for (buffindex=0 ; buffindex<(int)io_size ; buffindex++) 
   	       buff[buffindex] = '\0';

           /*
            * wrapper for write operations
            */
            for (buffindex=0, this_iop=0 ; this_iop<iops ; this_iop++) {
               buffindex %= io_size;  /* range of buffindex is 0 to io_size-1*/
               buff[buffindex++]++;   /* soil the buffer to confound I/O 
                                       * optimizations and obtain better 
  				       * results */

               /*
                * Perform the write I/O operation; capture time just before
                * and just after - the difference is the response time for 
                * the write operation. Note that some operating systems
                * will bundle IOPs, particularly sequential I/Os. What 
                * constitutes and IOP at an application level (e.g. this 
                * program) is not necessarily what constitutes an IOP at 
                * the disk. Review sar stats and look at the IOP rate and 
                * compare to the IOP rate performed by this program. Note 
                * that the response times will proportionally vary as well.
                */
               io_start_time = timestamp(basetime);
               if ((write_io_bytes = write(fd, buff, (size_t)io_size)) == -1) 
                  io_error("write(2)");
               io_end_time   = timestamp(basetime);

               /*
                * Record the elapsed time to perform the I/O op, emit a 
                * warning if something bizarre has happened such that the 
                * number of bytes actually written varies from what was 
                * intended. Such an event may invalidate the results of the 
                * test.
                */
               m_index = this_iop * nprocs + p;

               metrics[m_index].tstamp   = io_start_time;
               metrics[m_index].rsp_time = (float)(io_end_time - io_start_time);
               metrics[m_index].io_size  = io_size;

               /* verify I/O chunk - did all the data get written? */
               if ( write_io_bytes != (ssize_t)io_size) {
                  fprintf(logptr, "Warning: child pid #%u, IOP #%u did not ",
		     p, (uint)(this_iop-1));
                  fprintf(logptr,
		     "write intended number of bytes; wrote %lu bytes\n", 
		     (ulong)write_io_bytes);
               }					/* if IOP successful */
            } 						/* for this_iop*/

            if (close(fd) == -1) io_error("close after fast write");
            stop_time = timestamp(basetime);

            if (verbose)
               fprintf(logptr, "Write Child %u ends; elapsed: %12.6lf\n",
                        p, stop_time - start_time);
            exit( EXIT_NORMAL_TERMINATION );    /* important for children! */
       }                                        /* if child process */
   }                                            /* for p */

   assert(!errno);

   /* parent will wait for all children to complete, then samples CPU */
   MARK("Write", "Start"); 
   sample_times(basetime, &last_elapsed_time, &last_cpu_time);

   /* bulk of I/O is being done by children now; wait for them to finish */
   for (p=0; p<nprocs; p++ ) {
      retval = waitpid(-1, &status, NULL);
      if (errno && (errno!=EINTR)) perror("bertha waitpid(): ");

      if (status) {
         fprintf(logptr,
            "When generating input file, child process terminated\n");
         fprintf(logptr,"with errno: %d\n",status>>16);
          
        /* 
         * kill off remaining children
         */
         for (p0=0; p0<nprocs ; p0++) if (child[p0]) kill(child[p0],SIGINT);

       /*
        * pop smoke and evacuate
        */ 
         terminate( (uint)(status>>16) );
      }						/* if status */
   }						/* for p */

   get_delta_t(Write, delta, basetime, &last_elapsed_time, &last_cpu_time);
   sample_times(basetime, &last_elapsed_time, &last_cpu_time);
   MARK("Write", "Stop"); 
   SYNC("Write");

   fprintf(logptr, "Write: %7.3lf elapsed seconds, %10.6lf CPU seconds ",
		delta[(int)Write][ELAPSED],delta[(int)Write][CPU]);
   fprintf(logptr, " Thruput: %7.3lf MB/sec\n",
       ((fsize)*nprocs/(delta[(int)Write][ELAPSED] * 1024.0 * 1024.0)));

   /* emit output table and generate relevant reports & charts*/
   do_reports(metrics, nprocs, iops, "Write", test_timestamp,
             hist_args, rptdir, testname, dump_raw_metrics_flag, 
             metrics_by_proc_flag, reports_requested, logptr, 
             verbose, 0/*replay_mono_file_flag=0*/);

   /* record raw data for rereporting later if requested */
   if (record_flag)
      do_record(metrics, nprocs, iops, "Write", rptdir, test_timestamp,
             testname, logptr, verbose, 0/*replay_mono_file_flag*/);
  /*---------------------------------------------------
   *  "Read" test
   *---------------------------------------------------*/
   if (verbose) fprintf(logptr, "\nbertha: Sequential Read:\n");

   /* initialize shared memory segment that will contain the rsp metrics */
   init_metrics(metrics, nprocs, iops, logptr);

   for (p=0 ; p<nprocs ; p++) {
      child[p] = 0;			/* initialize out of paranoia */
      if ((child[p] = fork()) == -1) io_error("fork");
      else
         if (child[p] == 0) {
            /* double start_time, stop_time; */
            (void)sleep(SLEEP); /* allow all child processes to be started */
           /*
            * Solaris alarms to terminate sleep state cause EINTR to be set;
            * this is quite reasonable (Linux does not do this). Reset errno
            * to allow assertions ( assert(!errno) ) to pass.
            */
            if (errno == EINTR) errno = 0;
	    
            start_time = timestamp(basetime);

            openfile(name[p], &fd, 0); /* open existing file for read test */

           /*
            * Wrapper for read operations
            */
            for (this_iop=0 ; this_iop<iops ; this_iop++) {
               /*
                * perform the read I/O operation; capture time just before
                * and just after - the difference is the response time for 
                * the read operation. Notes above for write operation 
                * apply here as well.
                */
               io_start_time = timestamp(basetime);
               if ((read_io_bytes = read(fd, buff, (size_t)io_size)) == -1)
	 	  io_error("read(2)");
               io_end_time   = timestamp(basetime);

               /*
                * record the elapsed time to perform the I/O op, only fully
                * successful I/O ops are to be used for detailed metrics
                */
               m_index = this_iop * nprocs + p;

               metrics[m_index].tstamp   = io_start_time;
               metrics[m_index].rsp_time = (float)(io_end_time - io_start_time);
               metrics[m_index].io_size  = io_size;

               /* verify I/O op */
               if ( read_io_bytes != (ssize_t)io_size ) {
                  fprintf(logptr, "Warning: child pid # %u, IOP # %u did not ",
		     p, (uint)(this_iop-1));
                  /* fprintf(logptr, */
                  printf("read intended number of bytes; read %lu bytes\n", 
			(ulong)read_io_bytes);
               }				      /* if IOP unsuccessful */
            }  					      /* for this_iop */

            if (close(fd) == -1) io_error("close after read");
            stop_time = timestamp(basetime);
            if (verbose)
               fprintf(logptr, "Read Child %u ends; elapsed: %12.6lf\n",
                        p, stop_time - start_time);
            exit( EXIT_NORMAL_TERMINATION );  	/* important for children! */
       }                                        /* if child process */
   }                                            /* for p */
   assert(!errno);

   /* parent waits for all children to complete, then samples CPU */
   MARK("Read", "Start"); 
   sample_times(basetime, &last_elapsed_time, &last_cpu_time);

   /* bulk of I/O is being done by children now; wait for them to finish */
   for (p=0; p<nprocs; p++ ) {
      retval = waitpid(-1, &status, NULL);
      if (errno && (errno!=EINTR)) perror("bertha waitpid(): ");

      if ( status ) {
         fprintf(logptr,
            "When generating input file, child process terminated\n");
         fprintf(logptr,"with errno: %d\n",status>>16);
          
        /* 
         * kill off remaining children
         */
         for (p0=0; p0<nprocs ; p0++) if (child[p0]) kill(child[p0],SIGINT);

       /*
        * pop smoke and evacuate
        */ 
         terminate( (uint)(status>>16) );
      }						/* if status */
   }						/* for p */

   get_delta_t(Read, delta, basetime, &last_elapsed_time, &last_cpu_time);

   MARK("Read", "Stop"); 
   SYNC("Read");

   fprintf(logptr, "Read: %7.3lf elapsed seconds, %10.6lf CPU seconds ",
		delta[(int)Read][ELAPSED],delta[(int)Read][CPU]);
   fprintf(logptr,
          " Thruput: %7.3lf MB/sec\n",
	  (double)(nprocs)*(fsize) / (1024*1024 * (delta[(int)Read][ELAPSED])));

   /* emit output table and generate relevant reports & charts*/
   do_reports(metrics, nprocs, iops, "Read", test_timestamp,
              hist_args, rptdir, testname, dump_raw_metrics_flag, 
              metrics_by_proc_flag, reports_requested, logptr, verbose, 
              0 /* replay_mono_file_flag = 0*/ );

   /* record raw data for rereporting later if requested */
   if (record_flag)
      do_record(metrics, nprocs, iops, "Read", rptdir, test_timestamp,
             testname, logptr, verbose, 0/*replay_mono_file_flag*/);

  /*------------------------------------------------------------------------
   * read & write (rewrite) using block I/O.  Dirty one byte in each block
   * to confound I/O avoidance optimizations.
   *------------------------------------------------------------------------*/
   if (verbose) fprintf(logptr, "\nbertha: ReWrite\n");

   /* initialize shared memory segment that will contain the rsp metrics */
   init_metrics(metrics, nprocs, iops, logptr);

   for (p=0; p<nprocs ; p++) {
      child[p] = 0;			/* initialize out of paranoia */
      if ((child[p] = fork()) == -1) io_error("fork");
      else
         if (child[p] == 0) {
            /* double start_time, stop_time; */
            (void)sleep(SLEEP);   /* allow all child processes to be started */
           /*
            * Solaris alarms to terminate sleep state cause EINTR to be set;
            * this is quite reasonable (Linux does not do this). Reset errno
            * to allow assertions ( assert(!errno) ) to pass.
            */
            if (errno == EINTR) errno = 0;
	    
            start_time = timestamp(basetime);

   	    openfile(name[p], &fd, 0);  /* open existing file */

	    /* rewind to beginning of file */
   	    if (lseek(fd, (off_t)0,0) == (off_t) -1)
	       io_error("lseek(2) before rewrite");

            for (buffindex=0, this_iop = 0 ; this_iop < iops ; this_iop++ ) {

               /* init with dummy values that will be overwritten by r/w calls*/
               read_io_bytes  = -1; 
               write_io_bytes = -1;

	       /*
                * a rewrite "IOP" is actually two IOPS: one read followed 
                * by one write. The time recorded includes read + write time.
                * Note that lseek() time is also included as part of the IOP; 
                * this *should* be negligble in comparison to the other ops. 
                * Also included is the time to dirty the buffer, but this too 
                * is comparitively negligble compared to the I/O times.
                */
               io_start_time = timestamp(basetime);

               /* read of next block */
      	       if ((read_io_bytes=read(fd, buff, (size_t)io_size )) == -1)
		  io_error("rwrite read");

               /* dirty the buffer - skirt optimizations for I/O avoidance */
               buffindex %= io_size;      /* buffindex range is 0 to io_size */
	       buff[buffindex++]++;       /* dirty the buffer here */

               /* rewind one IOP in distance to do re-write */
      	       if (lseek(fd, (off_t) -io_size, 1) == -1)
		  io_error("relative lseek(2)");

               /* one write, change content of this block of file */
      	       if ((write_io_bytes = write(fd, buff, (size_t)io_size ))==-1) 
   	          io_error("re write(2)");

               io_end_time   = timestamp(basetime);

              /*
               * record the elapsed time to perform the I/O op, only fully
               * successful I/O ops are to be used for detailed metrics
               */
               m_index = this_iop * nprocs + p;
               assert( m_index < (iops * nprocs));
                
               metrics[m_index].tstamp   = io_start_time;
               metrics[m_index].rsp_time = (float)(io_end_time - io_start_time);
               /*
                * io_size must reflect that a read and a write were performed;
                * a "rewrite" transactionis a read plus a write 
                */
               metrics[m_index].io_size  = io_size * 2;

               /* verify I/O op */
               if ( (read_io_bytes != (ssize_t)io_size) || 
                    (write_io_bytes != (ssize_t)io_size)){
                  fprintf(logptr, "Warning: child pid # %u, IOP # %u did not ",
		     p, (uint)(this_iop-1));
                  /* fprintf(logptr, */
                  printf(
		     "read/write intended number of bytes;\n");
                  fprintf(logptr, "read %lu bytes,  wrote %lu bytes\n", 
		     (ulong)read_io_bytes, (ulong)write_io_bytes);
               }				      /* if IOP unsuccessful */
   	    } 					      /* for this_iop */

   	    if (close(fd) == -1) io_error("close after rewrite");

            stop_time = timestamp(basetime);
            if ( verbose )
               fprintf(logptr, "ReWrite Child %u ends; elapsed: %12.6lf\n",
                        p, stop_time - start_time);
            exit( EXIT_NORMAL_TERMINATION );    /* important for children! */
       }                                        /* if child process */
   }                                            /* for p */

   assert(!errno);

   /* parent waits for all children to complete, then samples CPU */

   MARK("ReWrite", "Start"); 
   sample_times(basetime, &last_elapsed_time, &last_cpu_time);

   /* bulk of I/O is being done by children now; wait for them to finish */
   for (p=0; p<nprocs; p++ ) {
      retval = waitpid(-1, &status, NULL);
      if (errno && (errno!=EINTR)) perror("bertha waitpid(): ");

      if ( status ) {
         fprintf(logptr,
            "When generating input file, child process terminated\n");
         fprintf(logptr,"with errno: %d\n",status>>16);
          
        /* 
         * kill off remaining children
         */
         for (p0=0; p0<nprocs ; p0++) if (child[p0]) kill(child[p0],SIGINT);

       /*
        * pop smoke and evacuate
        */ 
         terminate( (uint)(status>>16) );
      }						/* if status */
   }						/* for p */

   get_delta_t(ReWrite, delta, basetime, &last_elapsed_time, &last_cpu_time);

   MARK("ReWrite", "Stop"); 
   SYNC("ReWrite");

   fprintf(logptr, "ReWrite: %7.3lf elapsed seconds, %10.6lf CPU seconds ",
		delta[(int)ReWrite][ELAPSED],delta[(int)ReWrite][CPU]);
   fprintf(logptr,
          " Thruput: %7.3lf MB/sec\n",
	  (double)(nprocs)*(2*fsize+io_size) / 
	     (1024 * 1024 * (delta[(int)ReWrite][ELAPSED])));

  /*--------------------------------------------------------------
   * clean-up and generate report
   *--------------------------------------------------------------*/
   assert( !errno );
   for (p=0; p<nprocs; p++) 
      if (unlink(name[p])) {
         fprintf(logptr, "WARNING: Could not unlink file \"%s\"; ", name[p]);
         fprintf(logptr, "errno = %d\n", errno);
         errno = 0;		 /* reset errno; only a warning, not fatal */
      }

   bonnie_report(testname, fsize, nprocs, delta, io_size);
   free( buff );

  /* 
   * Emit output table and generate relevant reports & charts; 
   */
   do_reports(metrics, nprocs, iops, "ReWrite", test_timestamp,
              hist_args, rptdir, testname, dump_raw_metrics_flag, 
              metrics_by_proc_flag, reports_requested, logptr, verbose, 
              0 /* replay_mono_file_flag = 0*/);

   /* record raw data for rereporting later if requested */
   if (record_flag)
      do_record(metrics, nprocs, iops, "ReWrite", rptdir, test_timestamp,
             testname, logptr, verbose, 0/*replay_mono_file_flag*/);
   /* note: shared memory seg for metrics[] is release in terminate() */

  /*--------------------------------------------------------------
   * Post-conditions
   *--------------------------------------------------------------*/
   assert(!errno);
}							/* thruput() */
